from django.contrib import admin
from django.urls import include, path

admin.site.site_header = "FindMyBus admin"
admin.site.site_title = "FindMyBus"

urlpatterns = [
    path("django-admin/", admin.site.urls),
    path("", include("transit.urls")),
]
