from django.db.models.signals import post_delete, post_save
from django.dispatch import receiver

from .models import Route, Stop


@receiver([post_save, post_delete], sender=Route)
@receiver([post_save, post_delete], sender=Stop)
def _routes_changed(**kwargs):
    from .fleet.service import fleet_or_none
    svc = fleet_or_none()
    if svc is not None:
        svc.request_reload()
