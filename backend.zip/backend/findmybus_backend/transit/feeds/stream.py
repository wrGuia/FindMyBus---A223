"""LA Metro real-time WebSocket (the API's main live channel), in a background thread.

wss://api.metro.net/ws/{agency}/vehicle_positions/{route_codes}
The server sends one JSON vehicle record about every 3 seconds per bus, or a
text message starting with "Error". We keep the latest record per vehicle.
"""
import json
import threading
import time

from .. import conf
from . import metro

try:
    import websocket          # pip package: websocket-client
except ImportError:           # reported in /api/status/ instead of crashing
    websocket = None


class MetroStream:
    def __init__(self):
        self._lock = threading.Lock()
        self._threads = {}        # agency -> Thread
        self._wanted = {}         # agency -> tuple of route codes to subscribe to
        self._apps = {}           # agency -> current WebSocketApp
        self._vehicles = {}       # route_code -> {vehicle_id: (parsed, received_at)}
        self._status = {"state": "idle", "url": None, "connected_at": None, "last_message_at": None,
                        "messages": 0, "unparsed": 0, "errors": 0, "last_error": None, "last_sample": None}

    # ----------------------------------------------------------- reading
    def snapshot(self):
        with self._lock:
            snap = dict(self._status)
            snap["vehicles_by_route"] = {c: len(v) for c, v in self._vehicles.items()}
            return snap

    def healthy(self, now=None):
        now = now or time.time()
        with self._lock:
            last = self._status["last_message_at"]
            return (self._status["state"] == "connected" and last is not None
                    and now - last < conf.STREAM_HEALTHY_SECONDS)

    def vehicles(self, route_code, keep_seconds=conf.LIVE_KEEP_SECONDS, now=None):
        cutoff = (now or time.time()) - keep_seconds
        with self._lock:
            bucket = self._vehicles.get(str(route_code), {})
            for vid in [v for v, (_, ts) in bucket.items() if ts < cutoff]:
                del bucket[vid]
            return [dict(p, received_at=ts) for p, ts in bucket.values()]

    # ----------------------------------------------------------- writing
    def _set(self, **kw):
        with self._lock:
            self._status.update(kw)

    def handle(self, message, now=None):
        if isinstance(message, bytes):
            message = message.decode("utf-8", "replace")
        now = now or time.time()
        with self._lock:
            self._status["messages"] += 1
            self._status["last_message_at"] = now
            self._status["last_sample"] = message[:500]
        if message.startswith("Error"):
            self._set(last_error=message[:200])
            with self._lock:
                self._status["errors"] += 1
            return
        try:
            payload = json.loads(message)
        except ValueError:
            with self._lock:
                self._status["errors"] += 1
                self._status["last_error"] = "unreadable (non-JSON) message"
            return
        for rec in payload if isinstance(payload, list) else [payload]:
            if not isinstance(rec, dict):
                continue
            parsed, code = metro.parse_vehicle(rec), metro.route_code_of(rec)
            with self._lock:
                if parsed is None or not code:
                    self._status["unparsed"] += 1
                else:
                    self._vehicles.setdefault(code, {})[parsed["id"]] = (parsed, now)

    def _run(self, agency):
        backoff = 2
        while True:
            with self._lock:
                codes = self._wanted[agency]
            url = f"{conf.METRO_WS_BASE}/ws/{agency}/vehicle_positions/{','.join(codes)}"
            self._set(state="connecting", url=url)
            try:
                app = websocket.WebSocketApp(
                    url,
                    header=[f"Authorization: Bearer {conf.METRO_API_TOKEN}"] if conf.METRO_API_TOKEN else None,
                    on_open=lambda ws: self._set(state="connected", connected_at=time.time(), last_error=None),
                    on_message=lambda ws, m: self.handle(m),
                    on_error=lambda ws, e: self._set(last_error=f"{type(e).__name__}: {e}"[:200]),
                )
                with self._lock:
                    self._apps[agency] = app
                app.run_forever(ping_interval=25, ping_timeout=10)
            except Exception as exc:
                self._set(last_error=f"{type(exc).__name__}: {exc}"[:200])
            self._set(state="disconnected")
            with self._lock:
                changed = self._wanted[agency] != codes
            if changed:                               # route list changed: reconnect right away
                backoff = 2
                continue
            if self.healthy(time.time() - 1):
                backoff = 2
            time.sleep(backoff)
            backoff = min(backoff * 2, 60)

    def ensure_started(self, routes):
        """One background connection per agency. Reconnects when the set of route codes changes."""
        if websocket is None:
            self._set(state="unavailable",
                      last_error="websocket-client is not installed (pip install -r requirements.txt)")
            return
        groups = {}
        for r in routes:
            groups.setdefault(r.agency, set()).add(str(r.code))
        with self._lock:
            for agency, codes in groups.items():
                codes = tuple(sorted(codes))
                old = self._wanted.get(agency)
                self._wanted[agency] = codes
                t = self._threads.get(agency)
                if t is not None and t.is_alive():
                    if old != codes and self._apps.get(agency) is not None:
                        self._apps[agency].close()
                    continue
                t = threading.Thread(target=self._run, args=(agency,), daemon=True, name=f"metro-ws-{agency}")
                self._threads[agency] = t
                t.start()
