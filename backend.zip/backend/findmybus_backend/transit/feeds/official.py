"""Turn LA Metro's official stop rows into one ordered stop list (pure, no network)."""
import json

from ..core.geo import haversine_m


def _point(obj):
    """(lat, lon) from a GeoJSON Point/Feature (dict or JSON string) or plain lat/lon fields."""
    if isinstance(obj, str):
        try:
            obj = json.loads(obj)
        except ValueError:
            return None
    if not isinstance(obj, dict):
        return None
    if isinstance(obj.get("geometry"), (dict, str)):
        got = _point(obj["geometry"])
        if got:
            return got
    coords = obj.get("coordinates")
    if isinstance(coords, (list, tuple)) and len(coords) >= 2:
        try:
            return float(coords[1]), float(coords[0])
        except (TypeError, ValueError):
            return None
    if isinstance(obj.get("geojson"), (dict, str)):
        return _point(obj["geojson"])
    for la, lo in (("stop_lat", "stop_lon"), ("latitude", "longitude"), ("lat", "lon")):
        try:
            return float(obj[la]), float(obj[lo])
        except (KeyError, TypeError, ValueError):
            continue
    return None


def _patterns(rows):
    """Cleaned stop lists, one per (day type, route id, direction) pattern of the best day type."""
    groups = {}
    for row in rows:
        if not isinstance(row, dict):
            continue
        pt = _point(row)
        try:
            seq = int(row.get("stop_sequence"))
        except (TypeError, ValueError):
            continue
        if pt is None:
            continue
        key = (str(row.get("day_type") or "").lower(), str(row.get("route_id")), row.get("direction_id"))
        name = (row.get("stop_name") or "").strip() or f"Stop {row.get('stop_id')}"
        groups.setdefault(key, {})[seq] = {"name": name, "lat": pt[0], "lon": pt[1]}
    if not groups:
        return []
    day_types = {k[0] for k in groups}
    day = "weekday" if "weekday" in day_types else max(
        day_types, key=lambda d: sum(len(v) for k, v in groups.items() if k[0] == d))
    out = []
    for (d, rid, direction), stops in groups.items():
        if d != day:
            continue
        ordered = [stops[s] for s in sorted(stops)]
        clean = [ordered[0]]
        for s in ordered[1:]:                        # drop consecutive duplicates
            if haversine_m(clean[-1]["lat"], clean[-1]["lon"], s["lat"], s["lon"]) > 10:
                clean.append(s)
        if len(clean) >= 5:
            out.append({"route_id": rid, "direction": direction, "stops": clean})
    return out


def _nearest(line, point):
    """(index, distance in m) of the stop closest to point."""
    best_i, best_d = 0, float("inf")
    for i, s in enumerate(line):
        d = haversine_m(s["lat"], s["lon"], *point)
        if d < best_d:
            best_i, best_d = i, d
    return best_i, best_d


def _length_m(line):
    return sum(haversine_m(a["lat"], a["lon"], b["lat"], b["lon"]) for a, b in zip(line, line[1:]))


def _between_terminals(line, start, end, tolerance_m):
    """The part of `line` that runs from the stop nearest `start` to the one nearest `end`, or None.

    Works in either direction of travel (the result always runs start -> end). A pattern that
    carries on past a terminal is cut there, and one that stops short of it is rejected, so a
    partial LA Metro pattern can never replace the full route."""
    for candidate in (line, line[::-1]):
        i, di = _nearest(candidate, start)
        j, dj = _nearest(candidate, end)
        if i < j and di <= tolerance_m and dj <= tolerance_m:
            return candidate[i:j + 1]
    return None


def build_stops(rows, toward=None, terminals=None, tolerance_m=2000.0):
    """Rows -> [{"name","lat","lon"}] ordered in the "fwd" direction, or None if unusable.

    With `terminals` = ((lat, lon) of the first stop, (lat, lon) of the last stop), the result is the
    longest official pattern that really runs between those two points (see _between_terminals).
    Without it, keeps the longest weekday pattern per direction and orients the result so it
    ends closer to `toward` (lat, lon) than it starts."""
    patterns = _patterns(rows)
    if not patterns:
        return None

    if terminals:
        start, end = terminals
        fits = [seg for p in patterns
                for seg in [_between_terminals(p["stops"], start, end, tolerance_m)] if seg and len(seg) >= 5]
        if not fits:
            return None
        return max(fits, key=lambda seg: (_length_m(seg), len(seg)))

    best = {}
    for p in patterns:
        if p["direction"] not in best or len(p["stops"]) > len(best[p["direction"]]):
            best[p["direction"]] = p["stops"]
    lines = list(best.values())

    def score(line):                                 # negative = heads toward `toward`
        if not toward:
            return 0.0
        return haversine_m(line[-1]["lat"], line[-1]["lon"], *toward) - haversine_m(
            line[0]["lat"], line[0]["lon"], *toward)

    fwd = min(lines, key=score)
    return fwd[::-1] if toward and score(fwd) > 0 else fwd


def _name_key(name):
    return "".join(ch for ch in (name or "").lower() if ch.isalnum())


def match_stops(rows, stops, max_m=3000.0):
    """Give hand-entered stops LA Metro's exact positions, matched by stop name.

    `stops` is [{"name","lat","lon"}, ...] in route order. When several official stops share a name
    (the two sides of a street, or both directions) the one closest to the entered position is used,
    and a name entered twice gets two different official stops where they exist. Stops without an
    official namesake within `max_m` keep their position. Returns (new stops, number matched)."""
    pool = {}
    for p in _patterns(rows):
        for s in p["stops"]:
            bucket = pool.setdefault(_name_key(s["name"]), [])
            if not any(haversine_m(s["lat"], s["lon"], o["lat"], o["lon"]) < 3 for o in bucket):
                bucket.append(s)
    used, out, matched = set(), [], 0
    for st in stops:
        key = _name_key(st["name"])
        cands = [(haversine_m(st["lat"], st["lon"], c["lat"], c["lon"]), i, c)
                 for i, c in enumerate(pool.get(key, [])) if (key, i) not in used]
        cands = [c for c in cands if c[0] <= max_m]
        if not cands:
            out.append(dict(st))
            continue
        d, i, best = min(cands, key=lambda c: c[0])
        used.add((key, i))
        out.append({**st, "lat": best["lat"], "lon": best["lon"]})
        matched += 1
    return out, matched
