"""Snap hand-entered stops to real roads with OSRM. Returns None when it can't."""
import logging
import math
import time

import requests

from .. import conf
from ..core.geo import haversine_m

log = logging.getLogger(__name__)


def road_points(stops, session=requests):
    """[(lat, lon), ...] following the streets through every stop, or None."""
    if len(stops) < 2:
        return None
    coords = ";".join(f"{s['lon']},{s['lat']}" for s in stops)
    try:
        r = session.get(f"{conf.OSRM_URL}{coords}", params={"overview": "full", "geometries": "geojson"},
                        timeout=conf.HTTP_TIMEOUT)
        r.raise_for_status()
        line = r.json()["routes"][0]["geometry"]["coordinates"]
        return [(lat, lon) for lon, lat in line] if len(line) >= 2 else None
    except Exception as exc:                          # network, HTTP, JSON shape
        log.info("OSRM road snapping unavailable: %s", exc)
        return None


def _straight_m(points):
    return sum(haversine_m(a[0], a[1], b[0], b[1]) for a, b in zip(points, points[1:]))


def snap_official(stops, session=requests, max_ratio=1.35, chunk=20):
    """Follow the streets through widely spaced official stops, in chunks of `chunk` stops.

    A chunk whose road route is more than `max_ratio` times longer than the straight line
    (OSRM took a freeway or a detour) keeps the straight line instead. Returns (points, snapped_all)."""
    pts, snapped_all = [], True
    i = 0
    while i < len(stops) - 1:
        part = stops[i:i + chunk]
        straight = [(s["lat"], s["lon"]) for s in part]
        road = road_points(part, session=session)
        if road is None or _straight_m(road) > max_ratio * max(_straight_m(straight), 1.0):
            road, snapped_all = straight, snapped_all and road is not None
        pts.extend(road if not pts else road[1:])
        i += chunk - 1
    return pts, snapped_all


# ---- Road line through a full, hand-entered stop list -------------------------------------------------

def _bearing_deg(a, b):
    p1, p2 = math.radians(a["lat"]), math.radians(b["lat"])
    dl = math.radians(b["lon"] - a["lon"])
    y = math.sin(dl) * math.cos(p2)
    x = math.cos(p1) * math.sin(p2) - math.sin(p1) * math.cos(p2) * math.cos(dl)
    return (math.degrees(math.atan2(y, x)) + 360.0) % 360.0


def _get_json(session, coords, params):
    """GET one route from the first OSRM server that answers. A busy server (429/5xx) is retried with a
    short wait, then the next server is tried. A 400 ("no route", "no segment") is a real answer: returned."""
    last = None
    for base in conf.OSRM_URLS:
        for attempt in range(3):
            try:
                r = session.get(f"{base}{coords}", params=params, timeout=conf.HTTP_TIMEOUT)
                code = getattr(r, "status_code", 200)
                if code in (429, 502, 503, 504):
                    last = RuntimeError(f"HTTP {code} from {base}")
                    time.sleep(1.0 * (attempt + 1))
                    continue
                if code == 400:
                    return r.json()
                r.raise_for_status()
                return r.json()
            except Exception as exc:                  # timeout, connection, bad JSON
                last = exc
                break
    raise last or RuntimeError("no OSRM server configured")


def _route(stops, session, directed, radius_m, bearing_range):
    """One OSRM request through `stops`. With `directed`, each waypoint may only snap to a road that runs
    the way the bus travels (within +-bearing_range degrees), so a stop that sits a little off Wilshire
    snaps to Wilshire, not to a side street (which would draw a spur) or the street behind it."""
    coords = ";".join(f"{s['lon']},{s['lat']}" for s in stops)
    params = {"overview": "full", "geometries": "geojson", "continue_straight": "true"}
    if directed:
        bearings = []
        for i, s in enumerate(stops):
            prev_s = stops[max(i - 1, 0)]
            next_s = stops[min(i + 1, len(stops) - 1)]
            bearings.append(f"{round(_bearing_deg(prev_s, next_s)) % 360},{bearing_range}")
        params["bearings"] = ";".join(bearings)
        params["radiuses"] = ";".join([str(int(radius_m))] * len(stops))
    body = _get_json(session, coords, params)
    if body.get("code") != "Ok":
        return None
    line = body["routes"][0]["geometry"]["coordinates"]
    if len(line) < 2:
        return None
    try:
        legs = [float(leg["distance"]) for leg in body["routes"][0]["legs"]]
    except (KeyError, TypeError, ValueError):
        legs = None                                   # server gave no per-leg distances: skip the leg check
    return [(lat, lon) for lon, lat in line], legs


def snap_stop_list(stops, session=requests, chunk=10, max_ratio=1.25, slack_m=120.0, radius_m=250.0,
                   bearing_range=60, pause_s=0.15, stats=None, leg_ratio=1.3, leg_slack_m=100.0):
    """The street line through a full stop list: [(lat, lon), ...] and whether every stretch was snapped.

    Works in chunks of `chunk` stops. A chunk whose road route is more than `max_ratio` times (plus
    `slack_m`) longer than the straight line (OSRM took a freeway or a one-way detour) is split in
    half and retried; a single stop-to-stop stretch that still fails keeps a straight line."""
    state = {"all": True}
    stats = stats if stats is not None else {}
    stats.update(bad=0, total=max(len(stops) - 1, 0), failed_requests=0, bad_pairs=[])

    def straight(part):
        return [(s["lat"], s["lon"]) for s in part]

    def acceptable(part, pts, legs):
        """The whole road line is not much longer than the straight line, AND neither is any single
        stop-to-stop leg. (A short block-long loop or a side-street zigzag hides inside a long chunk.)"""
        if _straight_m(pts) > max_ratio * _straight_m(straight(part)) + slack_m:
            return False
        if legs and len(legs) == len(part) - 1:
            for a, b, d in zip(part, part[1:], legs):
                if d > leg_ratio * haversine_m(a["lat"], a["lon"], b["lat"], b["lon"]) + leg_slack_m:
                    return False
        return True

    def solve(part):
        for directed in (True, False):
            try:
                time.sleep(pause_s)
                got = _route(part, session, directed, radius_m, bearing_range)
            except Exception as exc:
                stats["failed_requests"] += 1
                if stats["failed_requests"] <= 3:
                    log.info("OSRM request failed: %s", exc)
                got = None
            if got and acceptable(part, *got):
                return got[0]
        if len(part) <= 2:
            state["all"] = False
            stats["bad"] += 1
            if len(part) == 2:
                stats["bad_pairs"].append(f"{part[0]['name']} -> {part[1]['name']}")
            return straight(part)
        mid = len(part) // 2
        left, right = solve(part[:mid + 1]), solve(part[mid:])
        return left + right[1:]

    out, i = [], 0
    while i < len(stops) - 1:
        part = stops[i:i + chunk]
        pts = solve(part)
        out.extend(pts if not out else pts[1:])
        i += chunk - 1
    return out, state["all"]


def pin_stops_to_line(stops, points, max_move_m=300.0):
    """Move each stop onto the road line (when it is within max_move_m of it), so stops sit on the road.
    Returns new stop dicts in the same order."""
    from ..core.geo import Polyline
    line = Polyline(points)
    out, start = [], 0.0
    for s in stops:
        along, off = line.project(s["lat"], s["lon"], start)
        if off <= max_move_m:
            lat, lon = line.point_at(along)
            out.append({**s, "lat": round(lat, 6), "lon": round(lon, 6)})
            start = along
        else:
            out.append(dict(s))
    return out
