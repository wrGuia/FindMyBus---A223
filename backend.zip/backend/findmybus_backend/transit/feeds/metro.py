"""LA Metro real-time REST client and record parser (https://api.metro.net).

The API passes GTFS-realtime data through, so the parser accepts a few layouts
(flat fields, or nested vehicle.position.latitude) instead of exactly one.
"""
import requests

from .. import conf

_LIST_KEYS = ("items", "data", "vehicles", "results", "entity", "entities")


def _headers():
    h = {"Accept": "application/json"}
    if conf.METRO_API_TOKEN:
        h["Authorization"] = f"Bearer {conf.METRO_API_TOKEN}"
    return h


def _dig(rec, *path):
    cur = rec
    for key in path:
        if isinstance(cur, dict) and key in cur:
            cur = cur[key]
        else:
            return None
    return cur


def _first(rec, *paths):
    for path in paths:
        val = _dig(rec, *path)
        if val is not None and val != "":
            return val
    return None


def _float(val):
    try:
        return float(val)
    except (TypeError, ValueError):
        return None


def extract_records(payload):
    """The list of vehicle dicts, whatever envelope the API used."""
    if isinstance(payload, list):
        return [r for r in payload if isinstance(r, dict)]
    if isinstance(payload, dict):
        for key in _LIST_KEYS:
            if isinstance(payload.get(key), list):
                return [r for r in payload[key] if isinstance(r, dict)]
        for val in payload.values():
            if isinstance(val, list) and val and all(isinstance(r, dict) for r in val):
                return val
        return [payload]
    return []


def parse_vehicle(rec):
    """One record -> {id, lat, lon, speed_kmh, delay_s, reported_at, trip_id}, or None without a usable position."""
    vid = _first(rec, ("vehicle_id",), ("vehicle", "vehicle", "id"), ("vehicle", "id"), ("id",))
    lat = _float(_first(rec, ("latitude",), ("lat",), ("position", "latitude"),
                        ("vehicle", "position", "latitude"), ("location", "lat")))
    lon = _float(_first(rec, ("longitude",), ("lon",), ("lng",), ("position", "longitude"),
                        ("vehicle", "position", "longitude"), ("location", "lon"), ("location", "lng")))
    if vid is None or lat is None or lon is None:
        return None
    if not (-90 <= lat <= 90 and -180 <= lon <= 180) or (lat == 0 and lon == 0):
        return None
    speed_ms = _float(_first(rec, ("speed",), ("position", "speed"), ("vehicle", "position", "speed")))
    delay = _float(_first(rec, ("delay",), ("trip_update", "delay"), ("stop_time_update", "arrival", "delay")))
    reported = _float(_first(rec, ("timestamp",), ("vehicle", "timestamp"), ("vehicle", "vehicle", "timestamp")))
    if reported is not None and reported > 1e12:                     # milliseconds
        reported /= 1000.0
    return {
        "id": str(vid),
        "lat": lat, "lon": lon,
        "speed_kmh": round(speed_ms * 3.6, 1) if speed_ms is not None and speed_ms >= 0 else None,
        "delay_s": delay,
        "reported_at": reported,
        "trip_id": _first(rec, ("trip_id",), ("trip", "trip_id"), ("vehicle", "trip", "trip_id")),
    }


def route_code_of(rec):
    """Route code of a record without any HASTUS suffix ('720-13168' -> '720')."""
    raw = _first(rec, ("route_code",), ("vehicle", "trip", "route_id"), ("trip", "route_id"), ("route_id",))
    return str(raw).split("-")[0] if raw is not None else None


def parse_payload(payload):
    seen, out = set(), []
    for rec in extract_records(payload):
        v = parse_vehicle(rec)
        if v and v["id"] not in seen:
            seen.add(v["id"])
            out.append(v)
    return out


def fetch_vehicles(agency, route_code, session=requests):
    """Live vehicles on one route. Raises on network or HTTP errors."""
    r = session.get(f"{conf.METRO_API_BASE}/{agency}/trip_detail/route_code/{route_code}",
                    headers=_headers(), timeout=conf.HTTP_TIMEOUT)
    r.raise_for_status()
    return parse_payload(r.json())


def fetch_route_stops(agency, route_code, session=requests):
    """Raw official stop rows for a route (weekday pattern first, then any day type)."""
    url = f"{conf.METRO_API_BASE}/{agency}/route_stops/{route_code}"
    rows = []
    for params in ({"daytype": "weekday"}, {}):
        r = session.get(url, params=params, headers=_headers(), timeout=conf.HTTP_TIMEOUT)
        r.raise_for_status()
        rows = r.json()
        if isinstance(rows, list) and rows:
            break
    return rows if isinstance(rows, list) else []
