"""Network clients: LA Metro (REST + WebSocket), official stop lists, OSRM road geometry."""
