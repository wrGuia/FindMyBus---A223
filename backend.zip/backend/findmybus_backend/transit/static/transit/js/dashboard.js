(function () {
  "use strict";
  var cfg = JSON.parse(document.getElementById("page-config").textContent);
  var $ = function (id) { return document.getElementById(id); };
  var TRAFFIC = { heavy: "#e5383b", light: "#f2c14e" };
  var routeLayer = null, busLayer = null, fitted = false, lastData = null, pathCache = {};

  var map = L.map("map").setView([34.0522, -118.29], 11);
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
    { maxZoom: 19, attribution: "&copy; OpenStreetMap contributors" }).addTo(map);

  function esc(v) { var d = document.createElement("div"); d.textContent = String(v); return d.innerHTML; }
  function rgb(c) { return "rgb(" + c[0] + "," + c[1] + "," + c[2] + ")"; }
  function ago(sec) {
    if (sec < 5) return "now";
    if (sec < 90) return Math.round(sec) + " s ago";
    return Math.round(sec / 60) + " min ago";
  }
  function hav(a, b) {
    var R = 6371008.8, r = Math.PI / 180;
    var dp = (b[0] - a[0]) * r, dl = (b[1] - a[1]) * r;
    var h = Math.sin(dp / 2) * Math.sin(dp / 2) +
      Math.cos(a[0] * r) * Math.cos(b[0] * r) * Math.sin(dl / 2) * Math.sin(dl / 2);
    return 2 * R * Math.asin(Math.min(1, Math.sqrt(h)));
  }
  function cumulative(path) {
    var cum = [0];
    for (var i = 1; i < path.length; i++) cum.push(cum[i - 1] + hav(path[i - 1], path[i]));
    return cum;
  }
  // Points of `path` between two distances along it (metres).
  function slice(path, cum, from, to) {
    function at(d) {
      for (var i = 1; i < cum.length; i++) {
        if (d <= cum[i]) {
          var seg = cum[i] - cum[i - 1], f = seg ? (d - cum[i - 1]) / seg : 0;
          return [path[i - 1][0] + f * (path[i][0] - path[i - 1][0]), path[i - 1][1] + f * (path[i][1] - path[i - 1][1])];
        }
      }
      return path[path.length - 1];
    }
    var out = [at(from)];
    for (var i = 0; i < path.length; i++) if (cum[i] > from && cum[i] < to) out.push(path[i]);
    out.push(at(to));
    return out;
  }

  var chart = new Chart($("history-chart"), {
    type: "line",
    data: { labels: [], datasets: [
      { label: "On time", data: [], borderColor: "#2a9d8f", tension: .25, pointRadius: 0 },
      { label: "Delayed", data: [], borderColor: "#f4a261", tension: .25, pointRadius: 0 },
      { label: "Off route", data: [], borderColor: "#e5383b", tension: .25, pointRadius: 0 },
    ] },
    options: { responsive: true, maintainAspectRatio: false, animation: false,
      scales: { y: { beginAtZero: true, ticks: { precision: 0 } } } },
  });

  function badge(src) {
    var el = $("source-badge");
    var text = { live: "Live: LA Metro real-time feed", mixed: "Partly live (" + src.live_routes + " of " + src.total_routes + " routes)",
      empty: "Live only: no buses in service", simulated: "Simulated" }[src.state];
    el.className = "badge " + src.state;
    el.textContent = text + (src.reason ? " · " + src.reason : "");
    el.hidden = false;
  }

  function renderMap(data) {
    if (routeLayer) map.removeLayer(routeLayer);
    var layers = [];
    data.routes.forEach(function (r) {
      var key = r.id + ":" + r.path.length;
      if (!pathCache[key]) pathCache[key] = cumulative(r.path);
      var cum = pathCache[key];
      layers.push(L.polyline(r.path, { color: rgb(r.color), weight: 5, opacity: .85 }).bindTooltip(esc(r.name)));
      r.traffic.forEach(function (s) {
        if (!TRAFFIC[s.level]) return;
        layers.push(L.polyline(slice(r.path, cum, s.start_km * 1000, s.end_km * 1000),
          { color: TRAFFIC[s.level], weight: 7, opacity: .95 }).bindTooltip(s.level === "heavy" ? "Heavy traffic" : "Light traffic"));
      });
      r.stops.forEach(function (s) {
        layers.push(L.circleMarker([s.lat, s.lon], { radius: 3, color: "#555", weight: 1, fillColor: "#fff", fillOpacity: 1 })
          .bindTooltip(esc(s.name)));
      });
    });
    routeLayer = L.layerGroup(layers).addTo(map);

    if (busLayer) map.removeLayer(busLayer);
    busLayer = L.layerGroup(data.buses.map(function (b) {
      var fill = b.freshness !== "live" ? "#9aa0a6" : (b.status === "On Time" && !b.deviation ? "#2a9d8f" : "#f4a261");
      return L.circleMarker([b.lat, b.lon], { radius: 8, color: "#fff", weight: 2, fillColor: fill, fillOpacity: 1 })
        .bindTooltip(esc(b.id) + "<br>" + esc(b.route_name) + "<br>" + esc(b.heading) + "<br>" + esc(b.status) +
          (b.deviation ? " · off route" : ""));
    })).addTo(map);

    if (!fitted && data.routes.length) {
      var all = [];
      data.routes.forEach(function (r) { all = all.concat(r.path); });
      map.fitBounds(all, { padding: [20, 20] });
      fitted = true;
    }
  }

  function renderTable(data) {
    var route = $("route-filter").value, problems = $("problems-only").checked;
    var rows = data.buses.filter(function (b) {
      return (!route || b.route_id === route) && (!problems || b.status !== "On Time" || b.deviation);
    });
    $("fleet-tbody").innerHTML = rows.map(function (b) {
      var status = b.deviation ? "Off route" : b.status;
      return "<tr class='" + (b.freshness !== "live" ? "stale" : "") + "'><td>" + esc(b.id) + "</td><td>" + esc(b.route_name) +
        "</td><td>" + esc(b.heading) + "</td><td>" + esc(b.next_stop) + "</td><td><span class='pill " +
        (status === "On Time" ? "ok" : "late") + "'>" + esc(status) + "</span></td><td>" +
        (b.speed_kmh == null ? "–" : b.speed_kmh.toFixed(0) + " km/h") + "</td><td>" +
        ago(data.server_time - b.updated_at) + (b.freshness !== "live" ? " (" + b.freshness + ")" : "") +
        "</td><td>" + (b.live ? "LA Metro" : "Simulator") + "</td></tr>";
    }).join("") || "<tr><td colspan='8' class='caption'>No buses match.</td></tr>";
  }

  function renderDeviations(list) {
    $("dev-tbody").innerHTML = list.map(function (e) {
      return "<tr><td>" + esc(e.bus_id) + "</td><td>" + esc(e.route_name) + "</td><td>" + esc(e.started) + "</td><td>" +
        (e.duration_s == null ? "ongoing" : Math.round(e.duration_s) + " s") + "</td><td>" + e.max_offset_m + " m</td><td>" +
        (e.live ? "LA Metro" : "Simulator") + "</td></tr>";
    }).join("") || "<tr><td colspan='6' class='caption'>No deviations recorded yet.</td></tr>";
  }

  function renderChart(history) {
    chart.data.labels = history.map(function (h) { return new Date(h.t * 1000).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }); });
    chart.data.datasets[0].data = history.map(function (h) { return h.on_time; });
    chart.data.datasets[1].data = history.map(function (h) { return h.delayed; });
    chart.data.datasets[2].data = history.map(function (h) { return h.deviating; });
    chart.update();
  }

  async function refresh() {
    try {
      var res = await fetch(cfg.fleetApi, { cache: "no-store" });
      if (res.status === 401) { window.location.reload(); return; }
      var data = await res.json();
      lastData = data;
      badge(data.source);
      var b = data.buses;
      $("k-total").textContent = b.length;
      $("k-ontime").textContent = b.filter(function (x) { return x.status === "On Time"; }).length;
      $("k-delayed").textContent = b.filter(function (x) { return x.status === "Delayed"; }).length;
      $("k-dev").textContent = b.filter(function (x) { return x.deviation; }).length;
      $("k-stale").textContent = b.filter(function (x) { return x.freshness !== "live"; }).length;
      renderMap(data);
      renderTable(data);
      renderDeviations(data.deviations);
      renderChart(data.history);
    } catch (e) { console.error("refresh failed", e); }
  }

  $("route-filter").addEventListener("change", function () { if (lastData) renderTable(lastData); });
  $("problems-only").addEventListener("change", function () { if (lastData) renderTable(lastData); });
  refresh();
  setInterval(function () { if (!document.hidden) refresh(); }, cfg.refreshMs);
})();
