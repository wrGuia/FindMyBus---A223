"""ETA from live position and progress along the route (mirrors the app's lib/core/eta.dart).

    ETA = remaining distance / smoothed recent speed + a short dwell per stop in between

Kept deliberately simple and isolated so it can be improved later.
"""
from dataclasses import dataclass

from .. import conf


class SpeedSmoother:
    """Exponential moving average of each bus's speed, so one red light doesn't swing the ETA."""

    def __init__(self, alpha=conf.SPEED_SMOOTHING):
        self.alpha = alpha
        self._ema = {}

    def add(self, bus_id, kmh):
        if kmh is None or kmh != kmh or kmh < 0:
            return self._ema.get(bus_id)
        prev = self._ema.get(bus_id)
        self._ema[bus_id] = kmh if prev is None else prev + self.alpha * (kmh - prev)
        return self._ema[bus_id]

    def get(self, bus_id):
        return self._ema.get(bus_id)

    def retain(self, bus_ids):
        keep = set(bus_ids)
        for k in [k for k in self._ema if k not in keep]:
            del self._ema[k]


@dataclass(frozen=True)
class EtaResult:
    remaining_m: float
    eta_s: float
    passed: bool
    stops_away: int          # stops strictly between the bus and the target stop


def effective_kmh(smoothed_kmh):
    if smoothed_kmh is None:
        return conf.ETA_FALLBACK_KMH
    return max(conf.ETA_MIN_KMH, min(conf.ETA_MAX_KMH, smoothed_kmh))


def eta_to_stop(bus_along_m, stop_along_m, forward, smoothed_kmh, stops_along_m=()):
    """`forward` = the bus travels toward increasing distance along the route."""
    signed = stop_along_m - bus_along_m if forward else bus_along_m - stop_along_m
    passed = signed < -conf.ETA_PASSED_MARGIN_M
    if passed:
        return EtaResult(abs(signed), 0.0, True, 0)
    remaining = max(signed, 0.0)
    between = 0
    for s in stops_along_m:
        ahead = s - bus_along_m if forward else bus_along_m - s
        before_target = s < stop_along_m - 1 if forward else s > stop_along_m + 1
        if ahead > 1 and before_target:
            between += 1
    mps = effective_kmh(smoothed_kmh) / 3.6
    return EtaResult(remaining, remaining / mps + between * conf.ETA_DWELL_PER_STOP_S, False, between)
