"""Traffic levels along a route, inferred from live bus speeds (mirrors the app's lib/core/traffic.dart).

There is no traffic API. The route is cut into fixed-length buckets; each
speed report is blended into the buckets around the bus. Readings expire so a
stretch nobody drove recently goes back to "unknown".
    heavy (red)  < 12 km/h  <=  light (yellow)  < 22 km/h  <=  clear
"""
import math

from .. import conf

UNKNOWN, CLEAR, LIGHT, HEAVY = "unknown", "clear", "light", "heavy"


def level_of(kmh):
    if kmh is None:
        return UNKNOWN
    if kmh < conf.TRAFFIC_HEAVY_BELOW_KMH:
        return HEAVY
    if kmh < conf.TRAFFIC_LIGHT_BELOW_KMH:
        return LIGHT
    return CLEAR


class TrafficModel:
    def __init__(self, route_length_m, bucket_m=conf.TRAFFIC_BUCKET_M):
        self.route_length_m = route_length_m
        self.bucket_m = bucket_m
        n = max(1, math.ceil(route_length_m / bucket_m))
        self._kmh = [None] * n
        self._seen = [None] * n

    def observe(self, along_m, kmh, at):
        if kmh is None or kmh != kmh or kmh < 0:
            return
        lo = math.floor((along_m - conf.TRAFFIC_INFLUENCE_M) / self.bucket_m)
        hi = math.floor((along_m + conf.TRAFFIC_INFLUENCE_M) / self.bucket_m)
        for i in range(max(lo, 0), min(hi, len(self._kmh) - 1) + 1):
            seen = self._seen[i]
            expired = seen is None or at - seen > conf.TRAFFIC_MEMORY_SECONDS
            prev = self._kmh[i]
            self._kmh[i] = kmh if (expired or prev is None) else prev + conf.TRAFFIC_ALPHA * (kmh - prev)
            self._seen[i] = at

    def _level(self, i, now):
        seen = self._seen[i]
        if seen is None or now - seen > conf.TRAFFIC_MEMORY_SECONDS:
            return UNKNOWN
        return level_of(self._kmh[i])

    def level_at(self, along_m, now):
        i = min(max(int(along_m // self.bucket_m), 0), len(self._kmh) - 1)
        return self._level(i, now)

    def segments(self, now):
        """Runs of equal level: [(start_m, end_m, level), ...] covering the whole route."""
        out, cur, start = [], None, 0.0
        for i in range(len(self._kmh)):
            lvl = self._level(i, now)
            if lvl != cur:
                if cur is not None:
                    out.append((start, i * self.bucket_m, cur))
                cur, start = lvl, i * self.bucket_m
        out.append((start, self.route_length_m, cur))
        return out
