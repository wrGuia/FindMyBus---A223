"""Route deviation: flag a bus that stays farther than a threshold from its route for longer than a duration.

Both values are configurable (FINDMYBUS_DEVIATION_M, FINDMYBUS_DEVIATION_SECONDS).
"""
from dataclasses import dataclass, field

from .. import conf


@dataclass
class _Track:
    off_since: float | None = None
    flagged: bool = False
    max_offset_m: float = 0.0
    flagged_at: float | None = None


@dataclass
class DeviationChange:
    """What changed for one bus on this update (at most one of started / ended is True)."""
    flagged: bool
    started: bool = False
    ended: bool = False
    off_since: float | None = None
    max_offset_m: float = 0.0


@dataclass
class DeviationTracker:
    threshold_m: float = conf.DEVIATION_M
    min_seconds: float = conf.DEVIATION_SECONDS
    _tracks: dict = field(default_factory=dict)

    def update(self, bus_id, offset_m, now):
        t = self._tracks.setdefault(bus_id, _Track())
        if offset_m > self.threshold_m:
            if t.off_since is None:
                t.off_since, t.max_offset_m = now, offset_m
            t.max_offset_m = max(t.max_offset_m, offset_m)
            if not t.flagged and now - t.off_since >= self.min_seconds:
                t.flagged, t.flagged_at = True, now
                return DeviationChange(True, started=True, off_since=t.off_since, max_offset_m=t.max_offset_m)
            return DeviationChange(t.flagged, off_since=t.off_since, max_offset_m=t.max_offset_m)
        was = t.flagged
        change = DeviationChange(False, ended=was, off_since=t.off_since, max_offset_m=t.max_offset_m)
        self._tracks[bus_id] = _Track()
        return change

    def is_flagged(self, bus_id):
        t = self._tracks.get(bus_id)
        return bool(t and t.flagged)

    def retain(self, bus_ids):
        keep = set(bus_ids)
        for k in [k for k in self._tracks if k not in keep]:
            del self._tracks[k]
