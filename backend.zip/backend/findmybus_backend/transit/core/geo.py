"""Route geometry: distances, positions along a line, and snapping a GPS fix onto it."""
import math

EARTH_RADIUS_M = 6371008.8


def haversine_m(lat1, lon1, lat2, lon2):
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi = p2 - p1
    dl = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * EARTH_RADIUS_M * math.asin(min(1.0, math.sqrt(a)))


class Polyline:
    """A route line with cumulative distances, in metres.

    Projection uses a local flat-earth approximation per segment, which is
    accurate to well under a metre at city scale.
    """

    def __init__(self, points):
        pts = []
        for lat, lon in points:
            p = (float(lat), float(lon))
            if not pts or haversine_m(*pts[-1], *p) > 0.5:
                pts.append(p)
        if len(pts) == 1:
            pts.append(pts[0])
        if not pts:
            raise ValueError("a route line needs at least one point")
        self.points = pts
        self.cum = [0.0]
        for a, b in zip(pts, pts[1:]):
            self.cum.append(self.cum[-1] + haversine_m(*a, *b))
        lat0 = sum(p[0] for p in pts) / len(pts)
        self._kx = math.cos(math.radians(lat0)) * math.pi / 180 * EARTH_RADIUS_M
        self._ky = math.pi / 180 * EARTH_RADIUS_M
        self._xy = [(lon * self._kx, lat * self._ky) for lat, lon in pts]
        # Bounding box of each segment, so project() can skip far-away segments cheaply.
        self._boxes = [(min(a[0], b[0]), min(a[1], b[1]), max(a[0], b[0]), max(a[1], b[1]))
                       for a, b in zip(self._xy, self._xy[1:])]

    @property
    def length_m(self):
        return self.cum[-1]

    def point_at(self, along_m):
        d = max(0.0, min(along_m, self.length_m))
        lo, hi = 0, len(self.cum) - 1
        while lo < hi - 1:                       # binary search for the segment
            mid = (lo + hi) // 2
            if self.cum[mid] <= d:
                lo = mid
            else:
                hi = mid
        seg = self.cum[hi] - self.cum[lo]
        f = 0.0 if seg == 0 else (d - self.cum[lo]) / seg
        (a_lat, a_lon), (b_lat, b_lon) = self.points[lo], self.points[hi]
        return a_lat + f * (b_lat - a_lat), a_lon + f * (b_lon - a_lon)

    def bearing_at(self, along_m):
        """Unit vector (east, north) of the line's direction at a distance."""
        i = 1
        while i < len(self.cum) - 1 and self.cum[i] < along_m:
            i += 1
        (ax, ay), (bx, by) = self._xy[i - 1], self._xy[i]
        n = math.hypot(bx - ax, by - ay) or 1.0
        return (bx - ax) / n, (by - ay) / n

    def offset_point(self, along_m, offset_m):
        """A point `offset_m` to the left of the line at `along_m` (used by the simulator's detours)."""
        lat, lon = self.point_at(along_m)
        ex, ny = self.bearing_at(along_m)
        x, y = lon * self._kx - ny * offset_m, lat * self._ky + ex * offset_m
        return y / self._ky, x / self._kx

    def project(self, lat, lon, start_m=0.0):
        """(along_m, offset_m) of the closest point on the line at or after `start_m`."""
        px, py = lon * self._kx, lat * self._ky
        best_d2, best_along = float("inf"), 0.0
        for i in range(1, len(self._xy)):
            if self.cum[i] < start_m:
                continue
            x0, y0, x1, y1 = self._boxes[i - 1]
            bx_d = x0 - px if px < x0 else (px - x1 if px > x1 else 0.0)
            by_d = y0 - py if py < y0 else (py - y1 if py > y1 else 0.0)
            if bx_d * bx_d + by_d * by_d >= best_d2:
                continue
            (ax, ay), (bx, by) = self._xy[i - 1], self._xy[i]
            dx, dy = bx - ax, by - ay
            seg2 = dx * dx + dy * dy
            t = 0.0 if seg2 == 0 else max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / seg2))
            along = self.cum[i - 1] + t * (self.cum[i] - self.cum[i - 1])
            if along < start_m:
                along = start_m
                t = (start_m - self.cum[i - 1]) / ((self.cum[i] - self.cum[i - 1]) or 1.0)
            qx, qy = ax + t * dx, ay + t * dy
            d2 = (px - qx) ** 2 + (py - qy) ** 2
            if d2 < best_d2:
                best_d2, best_along = d2, along
        return best_along, math.sqrt(best_d2)

    def stops_along(self, stops):
        """Distance along the line of each stop, never going backwards."""
        out, start = [], 0.0
        for s in stops:
            along, _ = self.project(s["lat"], s["lon"], start)
            out.append(along)
            start = along
        return out

    def simplified(self, tolerance_m=1.5):
        """Douglas-Peucker: drop points that change the drawn line by less than `tolerance_m`.
        Straight runs of a densified line collapse to their end points, so the
        JSON is much smaller while the length (and every along_km) is unchanged."""
        n = len(self._xy)
        if n <= 2:
            return list(self.points)
        keep = [False] * n
        keep[0] = keep[-1] = True
        stack = [(0, n - 1)]
        tol2 = tolerance_m * tolerance_m
        while stack:
            i, j = stack.pop()
            (ax, ay), (bx, by) = self._xy[i], self._xy[j]
            dx, dy = bx - ax, by - ay
            seg2 = dx * dx + dy * dy
            far, far_d2 = -1, tol2
            for k in range(i + 1, j):
                px, py = self._xy[k]
                t = 0.0 if seg2 == 0 else max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / seg2))
                d2 = (px - ax - t * dx) ** 2 + (py - ay - t * dy) ** 2
                if d2 > far_d2:
                    far, far_d2 = k, d2
            if far >= 0:
                keep[far] = True
                stack.append((i, far))
                stack.append((far, j))
        return [p for p, k in zip(self.points, keep) if k]
