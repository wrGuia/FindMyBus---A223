"""Which way a live bus is going, from how its position along the route changes."""
from dataclasses import dataclass, field

from .. import conf


@dataclass
class _Anchor:
    along_m: float
    forward: bool | None          # None until the bus has really moved


@dataclass
class DirectionTracker:
    min_move_m: float = conf.DIRECTION_MIN_MOVE_M
    _anchors: dict = field(default_factory=dict)

    def update(self, bus_id, along_m):
        """Returns True (forward), False (reverse) or None (not known yet).
        The anchor only moves once the bus has moved `min_move_m`, so slow buses still reveal their direction."""
        a = self._anchors.get(bus_id)
        if a is None:
            self._anchors[bus_id] = _Anchor(along_m, None)
            return None
        if abs(along_m - a.along_m) > self.min_move_m:
            a.forward, a.along_m = along_m > a.along_m, along_m
        return a.forward

    def retain(self, bus_ids):
        keep = set(bus_ids)
        for k in [k for k in self._anchors if k not in keep]:
            del self._anchors[k]
