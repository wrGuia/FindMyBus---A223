"""How much to trust a position, from its age (same thresholds as the app's lib/core/freshness.dart)."""
from .. import conf

LIVE, STALE, OFFLINE = "live", "stale", "offline"


def classify(age_s, stale_after=conf.STALE_AFTER_SECONDS, offline_after=conf.OFFLINE_AFTER_SECONDS):
    if age_s >= offline_after:
        return OFFLINE
    if age_s >= stale_after:
        return STALE
    return LIVE
