"""Pure logic (no Django, no network): geometry, ETA, deviation, traffic, freshness.

Each module mirrors the matching file in the Flutter app's lib/core/ so the
server and the app agree on every number they both show.
"""
