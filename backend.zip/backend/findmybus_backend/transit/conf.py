"""Every tunable value in one place. Override any of them with an environment variable."""
import os


def _env(name, default, cast=float):
    raw = os.environ.get(name)
    if raw is None or raw == "":
        return default
    try:
        return cast(raw)
    except ValueError:
        return default


def _flag(name, default):
    return os.environ.get(name, "1" if default else "0").strip().lower() not in ("0", "false", "no", "off")


# ---- Data source ---------------------------------------------------------
#   auto       LA Metro live feed, simulator per route when a route has no live buses (default)
#   live       LA Metro only (a route with no buses in service shows none)
#   simulated  never call LA Metro
DATA_SOURCE = os.environ.get("FINDMYBUS_DATA_SOURCE", "auto").strip().lower()
if DATA_SOURCE not in ("auto", "live", "simulated"):
    DATA_SOURCE = "auto"

METRO_API_BASE = os.environ.get("METRO_API_BASE", "https://api.metro.net").rstrip("/")
METRO_API_TOKEN = os.environ.get("METRO_API_TOKEN", "")          # optional bearer token
METRO_WS_BASE = os.environ.get(
    "METRO_WS_BASE", METRO_API_BASE.replace("https://", "wss://").replace("http://", "ws://"))
HTTP_TIMEOUT = _env("FINDMYBUS_HTTP_TIMEOUT", 6.0)

# Replace the stops stored in the database with LA Metro's official stop list
# for routes that have "use official stops" ticked.
OFFICIAL_STOPS = _flag("FINDMYBUS_OFFICIAL_ROUTES", True)
# Snap hand-entered stops to real roads with the public OSRM server.
ROAD_SNAP = _flag("FINDMYBUS_ROAD_SNAP", True)
# Official stops whose typical gap is wider than this (metres) are joined along the road instead of straight.
SPARSE_STOP_GAP_M = _env("FINDMYBUS_SPARSE_STOP_GAP_M", 600.0)
OSRM_URL = os.environ.get("FINDMYBUS_OSRM_URL", "https://router.project-osrm.org/route/v1/driving/")
# Backup road-routing servers, tried in order when the first one is busy or fails (comma-separated).
OSRM_URLS = [OSRM_URL] + [u.strip() for u in os.environ.get(
    "FINDMYBUS_OSRM_FALLBACKS", "https://routing.openstreetmap.de/routed-car/route/v1/driving/").split(",")
    if u.strip() and u.strip() != OSRM_URL]
GEOMETRY_RETRY_SECONDS = _env("FINDMYBUS_GEOMETRY_RETRY_SECONDS", 120.0)
# Finished road lines are saved here so a restart answers instantly (delete the file to rebuild them).
GEOMETRY_CACHE_FILE = os.environ.get("FINDMYBUS_GEOMETRY_CACHE") or os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "geometry_cache.json")

# ---- Fleet loop ------------------------------------------------------------
TICK_SECONDS = _env("FINDMYBUS_TICK_SECONDS", 3.0)               # LA Metro pushes about every 3 s
REST_BACKOFF_SECONDS = 15.0                                       # after every REST call failed
STREAM_HEALTHY_SECONDS = 30.0                                     # stream counts as up if a frame came this recently
LIVE_KEEP_SECONDS = _env("FINDMYBUS_LIVE_KEEP_SECONDS", 300.0)   # keep (as stale) a vehicle not heard from this long
HISTORY_LENGTH = 60
SIM_BUSES_PER_ROUTE = int(_env("FINDMYBUS_SIM_BUSES_PER_ROUTE", 4, int))

# ---- Freshness (same thresholds as the app) -------------------------------
STALE_AFTER_SECONDS = 45.0
OFFLINE_AFTER_SECONDS = 120.0

# ---- Route deviation -------------------------------------------------------
# A bus is flagged when it is farther than DEVIATION_M from the route line for
# at least DEVIATION_SECONDS.
DEVIATION_M = _env("FINDMYBUS_DEVIATION_M", 250.0)
DEVIATION_SECONDS = _env("FINDMYBUS_DEVIATION_SECONDS", 30.0)

# ---- Delay ------------------------------------------------------------------
DELAY_THRESHOLD_S = 300          # feed schedule delay above this = Delayed
SLOW_BELOW_KMH = 8.0             # a bus crawling this slowly for a while = Delayed
SLOW_SECONDS = 90.0

# ---- Direction detection for live buses ----------------------------------
DIRECTION_MIN_MOVE_M = 20.0

# ---- ETA (same model as the app's lib/core/eta.dart) ----------------------
ETA_FALLBACK_KMH = 18.0
ETA_MIN_KMH = 8.0
ETA_MAX_KMH = 70.0
ETA_DWELL_PER_STOP_S = 15.0
ETA_PASSED_MARGIN_M = 50.0
SPEED_SMOOTHING = 0.3
ARRIVING_M = 150.0               # "arriving now"
ALERT_MIN_M = 100.0              # the app lets the user pick 100 m ... 3 km
ALERT_MAX_M = 3000.0
ALERT_DEFAULT_M = 500.0

# ---- Traffic (same model as the app's lib/core/traffic.dart) --------------
TRAFFIC_BUCKET_M = 300.0
TRAFFIC_INFLUENCE_M = 450.0
TRAFFIC_HEAVY_BELOW_KMH = 12.0
TRAFFIC_LIGHT_BELOW_KMH = 22.0
TRAFFIC_ALPHA = 0.4
TRAFFIC_MEMORY_SECONDS = 8 * 60.0
