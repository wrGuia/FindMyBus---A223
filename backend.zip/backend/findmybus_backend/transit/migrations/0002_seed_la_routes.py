from django.db import migrations


def seed(apps, schema_editor):
    from transit.seed import ROUTES
    Route = apps.get_model("transit", "Route")
    Stop = apps.get_model("transit", "Stop")
    for d in ROUTES:
        if Route.objects.filter(route_id=d["route_id"]).exists():
            continue
        fields = {k: v for k, v in d.items() if k != "stops"}
        route = Route.objects.create(**fields)
        Stop.objects.bulk_create(Stop(route=route, sequence=i + 1, name=n, lat=la, lon=lo)
                                 for i, (n, la, lo) in enumerate(d["stops"]))


def unseed(apps, schema_editor):
    from transit.seed import ROUTES
    apps.get_model("transit", "Route").objects.filter(route_id__in=[d["route_id"] for d in ROUTES]).delete()


class Migration(migrations.Migration):
    dependencies = [("transit", "0001_initial")]
    operations = [migrations.RunPython(seed, unseed)]
