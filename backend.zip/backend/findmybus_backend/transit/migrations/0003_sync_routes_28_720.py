from django.db import migrations


def sync(apps, schema_editor):
    """Replace the stops of routes 720 and 28 with the full LA Metro stop lists (existing databases)."""
    from transit.seed import ROUTES
    Route = apps.get_model("transit", "Route")
    Stop = apps.get_model("transit", "Stop")
    for d in ROUTES:
        if d["code"] not in ("720", "28"):
            continue
        route = Route.objects.filter(route_id=d["route_id"]).first()
        if route is None:
            continue
        for f in ("name", "color", "headsign_fwd", "headsign_rev", "fwd_toward_lat", "fwd_toward_lon",
                  "use_official_stops"):
            setattr(route, f, d[f])
        route.save()
        route.stops.all().delete()
        Stop.objects.bulk_create(Stop(route=route, sequence=i + 1, name=n, lat=la, lon=lo)
                                 for i, (n, la, lo) in enumerate(d["stops"]))


class Migration(migrations.Migration):
    dependencies = [("transit", "0002_seed_la_routes")]
    operations = [migrations.RunPython(sync, migrations.RunPython.noop)]
