from django.db import migrations


def enable(apps, schema_editor):
    """Routes 720 and 28: use LA Metro's official stop positions (the hand-entered ones are hundreds of metres off)."""
    Route = apps.get_model("transit", "Route")
    Route.objects.filter(code__in=("720", "28")).update(use_official_stops=True)


class Migration(migrations.Migration):
    dependencies = [("transit", "0003_sync_routes_28_720")]
    operations = [migrations.RunPython(enable, migrations.RunPython.noop)]
