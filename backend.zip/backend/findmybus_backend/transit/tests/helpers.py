import random
from contextlib import ExitStack
from unittest import mock

from transit import conf
from transit.fleet import service as fleet_service


class FakeStream:
    """Stands in for the LA Metro WebSocket: tests put vehicles in `by_code`."""

    def __init__(self):
        self.by_code = {}
        self.ok = True

    def ensure_started(self, routes):
        pass

    def healthy(self, now=None):
        return self.ok

    def vehicles(self, code, now=None, keep_seconds=None):
        return [dict(v) for v in self.by_code.get(str(code), [])]

    def snapshot(self):
        return {"state": "connected" if self.ok else "disconnected", "last_error": None, "messages": 1,
                "vehicles_by_route": {c: len(v) for c, v in self.by_code.items()}}


def patched_conf(**values):
    """Offline defaults for tests (no LA Metro, no OSRM), plus any overrides."""
    base = {"DATA_SOURCE": "simulated", "ROAD_SNAP": False, "OFFICIAL_STOPS": False}
    base.update(values)
    stack = ExitStack()
    for k, v in base.items():
        stack.enter_context(mock.patch.object(conf, k, v))
    return stack


def make_fleet(t0=1_800_000_000.0, stream=None):
    """A fleet ticked by hand with a fake clock, installed as the process-wide fleet."""
    clock = {"now": t0}
    svc = fleet_service.FleetService(rng=random.Random(7), stream=stream or FakeStream(),
                                     clock=lambda: clock["now"])
    svc.tick()
    fleet_service.set_fleet(svc)

    def advance(seconds, step=3.0):
        end = clock["now"] + seconds
        while clock["now"] < end:
            clock["now"] = min(end, clock["now"] + step)
            svc.tick()
        return svc.snapshot

    return svc, clock, advance
