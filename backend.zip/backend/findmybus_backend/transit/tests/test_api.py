"""The API the Flutter app reads, checked against responses captured by the app (tests/fixtures,
copied from findmybus_flutter_app/test/fixtures) plus the live-data paths."""
import json
from pathlib import Path

from django.contrib.auth.models import User
from django.test import TestCase

from transit.fleet import service as fleet_service
from transit.models import DeviationEvent, Route, Stop

from .helpers import FakeStream, make_fleet, patched_conf

FIXTURES = Path(__file__).parent / "fixtures"
DROPPED = {"crowd"}            # passenger capacity was removed on purpose; the app never read it


def load(name):
    return json.loads((FIXTURES / name).read_text())


def assert_same_shape(test, expected, actual, where="$"):
    """Every key the app saw must still be there with a compatible type (extra keys are fine)."""
    if expected is None or actual is None:
        return
    if isinstance(expected, bool):
        test.assertIsInstance(actual, bool, where)
    elif isinstance(expected, (int, float)):
        test.assertIsInstance(actual, (int, float), where)
        test.assertNotIsInstance(actual, bool, where)
    elif isinstance(expected, str):
        test.assertIsInstance(actual, str, where)
    elif isinstance(expected, list):
        test.assertIsInstance(actual, list, where)
        if expected and actual:
            assert_same_shape(test, expected[0], actual[0], where + "[0]")
    elif isinstance(expected, dict):
        test.assertIsInstance(actual, dict, where)
        for k, v in expected.items():
            if k in DROPPED:
                continue
            test.assertIn(k, actual, f"{where}.{k} missing")
            assert_same_shape(test, v, actual[k], f"{where}.{k}")


class FleetTestCase(TestCase):
    live_mode = "simulated"

    def setUp(self):
        self._conf = patched_conf(DATA_SOURCE=self.live_mode)
        self._conf.__enter__()
        self.stream = FakeStream()
        self.fleet, self.clock, self.advance = make_fleet(stream=self.stream)

    def tearDown(self):
        fleet_service.set_fleet(None)
        self._conf.__exit__(None, None, None)

    def get(self, url):
        resp = self.client.get(url)
        self.assertEqual(resp.status_code, 200, resp.content[:300])
        return resp.json()


class ContractTests(FleetTestCase):
    def test_routes_matches_app_fixture(self):
        body = self.get("/api/routes/")
        assert_same_shape(self, load("routes.json"), body)
        self.assertEqual([r["id"] for r in body["routes"]], ["R1", "R2", "R3"])
        self.assertEqual(body["routes"][0]["code"], "720")
        self.assertEqual(body["routes"][0]["source"], "simulated")

    def test_route_detail_matches_app_fixture(self):
        for rid in ("R1", "R2", "R3"):
            body = self.get(f"/api/route/{rid}/")
            assert_same_shape(self, load(f"route_{rid}.json"), body)
            along = [s["along_km"] for s in body["stops"]]
            self.assertEqual(along, sorted(along))
            self.assertAlmostEqual(along[-1], body["total_km"], places=2)
        # Same stops and distances as the backend the app was built against.
        old = load("route_R1.json")
        new = self.get("/api/route/R1/")
        for a, b in zip(old["stops"], new["stops"]):
            self.assertEqual(a["name"], b["name"])
            self.assertAlmostEqual(a["along_km"], b["along_km"], delta=0.01)

    def test_buses_matches_app_fixture(self):
        for rid in ("R1", "R2", "R3"):
            body = self.get(f"/api/buses/?route={rid}")
            assert_same_shape(self, load(f"buses_{rid}.json"), body)
            self.assertEqual(len(body["buses"]), 4)
            for b in body["buses"]:
                self.assertNotIn("crowd", b)
                self.assertIn(b["direction"], ("fwd", "rev"))
                self.assertIn(b["status"], ("On Time", "Delayed"))
                self.assertLessEqual(b["updated_at"], body["server_time"])

    def test_unknown_route_is_404(self):
        self.assertEqual(self.client.get("/api/route/R9/").status_code, 404)
        self.assertEqual(self.client.get("/api/buses/?route=R9").status_code, 404)

    def test_status_has_mode(self):
        self.assertEqual(self.get("/api/status/")["mode"], "simulated")

    def test_cors_for_configured_origin(self):
        with self.settings(CORS_ALLOWED_ORIGINS=["http://localhost:8550"]):
            resp = self.client.get("/api/routes/", HTTP_ORIGIN="http://localhost:8550")
        self.assertEqual(resp["Access-Control-Allow-Origin"], "http://localhost:8550")


class ArrivalsTests(FleetTestCase):
    def test_arrivals_sorted_and_use_chosen_distance(self):
        self.advance(30)
        body = self.get("/api/arrivals/?route=R1&stop=3&dir=both&radius_m=3000")
        rem = [a["remaining_m"] for a in body["arrivals"]]
        self.assertEqual(rem, sorted(rem))
        for a in body["arrivals"]:
            self.assertEqual(a["near"], a["remaining_m"] <= 3000)
            self.assertGreaterEqual(a["eta_s"], 0)

    def test_radius_is_clamped_and_km_still_accepted(self):
        self.assertEqual(self.get("/api/arrivals/?route=R1&stop=0&radius_m=5")["radius_m"], 100)
        self.assertEqual(self.get("/api/arrivals/?route=R1&stop=0&radius=0.75")["radius_m"], 750)
        self.assertEqual(self.client.get("/api/arrivals/?route=R1&stop=99").status_code, 400)

    def test_eta_for_one_bus(self):
        body = self.get("/api/eta/?bus=Sim%2001&stop=2")
        self.assertEqual(body["bus_id"], "Sim 01")
        self.assertIn("eta_s", body)


class SimulatorBehaviourTests(FleetTestCase):
    def test_buses_move_and_traffic_appears(self):
        before = {b["id"]: b["along_km"] for b in self.get("/api/buses/?route=R1")["buses"]}
        snap = self.advance(15 * 60)
        after = {b["id"]: b["along_km"] for b in self.get("/api/buses/?route=R1")["buses"]}
        self.assertTrue(any(abs(after[k] - before[k]) > 0.1 for k in before))
        levels = {s["level"] for s in self.get("/api/traffic/?route=R1")["segments"]}
        self.assertTrue(levels & {"clear", "light", "heavy"})
        self.assertTrue(snap.history)

    def test_detour_is_detected_and_logged(self):
        bus = self.fleet._sim["Sim 01"]
        bus.detour_until = self.clock["now"] + 600
        bus.detour_offset_m = 450
        self.advance(20)
        self.assertFalse(next(b for b in self.get("/api/buses/?route=R1")["buses"] if b["id"] == "Sim 01")["deviation"])
        self.advance(20)
        b = next(b for b in self.get("/api/buses/?route=R1")["buses"] if b["id"] == "Sim 01")
        self.assertTrue(b["deviation"])
        self.assertEqual(b["status"], "Delayed")
        ev = DeviationEvent.objects.get(bus_id="Sim 01")
        self.assertIsNone(ev.ended_at)
        self.assertGreater(ev.max_offset_m, 250)
        bus.detour_until = 0
        self.advance(6)
        ev.refresh_from_db()
        self.assertIsNotNone(ev.ended_at)


class LiveFeedTests(FleetTestCase):
    live_mode = "auto"

    def put(self, vid, along_m, speed=None, reported=None, offset_m=0):
        route = self.fleet._routes["R1"]
        lat, lon = route.line.offset_point(along_m, offset_m) if offset_m else route.line.point_at(along_m)
        v = {"id": vid, "lat": lat, "lon": lon, "speed_kmh": speed, "delay_s": None,
             "reported_at": reported if reported is not None else self.clock["now"], "trip_id": None,
             "received_at": self.clock["now"]}
        self.stream.by_code["720"] = [x for x in self.stream.by_code.get("720", []) if x["id"] != vid] + [v]

    def bus(self, rid="R1"):
        return self.get(f"/api/buses/?route={rid}")

    def test_live_route_replaces_simulator_and_detects_direction(self):
        self.put("5123", 5000, speed=None)
        self.advance(3)
        body = self.bus()
        self.assertEqual(body["source"]["state"], "live")
        self.assertEqual([b["id"] for b in body["buses"]], ["Bus 5123"])
        b = body["buses"][0]
        self.assertTrue(b["live"])
        self.assertIsNone(b["direction"])
        self.assertEqual(b["heading"], "Detecting direction…")
        self.assertEqual(self.bus("R2")["source"]["state"], "simulated")     # other routes fall back
        self.assertEqual(self.get("/api/routes/")["routes"][0]["source"], "live")

        self.put("5123", 4900)                                               # moved back toward Santa Monica
        self.advance(3)
        b = self.bus()["buses"][0]
        self.assertEqual(b["direction"], "rev")
        self.assertEqual(b["heading"], "To Santa Monica")
        self.assertAlmostEqual(b["along_km"], 4.9, delta=0.01)
        self.assertAlmostEqual(b["speed_kmh"], 100 / 3 * 3.6, delta=1)       # derived: 100 m in 3 s
        self.assertEqual(b["next_stop_index"], 0)

    def test_old_position_is_marked_stale_not_live(self):
        self.put("7", 8000, speed=20, reported=self.clock["now"] - 60)
        self.advance(3)
        b = self.bus()["buses"][0]
        self.assertEqual(b["freshness"], "stale")
        self.assertLess(b["updated_at"], self.clock["now"] - 59)

    def test_live_only_mode_shows_no_fake_buses(self):
        with patched_conf(DATA_SOURCE="live"):
            self.advance(3)
            body = self.bus("R2")
        self.assertEqual(body["buses"], [])
        self.assertEqual(body["source"]["state"], "empty")


class AdminTests(FleetTestCase):
    def test_dashboard_needs_staff_login(self):
        self.assertEqual(self.client.get("/dashboard/").status_code, 302)
        self.assertEqual(self.client.get("/api/fleet/").status_code, 401)
        User.objects.create_user("ops", password="pw-123456", is_staff=True)
        self.client.login(username="ops", password="pw-123456")
        self.assertEqual(self.client.get("/dashboard/").status_code, 200)
        body = self.get("/api/fleet/")
        self.assertEqual(len(body["routes"]), 3)
        self.assertIn("traffic", body["routes"][0])
        self.assertEqual(len(body["buses"]), 12)

    def test_route_edits_reach_the_api(self):
        r = Route.objects.create(route_id="R4", code="4", name="4 - Santa Monica Blvd", color="#3366CC",
                                 headsign_fwd="Downtown", headsign_rev="Santa Monica", sort_order=4)
        Stop.objects.create(route=r, sequence=1, name="A", lat=34.09, lon=-118.40)
        Stop.objects.create(route=r, sequence=2, name="B", lat=34.09, lon=-118.30)
        self.advance(3)
        ids = [x["id"] for x in self.get("/api/routes/")["routes"]]
        self.assertEqual(ids, ["R1", "R2", "R3", "R4"])
        self.assertEqual(len(self.get("/api/buses/?route=R4")["buses"]), 4)
        r.active = False
        r.save()
        self.advance(3)
        self.assertEqual(self.client.get("/api/route/R4/").status_code, 404)
