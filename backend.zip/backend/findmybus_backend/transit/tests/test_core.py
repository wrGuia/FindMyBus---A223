from django.test import SimpleTestCase

from transit.core import freshness, traffic
from transit.core.deviation import DeviationTracker
from transit.core.direction import DirectionTracker
from transit.core.eta import SpeedSmoother, eta_to_stop
from transit.core.geo import Polyline, haversine_m

LINE = [(34.0185, -118.4935), (34.058, -118.443), (34.067, -118.4003), (34.0631, -118.3612)]


class GeoTests(SimpleTestCase):
    def test_length_matches_haversine_sum(self):
        line = Polyline(LINE)
        expected = sum(haversine_m(*a, *b) for a, b in zip(LINE, LINE[1:]))
        self.assertAlmostEqual(line.length_m, expected, places=3)

    def test_project_round_trips_point_at(self):
        line = Polyline(LINE)
        for d in (0, 1234, 6000, 9000, line.length_m):
            along, off = line.project(*line.point_at(d))
            self.assertAlmostEqual(along, d, delta=1.0)
            self.assertLess(off, 1.0)

    def test_offset_point_is_off_the_line_at_same_place(self):
        line = Polyline(LINE)
        lat, lon = line.offset_point(3000, 400)
        along, off = line.project(lat, lon)
        self.assertAlmostEqual(off, 400, delta=5)
        self.assertAlmostEqual(along, 3000, delta=5)

    def test_simplify_keeps_length_of_densified_line(self):
        dense = []
        for a, b in zip(LINE, LINE[1:]):
            for k in range(50):
                f = k / 50
                dense.append((a[0] + f * (b[0] - a[0]), a[1] + f * (b[1] - a[1])))
        dense.append(LINE[-1])
        line = Polyline(dense)
        simple = line.simplified()
        self.assertEqual(len(simple), len(LINE))
        self.assertAlmostEqual(Polyline(simple).length_m, line.length_m, delta=0.5)

    def test_stops_along_never_go_backwards(self):
        out_and_back = LINE + list(reversed(LINE[:-1]))       # the same street both ways
        line = Polyline(out_and_back)
        along = line.stops_along([{"lat": p[0], "lon": p[1]} for p in out_and_back])
        self.assertEqual(along, sorted(along))
        self.assertAlmostEqual(along[-1], line.length_m, delta=1)


class EtaTests(SimpleTestCase):
    def test_forward_eta_with_dwell(self):
        r = eta_to_stop(1000, 4600, True, 36.0, [0, 2000, 3000, 4600, 6000])
        self.assertFalse(r.passed)
        self.assertEqual(r.remaining_m, 3600)
        self.assertEqual(r.stops_away, 2)
        self.assertAlmostEqual(r.eta_s, 3600 / 10 + 2 * 15)

    def test_reverse_and_passed(self):
        self.assertEqual(eta_to_stop(5000, 3000, False, 36.0).remaining_m, 2000)
        self.assertTrue(eta_to_stop(5000, 3000, True, 36.0).passed)
        self.assertFalse(eta_to_stop(3040, 3000, True, 36.0).passed)    # within the 50 m margin

    def test_speed_is_clamped_and_has_fallback(self):
        self.assertAlmostEqual(eta_to_stop(0, 1800, True, None).eta_s, 1800 / (18 / 3.6))
        self.assertAlmostEqual(eta_to_stop(0, 800, True, 0.5).eta_s, 800 / (8 / 3.6))

    def test_smoother(self):
        s = SpeedSmoother(alpha=0.5)
        self.assertEqual(s.add("a", 20), 20)
        self.assertEqual(s.add("a", 40), 30)
        self.assertEqual(s.add("a", None), 30)
        s.retain([])
        self.assertIsNone(s.get("a"))


class DeviationTests(SimpleTestCase):
    def test_needs_distance_and_duration(self):
        t = DeviationTracker(threshold_m=250, min_seconds=30)
        self.assertFalse(t.update("b", 400, 0).flagged)
        self.assertFalse(t.update("b", 400, 20).flagged)
        ch = t.update("b", 420, 31)
        self.assertTrue(ch.flagged and ch.started)
        self.assertEqual(ch.off_since, 0)
        self.assertFalse(t.update("b", 430, 40).started)                 # reported once
        ch = t.update("b", 10, 50)
        self.assertTrue(ch.ended)
        self.assertEqual(ch.max_offset_m, 430)
        self.assertFalse(t.is_flagged("b"))

    def test_brief_excursion_is_ignored(self):
        t = DeviationTracker(threshold_m=250, min_seconds=30)
        t.update("b", 400, 0)
        t.update("b", 100, 10)
        self.assertFalse(t.update("b", 400, 35).flagged)


class TrafficTests(SimpleTestCase):
    def test_levels_and_expiry(self):
        m = traffic.TrafficModel(3000)
        m.observe(1500, 8, at=0)
        self.assertEqual(m.level_at(1500, 1), traffic.HEAVY)
        self.assertEqual(m.level_at(2900, 1), traffic.UNKNOWN)
        for t in (10, 20, 30):
            m.observe(1500, 30, at=t)
        self.assertIn(m.level_at(1500, 31), (traffic.LIGHT, traffic.CLEAR))
        self.assertEqual(m.level_at(1500, 30 + 9 * 60), traffic.UNKNOWN)

    def test_segments_cover_route(self):
        m = traffic.TrafficModel(3000)
        m.observe(600, 15, at=0)
        segs = m.segments(1)
        self.assertEqual(segs[0][0], 0)
        self.assertEqual(segs[-1][1], 3000)
        self.assertIn(traffic.LIGHT, [s[2] for s in segs])


class SmallTests(SimpleTestCase):
    def test_freshness(self):
        self.assertEqual(freshness.classify(10), freshness.LIVE)
        self.assertEqual(freshness.classify(50), freshness.STALE)
        self.assertEqual(freshness.classify(130), freshness.OFFLINE)

    def test_direction(self):
        d = DirectionTracker(min_move_m=20)
        self.assertIsNone(d.update("b", 100))
        self.assertIsNone(d.update("b", 110))
        self.assertTrue(d.update("b", 130))
        self.assertTrue(d.update("b", 125))                              # jitter doesn't flip it
        self.assertFalse(d.update("b", 90))
