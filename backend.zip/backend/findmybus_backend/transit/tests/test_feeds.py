import json

from django.test import SimpleTestCase

from transit.feeds import metro, official
from transit.feeds.stream import MetroStream


class MetroParserTests(SimpleTestCase):
    def test_flat_record(self):
        v = metro.parse_vehicle({"vehicle_id": "5123", "latitude": "34.06", "longitude": "-118.30",
                                 "speed": 5, "timestamp": 1_800_000_000_000, "route_code": "720-13168"})
        self.assertEqual(v["id"], "5123")
        self.assertEqual(v["speed_kmh"], 18.0)
        self.assertEqual(v["reported_at"], 1_800_000_000)

    def test_gtfs_nested_record(self):
        rec = {"id": "x", "vehicle": {"vehicle": {"id": "777"}, "trip": {"route_id": "204-13168", "trip_id": "t1"},
                                      "position": {"latitude": 34.0, "longitude": -118.29}}}
        v = metro.parse_vehicle(rec)
        self.assertEqual(v["id"], "777")
        self.assertIsNone(v["speed_kmh"])
        self.assertEqual(metro.route_code_of(rec), "204")

    def test_rejects_null_island_and_dedupes(self):
        payload = {"items": [{"vehicle_id": 1, "latitude": 0, "longitude": 0},
                             {"vehicle_id": 2, "latitude": 34, "longitude": -118},
                             {"vehicle_id": 2, "latitude": 34, "longitude": -118}]}
        self.assertEqual([v["id"] for v in metro.parse_payload(payload)], ["2"])


class OfficialStopsTests(SimpleTestCase):
    def rows(self, direction, pts):
        return [{"day_type": "weekday", "route_id": "720", "direction_id": direction, "stop_sequence": i,
                 "stop_name": f"S{direction}-{i}",
                 "geometry": json.dumps({"type": "Point", "coordinates": [lon, lat]})}
                for i, (lat, lon) in enumerate(pts)]

    def test_picks_the_pattern_heading_toward_the_point(self):
        west_to_east = [(34.05, -118.50 + i * 0.02) for i in range(6)]
        rows = self.rows(0, list(reversed(west_to_east))) + self.rows(1, west_to_east[:5])
        stops = official.build_stops(rows, toward=(34.05, -118.20))
        self.assertEqual([s["name"] for s in stops], [f"S1-{i}" for i in range(5)])

    def test_flips_a_single_pattern_that_runs_the_other_way(self):
        west_to_east = [(34.05, -118.50 + i * 0.02) for i in range(6)]
        stops = official.build_stops(self.rows(0, list(reversed(west_to_east))), toward=(34.05, -118.20))
        self.assertEqual(len(stops), 6)
        self.assertLess(stops[0]["lon"], stops[-1]["lon"])


class OfficialTerminalTests(SimpleTestCase):
    """The official pattern must really run between the route's first and last stop."""

    def rows(self, route_id, direction, pts):
        return [{"day_type": "weekday", "route_id": route_id, "direction_id": direction, "stop_sequence": i,
                 "stop_name": f"{route_id}-{i}",
                 "geometry": json.dumps({"type": "Point", "coordinates": [lon, lat]})}
                for i, (lat, lon) in enumerate(pts)]

    def line(self, n, start=0):
        return [(34.054, -118.4155 + (start + i) * 0.003) for i in range(n)]

    def test_short_turn_pattern_alone_is_rejected(self):
        full = self.line(60)
        rows = self.rows("28-A", 0, full[20:39]) + self.rows("28-B", 1, full[20:39][::-1])
        self.assertIsNone(official.build_stops(rows, terminals=(full[0], full[-1])))

    def test_full_pattern_wins_over_a_short_one(self):
        full = self.line(60)
        rows = self.rows("28-A", 0, full[20:39]) + self.rows("28-C", 0, full)
        stops = official.build_stops(rows, terminals=(full[0], full[-1]))
        self.assertEqual(len(stops), 60)

    def test_pattern_running_past_a_terminal_is_cut_there(self):
        long_line = self.line(90)
        stops = official.build_stops(self.rows("720-A", 1, long_line[::-1]), terminals=(long_line[0], long_line[59]))
        self.assertEqual(len(stops), 60)
        self.assertLess(stops[0]["lon"], stops[-1]["lon"])        # always first terminal -> last terminal


class StreamTests(SimpleTestCase):
    def test_handle_frames(self):
        s = MetroStream()
        s.handle(json.dumps({"vehicle": {"vehicle": {"id": "9"}, "trip": {"route_id": "720"},
                                         "position": {"latitude": 34.06, "longitude": -118.3}}}), now=100)
        s.handle("Error: bad route", now=101)
        s.handle(b"not json", now=102)
        self.assertEqual(len(s.vehicles("720", now=110)), 1)
        self.assertEqual(s.vehicles("720", now=1000, keep_seconds=300), [])
        snap = s.snapshot()
        self.assertEqual(snap["messages"], 3)
        self.assertEqual(snap["errors"], 2)


class StopListSnapTests(SimpleTestCase):
    """snap_stop_list / pin_stops_to_line with a fake OSRM server."""

    class FakeOSRM:
        """Roads: one straight street along lat 34.05. Waypoints snap onto it; a request that
        includes the 'bad' stop (lon -118.30) is answered with a long freeway-style detour."""
        def __init__(self):
            self.calls = []

        def get(self, url, params=None, timeout=None):
            coords = [tuple(map(float, c.split(","))) for c in url.rsplit("/", 1)[1].split(";")]
            self.calls.append(params)
            detour = any(abs(lon + 118.30) < 1e-9 for lon, _ in coords) and len(coords) > 2
            line = [[lon, 34.05] for lon, _ in coords]
            if detour:
                line = [[coords[0][0], 34.05], [coords[0][0], 34.2], [coords[-1][0], 34.2], [coords[-1][0], 34.05]]
            outer = self

            class R:
                def raise_for_status(self): pass
                def json(self): return {"code": "Ok", "routes": [{"geometry": {"coordinates": line}}]}
            return R()

    def stops(self, n=6):
        return [{"name": f"s{i}", "lat": 34.0503, "lon": -118.40 + i * 0.02} for i in range(n)]

    def test_snaps_to_street_and_uses_direction(self):
        from transit.feeds import osrm
        fake = self.FakeOSRM()
        pts, ok = osrm.snap_stop_list(self.stops(), session=fake, pause_s=0)
        self.assertTrue(ok)
        self.assertTrue(all(abs(lat - 34.05) < 1e-9 for lat, _ in pts))
        self.assertIn("bearings", fake.calls[0])                    # direction-constrained first
        self.assertEqual(fake.calls[0]["bearings"].split(";")[0].split(",")[0], "90")   # heading east

    def test_detour_chunk_is_split_until_it_snaps_cleanly(self):
        from transit.feeds import osrm
        stops = self.stops()
        stops[2]["lon"] = -118.30
        pts, ok = osrm.snap_stop_list(stops, session=self.FakeOSRM(), pause_s=0)
        self.assertTrue(ok)                                         # short stretches snap fine
        self.assertTrue(all(lat < 34.07 for lat, _ in pts))         # never took the detour

    def test_block_loop_inside_a_long_chunk_is_caught_per_leg(self):
        from transit.core.geo import haversine_m
        from transit.feeds import osrm

        class LoopOSRM:
            def get(self, url, params=None, timeout=None):
                pts = [tuple(map(float, c.split(","))) for c in url.rsplit("/", 1)[1].split(";")]
                legs = []
                for a, b in zip(pts, pts[1:]):
                    d = haversine_m(34.06, a[0], 34.06, b[0])
                    legs.append({"distance": d + (600 if abs(b[0] + 118.344) < 1e-9 else 0)})

                class R:
                    def raise_for_status(self): pass
                    def json(self_):
                        return {"code": "Ok", "routes": [{"geometry": {"coordinates": [[lo, 34.06] for lo, _ in pts]},
                                                           "legs": legs}]}
                return R()

        stops = [{"name": f"s{i}", "lat": 34.06, "lon": -118.36 + i * 0.004} for i in range(9)]
        stats = {}
        _, ok = osrm.snap_stop_list(stops, session=LoopOSRM(), pause_s=0, stats=stats)
        self.assertFalse(ok)
        self.assertEqual(stats["bad_pairs"], ["s3 -> s4"])           # only the looping leg stays straight

    def test_pin_moves_stops_onto_the_line(self):
        from transit.feeds import osrm
        line = [(34.05, -118.40), (34.05, -118.30)]
        out = osrm.pin_stops_to_line([{"name": "a", "lat": 34.0512, "lon": -118.35},
                                      {"name": "far", "lat": 34.10, "lon": -118.32}], line)
        self.assertAlmostEqual(out[0]["lat"], 34.05, places=5)
        self.assertEqual(out[1]["lat"], 34.10)                      # too far: left alone


class MatchStopsTests(SimpleTestCase):
    def rows(self, names_pts, direction=0):
        return [{"day_type": "weekday", "route_id": "28-1", "direction_id": direction, "stop_sequence": i + 1,
                 "stop_name": n, "stop_lat": la, "stop_lon": lo} for i, (n, la, lo) in enumerate(names_pts)]

    def test_exact_positions_by_name(self):
        pts = [(f"Olympic / S{i}", 34.05, -118.40 + i * 0.01) for i in range(6)]
        mine = [{"name": "Olympic / S2", "lat": 34.0560, "lon": -118.3790},      # ~120 m off
                {"name": "Olympic  /  s4", "lat": 34.0, "lon": -118.0},          # same name, other spelling
                {"name": "Nowhere", "lat": 34.1, "lon": -118.3}]
        out, n = official.match_stops(self.rows(pts), mine)
        self.assertEqual(n, 1)                         # S4 is too far from its entered position (>3 km)
        self.assertAlmostEqual(out[0]["lon"], -118.38, places=6)
        self.assertEqual(out[0]["lat"], 34.05)
        self.assertEqual(out[2]["lat"], 34.1)          # no namesake: untouched

    def test_repeated_name_uses_two_official_stops(self):
        pts = [("5th / Colorado", 34.0143, -118.4915), ("5th / Colorado", 34.0146, -118.4912)] + \
              [(f"X{i}", 34.02 + i * 0.001, -118.49) for i in range(5)]
        mine = [{"name": "5th / Colorado", "lat": 34.0143, "lon": -118.4915},
                {"name": "5th / Colorado", "lat": 34.0143, "lon": -118.4915}]
        out, n = official.match_stops(self.rows(pts), mine)
        self.assertEqual(n, 2)
        self.assertNotEqual((out[0]["lat"], out[0]["lon"]), (out[1]["lat"], out[1]["lon"]))
