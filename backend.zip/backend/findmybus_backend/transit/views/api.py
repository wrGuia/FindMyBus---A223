"""Public JSON API for the Flutter app (read-only, no login).

Contract: the app's lib/data/api_client.dart and lib/data/models.dart.
    GET /api/routes/                 route list (no geometry)
    GET /api/route/<id>/             one route: stops with along_km, path, current buses
    GET /api/buses/?route=<id>       light poll: current buses of one route
    GET /api/status/                 connection check and diagnostics
Extra endpoints (not used by the app yet, same maths as the app):
    GET /api/arrivals/?route=&stop=&dir=fwd|rev|both&radius_m=   next buses to a stop
    GET /api/eta/?bus=&stop=                                      one bus to one stop
    GET /api/traffic/?route=                                      red/yellow/clear stretches
"""
from django.http import JsonResponse
from django.views.decorators.http import require_GET

from .. import conf
from ..core import freshness
from ..core.eta import eta_to_stop
from ..fleet.service import get_fleet

_NO_STORE = {"Cache-Control": "no-store"}


def _now():
    return get_fleet().clock()


def _json(data, status=200):
    resp = JsonResponse(data, status=status, json_dumps_params={"separators": (",", ":")})
    for k, v in _NO_STORE.items():
        resp[k] = v
    return resp


def _error(msg, status):
    return _json({"error": msg}, status)


def source_info(snap, route_id=None):
    """What the app shows on its Live / Simulated pill."""
    rids = [route_id] if route_id else list(snap.routes)
    states = [snap.sources.get(r) for r in rids]
    live_n, empty_n = states.count("live"), states.count("empty")
    if rids and live_n == len(rids):
        st = "live"
    elif live_n:
        st = "mixed"
    elif empty_n:
        st = "empty"
    else:
        st = "simulated"
    return {"state": st, "live_routes": live_n, "total_routes": len(rids),
            "mode": conf.DATA_SOURCE, "reason": None if st == "live" else snap.reason}


def _route_or_404(snap, route_id):
    return snap.routes.get(route_id)


@require_GET
def routes(request):
    snap = get_fleet().snapshot
    return _json({"routes": [{
        "id": r.id, "code": r.code, "name": r.name, "color": r.rgb, "headsigns": r.headsigns,
        "stops": r.stop_names, "buses": len(snap.buses.get(rid, [])),
        "source": source_info(snap, rid)["state"],
    } for rid, r in snap.routes.items()], "server_time": _now()})


@require_GET
def route_detail(request, route_id):
    snap = get_fleet().snapshot
    r = _route_or_404(snap, route_id)
    if r is None:
        return _error("unknown route", 404)
    return _json({
        "route_id": r.id, "code": r.code, "name": r.name, "headsigns": r.headsigns, "color": r.rgb,
        "stops": r.stops_payload, "path": r.path,
        "total_km": round(r.length_m / 1000, 4), "road_snapped": r.geometry.road_snapped,
        "official_stops": r.geometry.official,
        "source": source_info(snap, r.id),
        "buses": snap.buses.get(r.id, []),
        "server_time": _now(),
    })


@require_GET
def buses(request):
    snap = get_fleet().snapshot
    route_id = request.GET.get("route")
    if route_id is None:
        return _json({"route_id": None, "source": source_info(snap),
                      "buses": [b for lst in snap.buses.values() for b in lst], "server_time": _now()})
    if route_id not in snap.routes:
        return _error("unknown route", 404)
    return _json({"route_id": route_id, "source": source_info(snap, route_id),
                  "buses": snap.buses.get(route_id, []), "server_time": _now()})


@require_GET
def status(request):
    fleet = get_fleet()
    return _json(fleet.diagnostics())


def _stop_index(request, route):
    try:
        i = int(request.GET.get("stop", ""))
    except ValueError:
        return None
    return i if 0 <= i < len(route.stops) else None


def _eta_payload(route, bus, state, stop_idx):
    forward = state.direction != "rev"
    res = eta_to_stop(state.along_m, route.stops_along[stop_idx], forward, state.smoothed_kmh, route.stops_along)
    return res, {
        "bus_id": bus["id"], "direction": state.direction, "heading": bus["heading"],
        "remaining_m": round(res.remaining_m), "remaining_km": round(res.remaining_m / 1000, 3),
        "eta_s": round(res.eta_s), "eta_min": round(res.eta_s / 60, 1), "stops_away": res.stops_away,
        "passed": res.passed, "status": bus["status"], "deviation": bus["deviation"],
        "live": bus["live"], "freshness": state.freshness,
        "arriving": not res.passed and res.remaining_m <= conf.ARRIVING_M,
    }


@require_GET
def arrivals(request):
    """Buses still heading to a stop, nearest first. `near` uses the distance the passenger picked."""
    snap = get_fleet().snapshot
    route = _route_or_404(snap, request.GET.get("route"))
    if route is None:
        return _error("unknown route", 404)
    stop_idx = _stop_index(request, route)
    if stop_idx is None:
        return _error("stop must be an index into the route's stops", 400)
    direction = request.GET.get("dir", "both")
    if direction not in ("fwd", "rev", "both"):
        return _error("dir must be fwd, rev or both", 400)
    try:
        if "radius_m" in request.GET:
            radius_m = float(request.GET["radius_m"])
        else:                                                   # older clients send km
            radius_m = float(request.GET.get("radius", conf.ALERT_DEFAULT_M / 1000)) * 1000
    except ValueError:
        return _error("bad radius", 400)
    radius_m = max(conf.ALERT_MIN_M, min(conf.ALERT_MAX_M, radius_m))

    out = []
    for bus in snap.buses.get(route.id, []):
        st = snap.states[bus["id"]]
        # Unknown direction or no recent position: we can't say if it is coming.
        if st.direction is None or st.freshness == freshness.OFFLINE:
            continue
        if direction != "both" and st.direction != direction:
            continue
        res, row = _eta_payload(route, bus, st, stop_idx)
        if res.passed:
            continue
        row["near"] = res.remaining_m <= radius_m
        out.append(row)
    out.sort(key=lambda a: a["remaining_m"])
    return _json({"route_id": route.id, "stop_index": stop_idx, "stop_name": route.stops[stop_idx]["name"],
                  "direction": direction, "radius_m": radius_m, "arrivals": out, "server_time": _now()})


@require_GET
def eta(request):
    snap = get_fleet().snapshot
    bus_id = request.GET.get("bus")
    st = snap.states.get(bus_id)
    if st is None:
        return _error("unknown bus", 404)
    route = snap.routes[st.route_id]
    stop_idx = _stop_index(request, route)
    if stop_idx is None:
        return _error("stop must be an index into the route's stops", 400)
    bus = next(b for b in snap.buses[route.id] if b["id"] == bus_id)
    _, row = _eta_payload(route, bus, st, stop_idx)
    row.update(stop_index=stop_idx, stop_name=route.stops[stop_idx]["name"], server_time=_now())
    return _json(row)


@require_GET
def traffic_view(request):
    snap = get_fleet().snapshot
    route = _route_or_404(snap, request.GET.get("route"))
    if route is None:
        return _error("unknown route", 404)
    return _json({
        "route_id": route.id, "bucket_m": conf.TRAFFIC_BUCKET_M,
        "thresholds_kmh": {"heavy_below": conf.TRAFFIC_HEAVY_BELOW_KMH, "light_below": conf.TRAFFIC_LIGHT_BELOW_KMH},
        "segments": [{"start_km": round(a / 1000, 3), "end_km": round(b / 1000, 3), "level": lvl}
                     for a, b, lvl in snap.traffic.get(route.id, [])],
        "server_time": _now(),
    })
