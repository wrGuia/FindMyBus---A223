"""Admin web dashboard (live fleet map, traffic, delays and deviations)."""
from functools import wraps

from django.contrib.auth.decorators import user_passes_test
from django.http import JsonResponse
from django.shortcuts import render
from django.urls import reverse
from django.utils import timezone

from ..fleet.service import get_fleet
from ..models import DeviationEvent
from .api import source_info


def staff_api(view):
    @wraps(view)
    def wrapper(request, *args, **kwargs):
        if not (request.user.is_authenticated and request.user.is_staff):
            return JsonResponse({"error": "authentication required"}, status=401)
        return view(request, *args, **kwargs)
    return wrapper


def home(request):
    snap = get_fleet().snapshot
    all_buses = [b for lst in snap.buses.values() for b in lst]
    return render(request, "transit/home.html", {
        "routes": len(snap.routes),
        "bus_count": len(all_buses),
        "on_time": sum(1 for b in all_buses if b["status"] == "On Time"),
        "source": source_info(snap),
    })


@user_passes_test(lambda u: u.is_active and u.is_staff, login_url="login")
def dashboard(request):
    snap = get_fleet().snapshot
    return render(request, "transit/dashboard.html", {
        "routes": [{"id": r.id, "name": r.name} for r in snap.routes.values()],
        "config": {"fleetApi": reverse("api_fleet"), "statusUrl": reverse("api_status"), "refreshMs": 3000},
    })


@staff_api
def fleet_api(request):
    snap = get_fleet().snapshot
    recent = DeviationEvent.objects.all()[:25]
    return JsonResponse({
        "routes": [{"id": r.id, "name": r.name, "color": r.rgb, "path": r.path, "stops": r.stops_payload,
                    "source": snap.sources.get(rid),
                    "traffic": [{"start_km": round(a / 1000, 3), "end_km": round(b / 1000, 3), "level": lvl}
                                for a, b, lvl in snap.traffic.get(rid, [])]}
                   for rid, r in snap.routes.items()],
        "buses": [b for lst in snap.buses.values() for b in lst],
        "history": snap.history,
        "source": source_info(snap),
        "deviations": [{
            "bus_id": e.bus_id, "route_name": e.route_name, "live": e.live,
            "started": timezone.localtime(e.started_at).strftime("%b %d, %H:%M:%S"),
            "duration_s": round(e.duration_s) if e.duration_s is not None else None,
            "max_offset_m": round(e.max_offset_m),
        } for e in recent],
        "server_time": get_fleet().clock(),
    })
