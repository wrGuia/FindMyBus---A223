from django.apps import AppConfig


class TransitConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "transit"
    verbose_name = "Transit"

    def ready(self):
        from . import signals  # noqa: F401  (reload the fleet when routes change)
