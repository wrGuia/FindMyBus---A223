"""Tiny CORS middleware for the public, read-only passenger API.

No third-party package needed. Only /api/ paths get CORS headers, and
credentials (cookies) are never allowed, so the admin-only /api/fleet/
endpoint stays protected by its session cookie.

Configure with FINDMYBUS_CORS_ORIGINS (comma-separated exact origins, e.g.
"https://my-flet-app.example.com,http://localhost:8550"). "*" allows any
origin (fine for these public GET endpoints, but prefer exact origins).
"""
from django.conf import settings
from django.http import HttpResponse

ALLOWED_METHODS = "GET, OPTIONS"
ALLOWED_HEADERS = "Content-Type, Authorization"


class ApiCorsMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def _allowed_origin(self, request):
        origin = request.headers.get("Origin")
        if not origin:
            return None
        allowed = getattr(settings, "CORS_ALLOWED_ORIGINS", [])
        if "*" in allowed:
            return "*"
        return origin if origin in allowed else None

    def __call__(self, request):
        if not request.path.startswith("/api/"):
            return self.get_response(request)

        origin = self._allowed_origin(request)

        # Preflight
        if request.method == "OPTIONS" and "Access-Control-Request-Method" in request.headers:
            response = HttpResponse(status=204)
        else:
            response = self.get_response(request)

        if origin:
            response["Access-Control-Allow-Origin"] = origin
            response["Access-Control-Allow-Methods"] = ALLOWED_METHODS
            response["Access-Control-Allow-Headers"] = ALLOWED_HEADERS
            response["Access-Control-Max-Age"] = "600"
            if origin != "*":
                response["Vary"] = "Origin"
        return response
