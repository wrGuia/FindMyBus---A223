from django.contrib import admin

from .models import DeviationEvent, Route, Stop


class StopInline(admin.TabularInline):
    model = Stop
    extra = 1
    fields = ("sequence", "name", "lat", "lon")


@admin.register(Route)
class RouteAdmin(admin.ModelAdmin):
    list_display = ("route_id", "code", "name", "color", "use_official_stops", "active", "sort_order")
    list_editable = ("active", "sort_order")
    search_fields = ("route_id", "code", "name")
    inlines = [StopInline]
    fieldsets = (
        (None, {"fields": ("route_id", "code", "agency", "name", "color", "active", "sort_order")}),
        ("Directions", {"fields": ("headsign_fwd", "headsign_rev", ("fwd_toward_lat", "fwd_toward_lon"))}),
        ("Stops", {"fields": ("use_official_stops",)}),
    )


@admin.register(DeviationEvent)
class DeviationEventAdmin(admin.ModelAdmin):
    list_display = ("bus_id", "route_name", "live", "started_at", "ended_at", "max_offset_m")
    list_filter = ("route_id", "live")
    date_hierarchy = "started_at"
    readonly_fields = [f.name for f in DeviationEvent._meta.fields]

    def has_add_permission(self, request):
        return False
