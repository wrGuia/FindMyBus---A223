"""Simulated buses: replay buses along a route so everything works without live data.

Buses shuttle end to end in both directions, slow down in a couple of
congestion zones per route (so traffic colours have something to show), and
now and then take a short detour off the route (so deviation detection does too).
"""
import random
from dataclasses import dataclass


@dataclass
class SimBus:
    id: str
    route_id: str
    along_m: float
    forward: bool
    cruise_kmh: float
    speed_kmh: float
    detour_until: float = 0.0
    detour_offset_m: float = 0.0
    layover_until: float = 0.0


def congestion_zones(route_id, length_m):
    """Two fixed slow stretches per route: (start_m, end_m, speed factor). Deterministic per route."""
    rng = random.Random(f"zones-{route_id}")
    zones = []
    for factor in (0.3, 0.65):                      # ~heavy, ~light at normal cruise speed
        span = rng.uniform(700, 1500)
        start = rng.uniform(0.1, 0.9) * max(length_m - span, 0)
        zones.append((start, start + span, factor))
    return zones


def new_bus(bus_id, route, forward, rng):
    cruise = rng.uniform(24, 34)
    return SimBus(bus_id, route.id, rng.uniform(0, route.length_m), forward, cruise, cruise)


def step(bus, route, zones, dt, now, rng):
    """Advance one bus by `dt` seconds."""
    if now < bus.layover_until:
        bus.speed_kmh = 0.0
        return
    factor = 1.0
    for start, end, f in zones:
        if start <= bus.along_m <= end:
            factor = min(factor, f)
    target = bus.cruise_kmh * factor * rng.uniform(0.85, 1.15)
    bus.speed_kmh = max(2.0, min(55.0, bus.speed_kmh + 0.5 * (target - bus.speed_kmh)))

    move = bus.speed_kmh / 3.6 * dt
    bus.along_m += move if bus.forward else -move
    if bus.along_m >= route.length_m or bus.along_m <= 0:          # end of the line: turn around
        bus.along_m = min(max(bus.along_m, 0.0), route.length_m)
        bus.forward = not bus.forward
        bus.layover_until = now + rng.uniform(20, 60)
        bus.detour_until = 0.0

    if bus.detour_until and now >= bus.detour_until:
        bus.detour_until = 0.0
    elif not bus.detour_until and rng.random() < 0.0025 * dt:     # about one detour per bus every ~7 min
        bus.detour_until = now + rng.uniform(45, 120)
        bus.detour_offset_m = rng.choice((-1, 1)) * rng.uniform(320, 520)


def position(bus, route, now):
    if bus.detour_until and now < bus.detour_until:
        return route.line.offset_point(bus.along_m, bus.detour_offset_m)
    return route.line.point_at(bus.along_m)
