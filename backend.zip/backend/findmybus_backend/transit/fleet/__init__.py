"""The live fleet: routes in memory, the simulator, and the background service that keeps both current."""
