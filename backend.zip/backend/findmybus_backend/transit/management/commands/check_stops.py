"""Compare route stops with LA Metro's published stop positions: python manage.py check_stops [--apply]

For every stop of every active route, finds the closest official stop (any direction, same route code)
and prints the distance. With --apply, stops within --max-m metres are moved onto the official position
(names and order are kept). Needs access to api.metro.net."""
from django.core.management.base import BaseCommand

from ...core.geo import haversine_m
from ...feeds import metro, official
from ...models import Route


class Command(BaseCommand):
    help = "Report (and optionally fix) stop coordinates against LA Metro's official stop list."

    def add_arguments(self, parser):
        parser.add_argument("--apply", action="store_true", help="Snap stops to the official positions.")
        parser.add_argument("--max-m", type=float, default=300.0, help="Largest move --apply may make (m).")

    def handle(self, *args, **opts):
        for route in Route.objects.filter(active=True):
            self.stdout.write(self.style.MIGRATE_HEADING(f"\n{route.route_id}  {route.name}"))
            try:
                rows = metro.fetch_route_stops(route.agency, route.code)
            except Exception as exc:
                self.stdout.write(self.style.ERROR(f"  could not download official stops: {type(exc).__name__}: {exc}"))
                continue
            pool = [s for p in official._patterns(rows) for s in p["stops"]]
            if not pool:
                self.stdout.write(self.style.WARNING("  no official stops returned"))
                continue
            mine = [{"name": s.name, "lat": s.lat, "lon": s.lon} for s in route.stops.all()]
            placed, n = official.match_stops(rows, mine)
            self.stdout.write(f"  {n} of {len(mine)} stops matched an official stop by name")
            moved = 0
            for stop, old, new in zip(route.stops.all(), mine, placed):
                d = haversine_m(old["lat"], old["lon"], new["lat"], new["lon"])
                if d == 0:      # no namesake: report the nearest official stop instead
                    best = min(pool, key=lambda o: haversine_m(stop.lat, stop.lon, o["lat"], o["lon"]))
                    d = haversine_m(stop.lat, stop.lon, best["lat"], best["lon"])
                    line = f"  {stop.sequence:>3} {stop.name:<42} no name match; nearest official {d:6.0f} m: {best['name']}"
                    self.stdout.write(self.style.WARNING(line))
                    continue
                line = f"  {stop.sequence:>3} {stop.name:<42} {d:6.0f} m off"
                self.stdout.write(self.style.SUCCESS(line) if d <= 60 else self.style.WARNING(line))
                if opts["apply"]:
                    stop.lat, stop.lon = new["lat"], new["lon"]
                    stop.save(update_fields=["lat", "lon"])
                    moved += 1
            if opts["apply"]:
                self.stdout.write(f"  moved {moved} stops; restart the server to rebuild the route line")
