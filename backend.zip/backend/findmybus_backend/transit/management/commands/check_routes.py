"""Show how each route's line is built: python manage.py check_routes

Prints the LA Metro stop patterns found for every route, which one was chosen, and the
resulting length, so a route that looks wrong on the map can be diagnosed."""
from django.core.management.base import BaseCommand

from ... import conf
from ...feeds import metro, official
from ...fleet.routes import load_configs, resolve_geometry


class Command(BaseCommand):
    help = "List the official LA Metro stop patterns per route and the geometry the backend ends up using."

    def handle(self, *args, **opts):
        self.stdout.write(f"Mode: {conf.DATA_SOURCE}  official stops: {conf.OFFICIAL_STOPS}  road snap: {conf.ROAD_SNAP}")
        for cfg in load_configs():
            self.stdout.write(self.style.MIGRATE_HEADING(f"\n{cfg.id}  {cfg.name}"))
            first, last = cfg.stops[0], cfg.stops[-1]
            self.stdout.write(f"  terminals: {first[0]}  ->  {last[0]}")
            try:
                rows = metro.fetch_route_stops(cfg.agency, cfg.code)
                for p in official._patterns(rows):
                    s = p["stops"]
                    self.stdout.write(f"  pattern route_id={p['route_id']} direction={p['direction']}: {len(s)} stops, "
                                      f"{official._length_m(s) / 1000:.1f} km, {s[0]['name']}  ->  {s[-1]['name']}")
            except Exception as exc:
                self.stdout.write(self.style.ERROR(f"  could not download official stops: {type(exc).__name__}: {exc}"))
            try:
                geo = resolve_geometry(cfg)
            except Exception as exc:
                self.stdout.write(self.style.ERROR(f"  geometry failed: {type(exc).__name__}: {exc}"))
                continue
            from ...core.geo import Polyline
            km = Polyline(geo.points).length_m / 1000
            style = self.style.SUCCESS if geo.complete else self.style.WARNING
            self.stdout.write(style(
                f"  USED: {'official' if geo.official else 'hand-picked'} stops ({len(geo.stops)}), line {km:.1f} km, "
                f"{geo.stops[0]['name']}  ->  {geo.stops[-1]['name']}"
                + (f"  | problems: {'; '.join(geo.errors)}" if geo.errors else "")))
