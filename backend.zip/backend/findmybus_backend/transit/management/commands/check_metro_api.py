"""Test the LA Metro connection from the terminal: python manage.py check_metro_api [--seconds 10]"""
import time

from django.core.management.base import BaseCommand

from ... import conf
from ...feeds import metro
from ...feeds.stream import MetroStream
from ...fleet.routes import load_configs


class Command(BaseCommand):
    help = "Listen to the LA Metro WebSocket for a few seconds, then try the REST backup and the official stop lists."

    def add_arguments(self, parser):
        parser.add_argument("--seconds", type=int, default=10)

    def handle(self, *args, **opts):
        routes = load_configs()
        self.stdout.write(f"Mode: {conf.DATA_SOURCE}  API: {conf.METRO_API_BASE}  routes: "
                          + ", ".join(f"{r.id}={r.code}" for r in routes))
        stream = MetroStream()
        stream.ensure_started(routes)
        self.stdout.write(f"Listening to the WebSocket for {opts['seconds']} s...")
        time.sleep(opts["seconds"])
        snap = stream.snapshot()
        ok = snap["messages"] > 0
        self.stdout.write((self.style.SUCCESS if ok else self.style.ERROR)(
            f"WebSocket: {snap['state']}, {snap['messages']} messages, vehicles per route {snap['vehicles_by_route']}"
            + (f", last error: {snap['last_error']}" if snap["last_error"] else "")))
        for r in routes:
            try:
                v = metro.fetch_vehicles(r.agency, r.code)
                self.stdout.write(self.style.SUCCESS(f"REST {r.code}: {len(v)} vehicles"))
            except Exception as exc:
                self.stdout.write(self.style.ERROR(f"REST {r.code}: {type(exc).__name__}: {exc}"))
            try:
                rows = metro.fetch_route_stops(r.agency, r.code)
                self.stdout.write(self.style.SUCCESS(f"Official stops {r.code}: {len(rows)} rows"))
            except Exception as exc:
                self.stdout.write(self.style.ERROR(f"Official stops {r.code}: {type(exc).__name__}: {exc}"))
