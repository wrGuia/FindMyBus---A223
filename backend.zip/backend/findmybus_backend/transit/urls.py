from django.contrib.auth import views as auth_views
from django.urls import path

from .views import api, dashboard

urlpatterns = [
    # Web pages
    path("", dashboard.home, name="home"),
    path("dashboard/", dashboard.dashboard, name="dashboard"),
    path("login/", auth_views.LoginView.as_view(template_name="transit/login.html"), name="login"),
    path("logout/", auth_views.LogoutView.as_view(), name="logout"),
    # Passenger API (Flutter app)
    path("api/routes/", api.routes, name="api_routes"),
    path("api/route/<str:route_id>/", api.route_detail, name="api_route"),
    path("api/buses/", api.buses, name="api_buses"),
    path("api/status/", api.status, name="api_status"),
    path("api/arrivals/", api.arrivals, name="api_arrivals"),
    path("api/eta/", api.eta, name="api_eta"),
    path("api/traffic/", api.traffic_view, name="api_traffic"),
    # Admin dashboard data (login required)
    path("api/fleet/", dashboard.fleet_api, name="api_fleet"),
]
