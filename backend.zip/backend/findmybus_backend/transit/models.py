"""Configuration the admin manages. Live bus positions are not stored here."""
from django.core.validators import MaxValueValidator, MinValueValidator, RegexValidator
from django.db import models

_lat = [MinValueValidator(-90), MaxValueValidator(90)]
_lon = [MinValueValidator(-180), MaxValueValidator(180)]


class Route(models.Model):
    route_id = models.CharField(
        "ID", max_length=16, unique=True,
        validators=[RegexValidator(r"^[A-Za-z0-9_-]+$", "Letters, digits, - and _ only.")],
        help_text="Short ID the app uses in URLs, e.g. R1.")
    code = models.CharField(
        max_length=16, help_text="LA Metro route code used for live data, e.g. 720.")
    agency = models.CharField(max_length=16, default="LACMTA")
    name = models.CharField(
        max_length=160, help_text='Shown in the app, e.g. "720 - Wilshire Rapid (Santa Monica to Downtown LA)".')
    color = models.CharField(
        max_length=7, default="#00B14F",
        validators=[RegexValidator(r"^#[0-9A-Fa-f]{6}$", "Use a hex colour like #E63946.")])
    headsign_fwd = models.CharField(
        "Toward (forward)", max_length=80, help_text="Where buses going first stop → last stop are headed.")
    headsign_rev = models.CharField(
        "Toward (reverse)", max_length=80, help_text="Where buses going last stop → first stop are headed.")
    fwd_toward_lat = models.FloatField(null=True, blank=True, validators=_lat,
                                       help_text="A point near the forward end (orients official stops).")
    fwd_toward_lon = models.FloatField(null=True, blank=True, validators=_lon)
    use_official_stops = models.BooleanField(
        default=True, help_text="Replace the stops below with LA Metro's official list when it can be downloaded.")
    active = models.BooleanField(default=True)
    sort_order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["sort_order", "route_id"]

    def __str__(self):
        return self.name

    @property
    def rgb(self):
        h = self.color.lstrip("#")
        return [int(h[i:i + 2], 16) for i in (0, 2, 4)]


class Stop(models.Model):
    route = models.ForeignKey(Route, related_name="stops", on_delete=models.CASCADE)
    sequence = models.PositiveIntegerField(help_text="Order along the route, first stop = lowest.")
    name = models.CharField(max_length=120)
    lat = models.FloatField(validators=_lat)
    lon = models.FloatField(validators=_lon)

    class Meta:
        ordering = ["route", "sequence"]
        constraints = [models.UniqueConstraint(fields=["route", "sequence"], name="unique_stop_sequence")]

    def __str__(self):
        return self.name


class DeviationEvent(models.Model):
    """A bus that left its route line (kept for the admin's delay and deviation review)."""
    bus_id = models.CharField(max_length=40)
    route_id = models.CharField(max_length=16)
    route_name = models.CharField(max_length=160)
    live = models.BooleanField(help_text="Real LA Metro bus (unticked = simulator).")
    started_at = models.DateTimeField()
    ended_at = models.DateTimeField(null=True, blank=True)
    max_offset_m = models.FloatField()
    lat = models.FloatField()
    lon = models.FloatField()

    class Meta:
        ordering = ["-started_at"]
        indexes = [models.Index(fields=["route_id", "-started_at"])]

    def __str__(self):
        return f"{self.bus_id} off route {self.route_id}"

    @property
    def duration_s(self):
        return (self.ended_at - self.started_at).total_seconds() if self.ended_at else None
