# FindMyBus backend (Django)

The server for the FindMyBus Android app (`findmybus_flutter_app`) and the admin
dashboard. Live LA Metro buses, with a simulator as fallback.

It serves exactly the JSON the app already reads, so **the app works with it
unchanged**. The tests check every response against the app's own fixtures.

## Run it

```bash
cd findmybus_backend
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python manage.py migrate                               # creates db.sqlite3 with the 3 LA routes
python manage.py createsuperuser                       # your admin login
python manage.py runserver 0.0.0.0:8000
```

- App on the Android emulator: it already points at `http://10.0.2.2:8000`.
- App on a phone on the same Wi-Fi: allow your PC's address, then set
  `http://<your-PC-IP>:8000` in the app's Settings:
  `DJANGO_ALLOWED_HOSTS="localhost,127.0.0.1,10.0.2.2,192.168.1.23" python manage.py runserver 0.0.0.0:8000`
- Demo without LA Metro: `FINDMYBUS_DATA_SOURCE=simulated python manage.py runserver 0.0.0.0:8000`
- Dashboard: http://127.0.0.1:8000/dashboard/ · Routes and stops: http://127.0.0.1:8000/django-admin/

Check the LA Metro connection from the terminal: `python manage.py check_metro_api`.

## What it does

| Feature | How |
|---|---|
| Live buses | LA Metro WebSocket (`wss://api.metro.net/ws/LACMTA/vehicle_positions/...`), REST `trip_detail` as backup |
| Fallback | Simulator per route when LA Metro has no buses on it (`auto` mode). Simulated buses run both ways, slow down in two congestion zones per route and sometimes detour, so every feature can be demoed |
| Official stops | Each route's real stop list from LA Metro `route_stops`, used when "use official stops" is ticked |
| ETA | Remaining distance along the route ÷ smoothed speed (clamped 8–70 km/h, 18 km/h if unknown) + 15 s per stop in between. Same formula as the app |
| Alert distance | `/api/arrivals/` marks a bus `near` within the distance the passenger picked (100 m – 3 km) and `arriving` within 150 m |
| Traffic colours | Route cut into 300 m pieces fed by live bus speeds: under 12 km/h heavy (red), under 22 km/h light (yellow). Readings expire after 8 min. Same model as the app |
| Route deviation | A bus more than 250 m off its line for 30 s is flagged, shown as Delayed, and logged for the admin. Both values configurable |
| Stale data | Every bus carries `updated_at` and `freshness` (`live`, `stale` after 45 s, `offline` after 2 min). Silent live buses stay listed as stale for 5 min instead of looking live |
| Admin | Login, live map with traffic colours, bus table, deviation log, 30-minute fleet chart. Routes and stops are edited in Django admin and reach the app on the next update |

Removed on purpose: Google sign-in, passenger capacity (`crowd`), weather.
Notifications are shown by the app itself (it polls and alerts on the phone,
even in the background), so the server needs no push service.

### Faster than the old backend
- One background loop updates the fleet every 3 s. Requests only read the latest
  snapshot, so no request ever waits on LA Metro or OSRM, and many phones polling
  cost almost nothing (a tick takes under a millisecond with the simulator).
- Route lines are simplified before sending: the same shape and length with far
  fewer points. Responses are gzip-compressed.
- Snapping a GPS fix to the route projects onto the line's segments instead of
  searching a 30 m point grid, which is more accurate and needs no densifying.

## API

Used by the app (unchanged contract):

| Endpoint | Returns |
|---|---|
| `GET /api/routes/` | Routes without geometry: id, code, name, color, headsigns, stop names, bus count, source |
| `GET /api/route/<id>/` | One route: stops with `along_km`, `path`, `total_km`, source, current buses |
| `GET /api/buses/?route=<id>` | The light poll: current buses of one route (omit `route` for all) |
| `GET /api/status/` | Connection check and diagnostics (`mode`, per-route source, stream state) |

Extra (same maths as the app, ready if the app or another client wants them):

| Endpoint | Returns |
|---|---|
| `GET /api/arrivals/?route=R1&stop=4&dir=fwd\|rev\|both&radius_m=500` | Buses still heading to a stop, nearest first, with `eta_s`, `remaining_m`, `stops_away`, `near`, `arriving` |
| `GET /api/eta/?bus=Sim%2001&stop=4` | One bus to one stop |
| `GET /api/traffic/?route=R1` | Traffic stretches: `start_km`, `end_km`, `level` (heavy, light, clear, unknown) |
| `GET /api/fleet/` | Everything the dashboard shows (staff login required) |

A bus looks like this (the app ignores fields it doesn't know):

```json
{"id": "Bus 5123", "route_id": "R1", "route_name": "720 - Wilshire Rapid (...)",
 "lat": 34.0631, "lon": -118.3612, "status": "On Time", "speed_kmh": 32.1,
 "deviation": false, "live": true, "next_stop": "Koreatown (Wilshire/Western)",
 "next_stop_index": 4, "direction": "fwd", "heading": "To Downtown LA",
 "along_km": 14.0886, "updated_at": 1791705629.9, "freshness": "live"}
```

## Settings (environment variables)

Nothing is required for local development. See `.env.example`.

| Variable | Default | Meaning |
|---|---|---|
| `FINDMYBUS_DATA_SOURCE` | `auto` | `auto`, `live` (LA Metro only) or `simulated` (never call LA Metro) |
| `METRO_API_TOKEN` | empty | Optional bearer token for api.metro.net |
| `FINDMYBUS_OFFICIAL_ROUTES` | `1` | `0` = always use the stops in the database |
| `FINDMYBUS_ROAD_SNAP` | `1` | Snap hand-entered stops to roads with OSRM |
| `FINDMYBUS_DEVIATION_M` / `FINDMYBUS_DEVIATION_SECONDS` | `250` / `30` | Deviation threshold and duration |
| `FINDMYBUS_TICK_SECONDS` | `3` | How often the fleet updates |
| `FINDMYBUS_LIVE_KEEP_SECONDS` | `300` | How long a silent live bus stays listed (as stale) |
| `DJANGO_SECRET_KEY` | dev value | Required when `DJANGO_DEBUG=0` |
| `DJANGO_DEBUG` | `1` | `0` in production |
| `DJANGO_ALLOWED_HOSTS` | `localhost,127.0.0.1,10.0.2.2` | Add your PC's IP or your domain |
| `DJANGO_CSRF_TRUSTED_ORIGINS` | empty | Your HTTPS origin, for the admin login behind a proxy |
| `FINDMYBUS_CORS_ORIGINS` | empty | Only for browser clients; the Android app doesn't need it |

## Deploying

The fleet lives in memory, so run **one** worker process (threads are fine):

```bash
pip install gunicorn
DJANGO_DEBUG=0 DJANGO_SECRET_KEY=... DJANGO_ALLOWED_HOSTS=your.host \
  DJANGO_CSRF_TRUSTED_ORIGINS=https://your.host \
  python manage.py collectstatic --noinput && python manage.py migrate && \
  gunicorn config.wsgi --workers 1 --threads 8 --bind 0.0.0.0:8000
```

For a quick public HTTPS URL from your PC: `cloudflared tunnel --url http://127.0.0.1:8000`
(add `.trycloudflare.com` to `DJANGO_ALLOWED_HOSTS`), then put that URL in the app's Settings.

## Tests

```bash
python manage.py test transit
```

37 tests: geometry, ETA, deviation, traffic, freshness, direction, the LA Metro
parsers and stream, the API against the app's fixtures, live/auto/live-only modes,
the deviation log, admin login and route edits.

## Layout

```
config/                settings, urls
transit/
  conf.py              every tunable value
  core/                pure logic, unit-tested: geo, eta, deviation, traffic, freshness, direction
  feeds/               LA Metro REST + WebSocket, official stops, OSRM
  fleet/               routes in memory, simulator, the background FleetService
  views/               api.py (the app), dashboard.py (admin)
  models.py            Route, Stop, DeviationEvent (SQLite)
  seed.py              the 3 LA routes loaded by the first migration
  templates/ static/   dashboard (Leaflet + Chart.js)
  tests/               tests + fixtures copied from the app
```

## Coming from the old `FindMyBus Flutter` backend

- Same URLs and JSON for the app. `crowd` is gone; `freshness`, `code` and a few extras are new.
- Admin login is now a real Django account (`createsuperuser`) instead of `admin/admin`.
- Routes and stops live in SQLite and are edited at `/django-admin/` (previously in-memory and lost on restart).
- The web passenger page is gone: the Android app is the passenger client.
- The Flet client is gone.

## Route shapes (28, 720, 204)

In live mode each route's stops come from LA Metro, but only a pattern that really runs between the
route's **first and last stop** (the terminals set in the admin) is accepted. A pattern that runs past a
terminal is cut there; a short-turn pattern that stops short is rejected, and the hand-entered stops are
snapped to the road instead (the reason shows in `/api/status/` under `geometry_errors`). Official stops
more than ~600 m apart (rapid lines such as 720) are joined along the road, not with straight lines.

To see what LA Metro returned and what was used:

```
python manage.py check_routes

# Compare stop coordinates with LA Metro's official positions (add --apply to snap them)
python manage.py check_stops
```
