"""FleetService: one background loop keeps every bus current; requests only read its latest snapshot.

Each tick (every FINDMYBUS_TICK_SECONDS, default 3 s):
  1. reads LA Metro vehicles (WebSocket stream first, REST as backup) unless the mode is "simulated",
  2. moves the simulated buses,
  3. snaps every bus onto its route line and works out direction, next stop and speed,
  4. runs deviation detection, delay status, speed smoothing and the traffic model,
  5. publishes an immutable Snapshot.

Requests never touch the network: they serialise the latest snapshot, so
polling from many phones is cheap. Run a single worker process (the fleet lives
in memory), e.g. `gunicorn config.wsgi --workers 1 --threads 8`.
"""
import logging
import random
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from datetime import datetime, timezone

from django.db import DatabaseError, close_old_connections

from .. import conf
from ..core import freshness, traffic
from ..core.deviation import DeviationTracker
from ..core.direction import DirectionTracker
from ..core.eta import SpeedSmoother
from ..core.geo import haversine_m
from ..feeds import metro
from ..feeds.stream import MetroStream
from . import simulator
from .routes import (RouteRuntime, load_cached_geometry, load_configs, needs_network, provisional_geometry,
                     resolve_geometry, save_cached_geometry)

log = logging.getLogger(__name__)


@dataclass(frozen=True)
class BusState:
    """What ETA and alert calculations need about a bus (not sent as-is)."""
    route_id: str
    along_m: float
    direction: str | None
    smoothed_kmh: float | None
    freshness: str


@dataclass
class Snapshot:
    time: float
    routes: dict                                  # route_id -> RouteRuntime, in display order
    buses: dict                                   # route_id -> [public bus dict]
    states: dict                                  # bus_id -> BusState
    sources: dict                                 # route_id -> "live" | "simulated" | "empty"
    via: dict                                     # route_id -> "stream" | "rest" | None
    traffic: dict                                 # route_id -> [(start_m, end_m, level)]
    history: list = field(default_factory=list)
    reason: str | None = None


def _iso(ts):
    return datetime.fromtimestamp(ts, tz=timezone.utc)


class FleetService:
    def __init__(self, *, rng=None, stream=None, clock=time.time):
        self.clock = clock
        self.rng = rng or random.Random()
        self.stream = stream if stream is not None else MetroStream()
        self._lock = threading.Lock()
        self._wake = threading.Event()
        self._reload = False
        self._thread = None
        self._routes = {}
        self._geo_cache = {}                      # RouteConfig.geometry_key -> Geometry
        self._geo_retry_at = 0.0
        self._geo_retry_running = False
        self._geo_building = False
        self._zones = {}
        self._sim = {}                            # bus_id -> SimBus
        self._sim_counter = 0
        self._live_prev = {}                      # bus_id -> (along_m, fix_time) for derived speed
        self._slow_since = {}
        self._open_events = {}                    # bus_id -> DeviationEvent pk
        self._directions = DirectionTracker()
        self._deviation = DeviationTracker()
        self._speeds = SpeedSmoother()
        self._traffic = {}                        # route_id -> TrafficModel
        self._history = []
        self._last_hist = 0.0
        self._rest_blocked_until = 0.0
        self.rest_error = None
        self.tick_ms = None
        self.snapshot = None

    # ------------------------------------------------------------------ routes
    def load_routes(self):
        """(Re)build routes from the database without ever waiting on the network.

        A route whose road line is not ready yet is served at once with straight lines between its stops,
        and the real line is built in a background thread (then swapped in by a reload). When the network
        isn't needed (tests, simulated mode with road snapping off) geometry is built right here."""
        configs = load_configs()
        todo = []
        for c in configs:
            if c.geometry_key in self._geo_cache:
                continue
            if needs_network():
                cached = load_cached_geometry(c)
                if cached is not None:
                    self._geo_cache[c.geometry_key] = cached
                else:
                    todo.append(c)
            else:
                geo = self._safe_geometry(c)
                if geo is not None:
                    self._geo_cache[c.geometry_key] = geo
        routes = {}
        for cfg in configs:
            geo = self._geo_cache.get(cfg.geometry_key)
            if geo is None:
                if cfg.id in self._routes and self._routes[cfg.id].cfg.geometry_key == cfg.geometry_key:
                    geo = self._routes[cfg.id].geometry
                elif len(cfg.stops) >= 2:
                    geo = provisional_geometry(cfg)
                else:
                    continue
            routes[cfg.id] = RouteRuntime(cfg, geo)
        self._apply_routes(routes)
        if todo:
            self._resolve_in_background(todo)

    def _resolve_in_background(self, todo):
        with self._lock:
            if self._geo_building:
                return
            self._geo_building = True

        def run():
            try:
                for cfg in todo:                              # one route at a time keeps OSRM load polite
                    geo = self._safe_geometry(cfg)
                    if geo is None:                           # unusable route: keep it from looping on reloads
                        geo = provisional_geometry(cfg) if len(cfg.stops) >= 2 else None
                        if geo is not None:
                            self._geo_cache[cfg.geometry_key] = geo
                        continue
                    save_cached_geometry(cfg, geo)
                    self._geo_cache[cfg.geometry_key] = geo   # failures too; the retry loop improves them later
                    log.info("route %s: road line ready (official=%s, snapped=%s, errors=%s)",
                             cfg.id, geo.official, geo.road_snapped, geo.errors)
            finally:
                self._geo_building = False
                self.request_reload()

        threading.Thread(target=run, daemon=True, name="geometry-build").start()

    @staticmethod
    def _safe_geometry(cfg):
        try:
            return resolve_geometry(cfg)
        except Exception as exc:
            log.warning("Route %s skipped: %s", cfg.id, exc)
            return None

    def _apply_routes(self, routes):
        old = self._routes
        self._routes = routes
        for rid, route in routes.items():
            self._zones[rid] = simulator.congestion_zones(rid, route.length_m)
            prev = old.get(rid)
            if prev is None or prev.length_m != route.length_m or prev.stops_along != route.stops_along:
                self._traffic[rid] = traffic.TrafficModel(route.length_m)
                for b in self._sim.values():          # keep simulated buses on the new line
                    if b.route_id == rid:
                        b.along_m = min(b.along_m, route.length_m)
        for rid in [r for r in self._traffic if r not in routes]:
            del self._traffic[rid]
        self._sim = {k: b for k, b in self._sim.items() if b.route_id in routes}
        have = {b.route_id for b in self._sim.values()}
        for rid, route in routes.items():
            if rid in have:
                continue
            for k in range(conf.SIM_BUSES_PER_ROUTE):
                self._sim_counter += 1
                bid = f"Sim {self._sim_counter:02d}"
                self._sim[bid] = simulator.new_bus(bid, route, forward=(k % 2 == 0), rng=self.rng)
        if conf.DATA_SOURCE != "simulated" and routes:
            self.stream.ensure_started(routes.values())

    def request_reload(self):
        with self._lock:
            self._reload = True
        self._wake.set()

    def _maybe_retry_geometry(self, now):
        """Every few minutes, retry geometry that failed (official stops or road snapping) in the background."""
        incomplete = [r.cfg for r in self._routes.values() if not r.geometry.complete]
        if not incomplete or self._geo_retry_running or self._geo_building or now < self._geo_retry_at:
            return
        self._geo_retry_at = now + conf.GEOMETRY_RETRY_SECONDS
        self._geo_retry_running = True

        def run():
            try:
                improved = False
                for cfg in incomplete:
                    geo = self._safe_geometry(cfg)
                    cur = self._geo_cache.get(cfg.geometry_key)
                    better = geo is not None and (geo.official or geo.road_snapped or cur is None
                                                  or geo.unsnapped < cur.unsnapped)
                    if better:
                        save_cached_geometry(cfg, geo)
                        self._geo_cache[cfg.geometry_key] = geo
                        improved = True
                if improved:
                    self.request_reload()
            finally:
                self._geo_retry_running = False

        threading.Thread(target=run, daemon=True, name="geometry-retry").start()

    # -------------------------------------------------------------- live data
    def _live_vehicles(self, now):
        """route_id -> (vehicles, via) for routes LA Metro reported buses on."""
        if conf.DATA_SOURCE == "simulated" or not self._routes:
            return {}
        stream_ok = self.stream.healthy(now)
        out, rest_needed = {}, []
        for rid, r in self._routes.items():
            v = self.stream.vehicles(r.code, now=now)
            if v:
                out[rid] = (v, "stream")
            elif not stream_ok:
                rest_needed.append(r)
        if rest_needed and now >= self._rest_blocked_until:
            def fetch(r):
                try:
                    return r.id, metro.fetch_vehicles(r.agency, r.code), None
                except Exception as exc:
                    return r.id, None, exc
            with ThreadPoolExecutor(max_workers=min(8, len(rest_needed))) as pool:
                results = list(pool.map(fetch, rest_needed))
            errors = [e for _, _, e in results if e is not None]
            for rid, vehicles, _ in results:
                if vehicles:
                    out[rid] = ([dict(v, received_at=now) for v in vehicles], "rest")
            if errors and len(errors) == len(results):
                self.rest_error = f"REST: {type(errors[0]).__name__}: {errors[0]}"[:200]
                self._rest_blocked_until = now + conf.REST_BACKOFF_SECONDS
            elif not errors:
                self.rest_error = None
        return out

    def _reason(self):
        if conf.DATA_SOURCE == "simulated":
            return "live feed turned off (FINDMYBUS_DATA_SOURCE=simulated)"
        snap = self.stream.snapshot()
        err = self.rest_error or snap.get("last_error")
        if err:
            return err[:140]
        if snap["state"] in ("idle", "connecting"):
            return "connecting to LA Metro..."
        return "LA Metro reported no buses in service on this route right now"

    # ------------------------------------------------------------------- tick
    def tick(self, now=None, dt=None):
        """Advance the whole fleet once and publish a new snapshot."""
        t0 = time.perf_counter()
        now = self.clock() if now is None else now
        with self._lock:
            reload, self._reload = self._reload, False
        if reload or not self._routes:
            self.load_routes()
        prev_time = self.snapshot.time if self.snapshot else now - conf.TICK_SECONDS
        dt = max(0.0, min(now - prev_time, 30.0)) if dt is None else dt

        for b in self._sim.values():
            simulator.step(b, self._routes[b.route_id], self._zones[b.route_id], dt, now, self.rng)
        live = self._live_vehicles(now)

        buses, states, sources, via = {}, {}, {}, {}
        for rid, route in self._routes.items():
            if rid in live:
                vehicles, via[rid] = live[rid]
                sources[rid] = "live"
                raw = [self._live_record(route, v, now) for v in vehicles]
            else:
                via[rid] = None
                sources[rid] = "empty" if conf.DATA_SOURCE == "live" else "simulated"
                raw = [] if sources[rid] == "empty" else [
                    self._sim_record(route, b, now) for b in self._sim.values() if b.route_id == rid]
            buses[rid] = [self._finish(route, r, now, states) for r in raw]

        ids = list(states)
        self._directions.retain(ids)
        self._deviation.retain(ids)
        self._speeds.retain(ids)
        self._slow_since = {k: v for k, v in self._slow_since.items() if k in states}
        self._live_prev = {k: v for k, v in self._live_prev.items() if k in states}
        self._close_vanished_events(set(ids), now)

        all_buses = [b for lst in buses.values() for b in lst]
        if now - self._last_hist >= 10 or not self._history:
            self._last_hist = now
            self._history.append({
                "t": round(now, 1),
                "on_time": sum(1 for b in all_buses if b["status"] == "On Time"),
                "delayed": sum(1 for b in all_buses if b["status"] == "Delayed"),
                "deviating": sum(1 for b in all_buses if b["deviation"]),
            })
            self._history = self._history[-180:]                 # 30 minutes

        self.snapshot = Snapshot(
            time=now, routes=dict(self._routes), buses=buses, states=states, sources=sources, via=via,
            traffic={rid: m.segments(now) for rid, m in self._traffic.items()},
            history=list(self._history),
            reason=None if all(s == "live" for s in sources.values()) else self._reason())
        self._maybe_retry_geometry(now)
        self.tick_ms = round((time.perf_counter() - t0) * 1000, 1)
        return self.snapshot

    def _sim_record(self, route, b, now):
        lat, lon = simulator.position(b, route, now)
        on_line = route.line.point_at(b.along_m)
        return {"id": b.id, "lat": lat, "lon": lon, "along_m": b.along_m,
                "offset_m": haversine_m(lat, lon, *on_line), "forward": b.forward,
                "speed_kmh": b.speed_kmh, "delay_s": None, "updated_at": now, "live": False}

    def _live_record(self, route, v, now):
        bid = f"Bus {v['id']}"
        along, offset = route.line.project(v["lat"], v["lon"])
        fix = min(v.get("reported_at") or v.get("received_at") or now, now)
        speed = v.get("speed_kmh")
        prev = self._live_prev.get(bid)
        if prev is not None and fix > prev[1]:
            derived = abs(along - prev[0]) / (fix - prev[1]) * 3.6
            if speed is None and derived < 120:                     # feed has no speed: use our own estimate
                speed = round(derived, 1)
        if prev is None or fix > prev[1]:
            self._live_prev[bid] = (along, fix)
        forward = self._directions.update(bid, along)
        return {"id": bid, "lat": v["lat"], "lon": v["lon"], "along_m": along, "offset_m": offset,
                "forward": forward, "speed_kmh": speed, "delay_s": v.get("delay_s"),
                "updated_at": fix, "live": True}

    def _finish(self, route, r, now, states):
        """Deviation, delay, smoothing, traffic -> the public bus dict."""
        bid = r["id"]
        fresh = freshness.classify(now - r["updated_at"])
        direction = None if r["forward"] is None else ("fwd" if r["forward"] else "rev")

        change = self._deviation.update(bid, r["offset_m"], now) if fresh == freshness.LIVE else None
        deviating = self._deviation.is_flagged(bid)
        if change is not None and (change.started or change.ended):
            self._log_deviation(route, r, change, now)

        speed = r["speed_kmh"]
        if fresh == freshness.LIVE and speed is not None and speed < conf.SLOW_BELOW_KMH:
            self._slow_since.setdefault(bid, now)
        else:
            self._slow_since.pop(bid, None)
        slow = bid in self._slow_since and now - self._slow_since[bid] >= conf.SLOW_SECONDS
        late = r["delay_s"] is not None and r["delay_s"] > conf.DELAY_THRESHOLD_S
        status = "Delayed" if (deviating or late or slow) else "On Time"

        smoothed = self._speeds.add(bid, speed) if fresh == freshness.LIVE else self._speeds.get(bid)
        if fresh == freshness.LIVE and direction is not None and not deviating and speed is not None:
            self._traffic[route.id].observe(r["along_m"], speed, now)

        states[bid] = BusState(route.id, r["along_m"], direction, smoothed, fresh)
        idx = route.next_stop_index(r["along_m"], r["forward"])
        return {
            "id": bid, "route_id": route.id, "route_name": route.name,
            "lat": r["lat"], "lon": r["lon"],
            "status": status,
            "speed_kmh": round(speed, 1) if speed is not None else None,
            "deviation": deviating,
            "live": r["live"],
            "next_stop": route.stops[idx]["name"], "next_stop_index": idx,
            "direction": direction, "heading": route.heading(direction),
            "along_km": round(r["along_m"] / 1000, 4),
            "updated_at": round(r["updated_at"], 3),
            "freshness": fresh,
        }

    # ------------------------------------------------------- deviation log
    def _log_deviation(self, route, r, change, now):
        from ..models import DeviationEvent
        bid = r["id"]
        try:
            if change.started:
                ev = DeviationEvent.objects.create(
                    bus_id=bid, route_id=route.id, route_name=route.name, live=r["live"],
                    started_at=_iso(change.off_since), max_offset_m=round(change.max_offset_m, 1),
                    lat=r["lat"], lon=r["lon"])
                self._open_events[bid] = ev.pk
            elif change.ended and bid in self._open_events:
                DeviationEvent.objects.filter(pk=self._open_events.pop(bid)).update(
                    ended_at=_iso(now), max_offset_m=round(change.max_offset_m, 1))
        except DatabaseError as exc:
            log.warning("Could not record deviation for %s: %s", bid, exc)

    def _close_vanished_events(self, present, now):
        from ..models import DeviationEvent
        gone = [b for b in self._open_events if b not in present]
        for bid in gone:
            try:
                DeviationEvent.objects.filter(pk=self._open_events.pop(bid)).update(ended_at=_iso(now))
            except DatabaseError:
                pass

    # ----------------------------------------------------------- lifecycle
    def start(self):
        """Load routes, publish a first snapshot, then keep ticking in a daemon thread."""
        self.tick()
        self._thread = threading.Thread(target=self._loop, daemon=True, name="fleet")
        self._thread.start()

    def _loop(self):
        while True:
            self._wake.wait(conf.TICK_SECONDS)
            self._wake.clear()
            try:
                self.tick()
            except Exception:
                log.exception("Fleet tick failed")
            finally:
                close_old_connections()

    def diagnostics(self):
        s = self.snapshot
        return {
            "mode": conf.DATA_SOURCE,
            "routes": {rid: {
                "code": r.code, "source": s.sources.get(rid), "via": s.via.get(rid),
                "buses": len(s.buses.get(rid, [])),
                "official_stops": r.geometry.official, "road_snapped": r.geometry.road_snapped,
                "geometry_errors": r.geometry.errors,
                "stops": len(r.stops), "length_km": round(r.length_m / 1000, 3),
            } for rid, r in s.routes.items()},
            "reason": s.reason,
            "rest_error": self.rest_error,
            "stream": self.stream.snapshot() if conf.DATA_SOURCE != "simulated" else {"state": "off"},
            "tick_seconds": conf.TICK_SECONDS,
            "tick_ms": self.tick_ms,
            "snapshot_age_s": round(self.clock() - s.time, 2),
            "server_time": self.clock(),
        }


_fleet = None
_fleet_lock = threading.Lock()


def get_fleet():
    """The process-wide fleet, started on first use."""
    global _fleet
    if _fleet is None:
        with _fleet_lock:
            if _fleet is None:
                svc = FleetService()
                svc.start()
                _fleet = svc
    return _fleet


def fleet_or_none():
    return _fleet


def set_fleet(svc):
    """Tests: install a fleet that is ticked by hand."""
    global _fleet
    _fleet = svc
