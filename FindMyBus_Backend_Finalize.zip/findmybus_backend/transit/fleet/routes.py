"""Routes as the fleet uses them: config from the database plus resolved geometry."""
import hashlib
import json
import logging
import os
import threading
from dataclasses import dataclass, field

from django.db import DatabaseError

from .. import conf, seed
from ..core.geo import Polyline, haversine_m
from ..feeds import metro, official, osrm

log = logging.getLogger(__name__)


@dataclass(frozen=True)
class RouteConfig:
    id: str
    code: str
    agency: str
    name: str
    rgb: tuple
    headsigns: dict
    toward: tuple | None
    use_official: bool
    stops: tuple                 # ((name, lat, lon), ...) as entered by the admin

    @property
    def geometry_key(self):
        return (self.code, self.agency, self.toward, self.use_official, self.stops)


def _rgb(hex_color):
    h = hex_color.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def _config(d, stops):
    toward = (d["fwd_toward_lat"], d["fwd_toward_lon"]) if d.get("fwd_toward_lat") is not None else None
    return RouteConfig(
        id=d["route_id"], code=str(d["code"]), agency=d.get("agency") or "LACMTA", name=d["name"],
        rgb=_rgb(d["color"]), headsigns={"fwd": d["headsign_fwd"], "rev": d["headsign_rev"]},
        toward=toward, use_official=d.get("use_official_stops", True),
        stops=tuple((n, float(la), float(lo)) for n, la, lo in stops))


def load_configs():
    """Active routes from the database, or the built-in seed if the database isn't migrated yet."""
    from ..models import Route
    try:
        out = []
        for r in Route.objects.filter(active=True).prefetch_related("stops"):
            d = {f: getattr(r, f) for f in ("route_id", "code", "agency", "name", "color", "headsign_fwd",
                                             "headsign_rev", "fwd_toward_lat", "fwd_toward_lon",
                                             "use_official_stops")}
            out.append(_config(d, [(s.name, s.lat, s.lon) for s in r.stops.all()]))
        return out
    except DatabaseError as exc:
        log.warning("Database not ready (%s); using the built-in routes. Run: python manage.py migrate", exc)
        return [_config(d, d["stops"]) for d in seed.ROUTES]


@dataclass
class Geometry:
    stops: list                  # [{"name", "lat", "lon"}]
    points: list                 # [(lat, lon)] of the route line
    official: bool
    road_snapped: bool
    errors: list = field(default_factory=list)
    unsnapped: int = 0           # stop-to-stop stretches still drawn as a straight line

    @property
    def complete(self):
        """False when something was wanted but failed (worth retrying later)."""
        return not self.errors


def provisional_geometry(cfg):
    """Instant, offline geometry (the entered stops joined by straight lines) shown while the real one loads."""
    stops = [{"name": n, "lat": la, "lon": lo} for n, la, lo in cfg.stops]
    return Geometry(stops, [(s["lat"], s["lon"]) for s in stops], False, False, ["loading road line..."])


def needs_network():
    """True when building a route's geometry calls LA Metro or OSRM (slow), so it must not block a request."""
    return conf.ROAD_SNAP or (conf.OFFICIAL_STOPS and conf.DATA_SOURCE != "simulated")


# ---- Disk cache of finished geometry ---------------------------------------------------------------------
_cache_lock = threading.Lock()


def _cache_id(cfg):
    return hashlib.sha1(repr(cfg.geometry_key).encode()).hexdigest()


def load_cached_geometry(cfg):
    try:
        with open(conf.GEOMETRY_CACHE_FILE, encoding="utf-8") as f:
            d = json.load(f).get(_cache_id(cfg))
        if not d:
            return None
        return Geometry(d["stops"], [tuple(p) for p in d["points"]], d["official"], d["road_snapped"], [])
    except (OSError, ValueError, KeyError, TypeError):
        return None


def save_cached_geometry(cfg, geo):
    if not geo.complete:
        return
    with _cache_lock:
        try:
            try:
                with open(conf.GEOMETRY_CACHE_FILE, encoding="utf-8") as f:
                    data = json.load(f)
            except (OSError, ValueError):
                data = {}
            data[_cache_id(cfg)] = {"stops": geo.stops, "points": [list(p) for p in geo.points],
                                    "official": geo.official, "road_snapped": geo.road_snapped}
            tmp = conf.GEOMETRY_CACHE_FILE + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, separators=(",", ":"))
            os.replace(tmp, conf.GEOMETRY_CACHE_FILE)
        except OSError as exc:
            log.info("could not save geometry cache: %s", exc)


def _official_points(stops):
    """Route line through official stops: straight when they are close together (that already
    follows the street), road-snapped when they are far apart (e.g. rapid lines ~1 km apart)."""
    straight = [(s["lat"], s["lon"]) for s in stops]
    gaps = sorted(haversine_m(a[0], a[1], b[0], b[1]) for a, b in zip(straight, straight[1:]))
    if conf.ROAD_SNAP and gaps and gaps[len(gaps) // 2] > conf.SPARSE_STOP_GAP_M:
        pts, _ = osrm.snap_official(stops)
        return pts
    return straight


def resolve_geometry(cfg):
    """Stops and route line for a route. May call LA Metro and OSRM (blocking)."""
    errors = []
    if conf.OFFICIAL_STOPS and cfg.use_official and conf.DATA_SOURCE != "simulated":
        try:
            rows = metro.fetch_route_stops(cfg.agency, cfg.code)
            # The first and last stop entered for the route are its terminals. The official
            # pattern is cut to (and must reach) them, so a short-turn pattern can't replace the route.
            terminals = ((cfg.stops[0][1], cfg.stops[0][2]), (cfg.stops[-1][1], cfg.stops[-1][2])) \
                if len(cfg.stops) >= 2 else None
            stops = official.build_stops(rows, cfg.toward, terminals)
            if stops:
                return Geometry(stops, _official_points(stops), True, True)
            if terminals and official.build_stops(rows, cfg.toward):
                errors.append("official stops: no LA Metro pattern runs between this route's first and last stop")
            else:
                errors.append("official stops: no usable stops in the response")
        except Exception as exc:
            errors.append(f"official stops: {type(exc).__name__}: {exc}"[:160])
    stops = [{"name": n, "lat": la, "lon": lo} for n, la, lo in cfg.stops]
    if len(stops) < 2:
        raise ValueError(f"route {cfg.id} needs at least two stops")
    if conf.OFFICIAL_STOPS and conf.DATA_SOURCE != "simulated":
        # Put every stop at LA Metro's exact position for the same stop name, so the stops (and the
        # road line routed through them) sit on the real street instead of on hand-estimated points.
        try:
            stops, n = official.match_stops(metro.fetch_route_stops(cfg.agency, cfg.code), stops)
            log.info("route %s: %d of %d stops placed at LA Metro's official positions", cfg.id, n, len(stops))
        except Exception as exc:
            log.info("route %s: could not fetch official stop positions (%s)", cfg.id, exc)
    straight = [(s["lat"], s["lon"]) for s in stops]
    if not conf.ROAD_SNAP:
        return Geometry(stops, straight, False, False, errors)
    stats = {}
    points, all_snapped = osrm.snap_stop_list(stops, stats=stats)
    bad, total = stats.get("bad", 0), max(stats.get("total", 1), 1)
    if points == straight:                        # every request failed: retry later
        errors.append("road snapping (OSRM) unavailable")
    elif not all_snapped:
        log.info("route %s: %d of %d stretches could not be snapped to a road and stay straight "
                 "(%d OSRM requests failed)", cfg.id, bad, total, stats.get("failed_requests", 0))
        if bad > 0.1 * total:                     # mostly fine is good enough to keep; otherwise retry later
            errors.append(f"{bad} of {total} stretches not snapped to a road")
    stops = osrm.pin_stops_to_line(stops, points)
    return Geometry(stops, points, False, bool(all_snapped), errors, bad)


class RouteRuntime:
    """Everything the fleet and the API need about one route, computed once."""

    def __init__(self, cfg: RouteConfig, geo: Geometry):
        self.cfg = cfg
        self.id = cfg.id
        self.code = cfg.code
        self.agency = cfg.agency
        self.name = cfg.name
        self.rgb = list(cfg.rgb)
        self.headsigns = cfg.headsigns
        self.geometry = geo
        self.stops = geo.stops
        self.line = Polyline(geo.points)
        self.stops_along = self.line.stops_along(self.stops)
        self.length_m = self.line.length_m
        self.path = [[round(lat, 6), round(lon, 6)] for lat, lon in self.line.simplified()]
        self.stops_payload = [{"name": s["name"], "lat": s["lat"], "lon": s["lon"], "along_km": round(a / 1000, 4)}
                              for s, a in zip(self.stops, self.stops_along)]
        self.stop_names = [s["name"] for s in self.stops]

    def heading(self, direction):
        return "Detecting direction…" if direction is None else "To " + self.headsigns[direction]

    def next_stop_index(self, along_m, forward):
        sa = self.stops_along
        if forward is False:
            for i in range(len(sa) - 1, -1, -1):
                if sa[i] <= along_m:
                    return i
            return 0
        for i, a in enumerate(sa):
            if a >= along_m:
                return i
        return len(sa) - 1
