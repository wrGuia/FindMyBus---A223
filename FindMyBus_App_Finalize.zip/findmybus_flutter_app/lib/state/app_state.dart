// Everything the passenger screens show: routes, live buses, selection, traffic.
import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:latlong2/latlong.dart';

import '../core/eta.dart';
import '../core/geo.dart';
import '../core/traffic.dart';
import '../core/trip_planner.dart';
import '../data/api_client.dart';
import '../data/models.dart';
import '../services/arrivals.dart';
import '../services/location_service.dart';
import 'app_settings.dart';

class NearestStop {
  const NearestStop(this.route, this.stop, this.distanceM);
  final RouteDetail route;
  final Stop stop;
  final double distanceM;
}

class AppState extends ChangeNotifier {
  AppState(this.settings, {LocationService? location, FindMyBusApi Function(String url)? apiFactory})
      : _location = location ?? LocationService(),
        _apiFactory = apiFactory ?? FindMyBusApi.new {
    _api = _apiFactory(settings.baseUrl);
    settings.addListener(_onSettingsChanged);
  }

  final AppSettings settings;
  final LocationService _location;
  final FindMyBusApi Function(String url) _apiFactory;
  late FindMyBusApi _api;
  FindMyBusApi get api => _api;

  // ---- data
  List<RouteSummary> routes = const [];
  final Map<String, RouteDetail> details = {};
  final Map<String, BusSnapshot> _snapshots = {};
  final Map<String, List<BusView>> _views = {};
  final Map<String, SpeedSmoother> _speeds = {};
  final Map<String, TrafficModel> _traffic = {};
  bool loading = true;
  String? error;

  /// Bumped on every data change; lets widgets skip work when nothing changed.
  int version = 0;

  // ---- selection
  String? selectedRouteId;
  String direction = 'fwd';
  int? myStopIndex;
  int? destinationStopIndex;
  String? selectedBusId;
  bool followBus = false;

  // ---- passenger location
  LatLng? userLocation;
  LocationProblem? locationProblem;

  Timer? _timer;
  bool _paused = false;
  bool _polling = false;

  RouteDetail? get selectedRoute =>
      selectedRouteId == null ? null : details[selectedRouteId];

  List<BusView> viewsOf(String routeId) => _views[routeId] ?? const [];

  BusSnapshot? snapshotOf(String routeId) => _snapshots[routeId];

  BusView? get selectedBus {
    final r = selectedRouteId;
    if (r == null || selectedBusId == null) return null;
    for (final v in viewsOf(r)) {
      if (v.bus.id == selectedBusId) return v;
    }
    return null;
  }

  List<TrafficSegment> trafficOf(String routeId) =>
      _traffic[routeId]?.segments(DateTime.now()) ?? const [];

  // ------------------------------------------------------------ lifecycle

  Future<void> init() async {
    await loadRoutes();
    unawaited(locate(silent: true));
  }

  Future<void> loadRoutes() async {
    loading = true;
    error = null;
    notifyListeners();
    try {
      routes = await _api.routes();
      // Geometry is fetched once per route and kept for the session.
      await Future.wait(routes.map((r) async {
        details[r.id] ??= await _api.route(r.id);
      }));
      loading = false;
      version++;
      notifyListeners();
      await _poll();
      _schedule();
    } on ApiException catch (e) {
      loading = false;
      error = e.message;
      notifyListeners();
    }
  }

  void _onSettingsChanged() {
    final url = FindMyBusApi.normalizeBaseUrl(settings.baseUrl);
    if (url != _api.baseUrl) {
      _api.close();
      _api = _apiFactory(url);
      details.clear();
      _snapshots.clear();
      _views.clear();
      _traffic.clear();
      selectedRouteId = null;
      loadRoutes();
    } else {
      _schedule();
    }
  }

  /// App went to the background: stop polling (the alert service keeps running).
  void pause() {
    _paused = true;
    _timer?.cancel();
  }

  void resume() {
    if (!_paused) return;
    _paused = false;
    if (routes.isEmpty) {
      loadRoutes();
    } else {
      _poll();
      _schedule();
    }
  }

  void _schedule() {
    _timer?.cancel();
    if (_paused || routes.isEmpty) return;
    // Faster while a route is open, slower on the overview to save battery/data.
    final base = settings.refreshRate.interval;
    final every = selectedRouteId == null ? base * 2 : base;
    _timer = Timer.periodic(every, (_) => _poll());
  }

  Future<void> refreshNow() => _poll();

  Future<void> _poll() async {
    if (_polling) return;
    _polling = true;
    try {
      // Buses are only fetched for the open route. The overview shows none.
      final open = selectedRouteId;
      if (open == null) {
        _polling = false;
        return;
      }
      final snaps = await Future.wait([_api.buses(open)]);
      for (final s in snaps) {
        // The server builds road lines in the background: when its line changed, download it again.
        final have = details[s.routeId];
        if (have != null && s.geometryId != null && s.geometryId != have.geometryId) {
          try {
            details[s.routeId] = await _api.route(s.routeId);
            _traffic.remove(s.routeId);
          } on ApiException {
            // keep the old line; try again on the next poll
          }
        }
        _ingest(s);
      }
      error = null;
    } on ApiException catch (e) {
      error = e.message;
    } finally {
      _polling = false;
    }
    version++;
    notifyListeners();
  }

  void _ingest(BusSnapshot snap) {
    final route = details[snap.routeId];
    if (route == null) return;
    _snapshots[snap.routeId] = snap;
    final views = buildBusViews(
        route, snap, _speeds.putIfAbsent(snap.routeId, SpeedSmoother.new));
    _views[snap.routeId] = views;
    final traffic = _traffic.putIfAbsent(
        snap.routeId, () => TrafficModel(routeLengthM: route.path.lengthM));
    for (final v in views) {
      if (v.trusted && v.bus.speedKmh != null && !v.bus.deviation) {
        traffic.observe(v.alongM, v.bus.speedKmh!, snap.fetchedAt);
      }
    }
  }

  // ------------------------------------------------------------ selection

  void selectRoute(String id, {String? direction, int? stopIndex, int? destinationIndex}) {
    final changed = selectedRouteId != id;
    selectedRouteId = id;
    if (direction != null) this.direction = direction;
    if (changed || stopIndex != null) myStopIndex = stopIndex;
    destinationStopIndex = destinationIndex;
    if (changed) {
      selectedBusId = null;
      followBus = false;
      if (stopIndex == null) myStopIndex = _nearestStopIndex(id);
    }
    version++;
    notifyListeners();
    _schedule();
    if (changed) _poll();
  }

  void clearRoute() {
    selectedRouteId = null;
    selectedBusId = null;
    destinationStopIndex = null;
    followBus = false;
    version++;
    notifyListeners();
    _schedule();
    _poll();
  }

  void setDirection(String d) {
    if (d == direction) return;
    direction = d;
    selectedBusId = null;
    followBus = false;
    version++;
    notifyListeners();
  }

  void setMyStop(int? index) {
    myStopIndex = index;
    version++;
    notifyListeners();
  }

  void selectBus(String? busId) {
    selectedBusId = busId;
    if (busId == null) followBus = false;
    // Show the bus in the direction it is travelling.
    final v = selectedBus;
    if (v?.bus.direction != null) direction = v!.bus.direction!;
    version++;
    notifyListeners();
  }

  void setFollow(bool on) {
    followBus = on;
    notifyListeners();
  }

  /// Destination search result: board at the stop nearest the passenger.
  String? planTo(String routeId, int destIndex) {
    final route = details[routeId];
    if (route == null) return null;
    final from = userLocation;
    if (from == null) {
      selectRoute(routeId, stopIndex: destIndex);
      return 'Showing buses to ${route.stops[destIndex].name}. Turn on location to plan where to board.';
    }
    final plan = planTrip(
        stops: [for (final s in route.stops) s.position],
        from: from,
        destinationStopIndex: destIndex);
    if (plan == null) {
      selectRoute(routeId, stopIndex: destIndex);
      return 'You are already closest to ${route.stops[destIndex].name}.';
    }
    selectRoute(routeId,
        direction: plan.direction,
        stopIndex: plan.boardStopIndex,
        destinationIndex: plan.destinationStopIndex);
    return null;
  }

  // ------------------------------------------------------------ location

  Future<LocationProblem?> locate({bool silent = false}) async {
    try {
      final r = await _location.current();
      locationProblem = r.problem;
      if (r.position != null) userLocation = r.position;
    } catch (_) {
      if (!silent) locationProblem = LocationProblem.serviceOff;
    }
    version++;
    notifyListeners();
    return locationProblem;
  }

  Future<void> openLocationSettings() => _location.openSettings();

  int? _nearestStopIndex(String routeId) {
    final route = details[routeId];
    final me = userLocation;
    if (route == null || me == null || route.stops.isEmpty) return null;
    var best = 0;
    var bestD = double.infinity;
    for (final s in route.stops) {
      final d = haversineM(me, s.position);
      if (d < bestD) {
        bestD = d;
        best = s.index;
      }
    }
    return best;
  }

  NearestStop? get nearestStop {
    final me = userLocation;
    if (me == null) return null;
    NearestStop? best;
    for (final r in details.values) {
      for (final s in r.stops) {
        final d = haversineM(me, s.position);
        if (best == null || d < best.distanceM) best = NearestStop(r, s, d);
      }
    }
    return best;
  }

  /// Next buses to the chosen stop in the chosen direction.
  List<BusEta> arrivalsAt(String routeId, int stopIndex, String dir) {
    final route = details[routeId];
    if (route == null) return const [];
    return etasToStop(route, viewsOf(routeId), stopIndex, dir);
  }

  @override
  void dispose() {
    _timer?.cancel();
    settings.removeListener(_onSettingsChanged);
    _api.close();
    super.dispose();
  }
}
