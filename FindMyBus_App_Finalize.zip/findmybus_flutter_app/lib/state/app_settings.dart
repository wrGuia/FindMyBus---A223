// User preferences, stored on the device.
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Default backend address. 10.0.2.2 is the host computer from the Android
/// emulator. Override at build time with --dart-define=API_BASE_URL=...
const kDefaultApiBaseUrl = String.fromEnvironment(
  'API_BASE_URL',
  defaultValue: 'http://10.0.2.2:8000',
);

enum RefreshRate {
  fast(Duration(seconds: 3), 'Fast', 'Every 3 s'),
  normal(Duration(seconds: 5), 'Normal', 'Every 5 s'),
  saver(Duration(seconds: 10), 'Battery saver', 'Every 10 s');

  const RefreshRate(this.interval, this.label, this.detail);
  final Duration interval;
  final String label;
  final String detail;
}

class AppSettings extends ChangeNotifier {
  static const _kUrl = 'api_base_url';
  static const _kAlertM = 'default_alert_m';
  static const _kRate = 'refresh_rate';

  String baseUrl = kDefaultApiBaseUrl;
  double defaultAlertM = 500;
  RefreshRate refreshRate = RefreshRate.fast;

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    baseUrl = p.getString(_kUrl) ?? kDefaultApiBaseUrl;
    defaultAlertM = p.getDouble(_kAlertM) ?? 500;
    refreshRate = RefreshRate.values.asNameMap()[p.getString(_kRate)] ?? RefreshRate.fast;
  }

  Future<void> update({String? baseUrl, double? defaultAlertM, RefreshRate? refreshRate}) async {
    final p = await SharedPreferences.getInstance();
    if (baseUrl != null) {
      this.baseUrl = baseUrl;
      await p.setString(_kUrl, baseUrl);
    }
    if (defaultAlertM != null) {
      this.defaultAlertM = defaultAlertM;
      await p.setDouble(_kAlertM, defaultAlertM);
    }
    if (refreshRate != null) {
      this.refreshRate = refreshRate;
      await p.setString(_kRate, refreshRate.name);
    }
    notifyListeners();
  }
}
