import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';

import 'services/alert_service.dart';
import 'services/inbox.dart';
import 'services/notification_service.dart';
import 'state/app_settings.dart';
import 'state/app_state.dart';
import 'ui/app_scope.dart';
import 'ui/home_screen.dart';
import 'ui/theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Lets the background alert service talk to the UI.
  FlutterForegroundTask.initCommunicationPort();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.dark,
  ));

  final settings = AppSettings();
  final inbox = Inbox();
  await Future.wait([settings.load(), inbox.load()]);
  final alerts = AlertController(inbox);
  final state = AppState(settings);

  runApp(FindMyBusApp(state: state, alerts: alerts, inbox: inbox, settings: settings));

  // Non-blocking start-up work.
  SystemNotifications.instance.init();
  alerts.restore();
  state.init();
}

class FindMyBusApp extends StatelessWidget {
  const FindMyBusApp({
    super.key,
    required this.state,
    required this.alerts,
    required this.inbox,
    required this.settings,
  });

  final AppState state;
  final AlertController alerts;
  final Inbox inbox;
  final AppSettings settings;

  @override
  Widget build(BuildContext context) {
    return AppScope(
      state: state,
      alerts: alerts,
      inbox: inbox,
      settings: settings,
      child: MaterialApp(
        title: 'FindMyBus',
        debugShowCheckedModeBanner: false,
        theme: buildTheme(),
        home: const HomeScreen(),
      ),
    );
  }
}
