// Glue between API data and the pure ETA / freshness / alert modules.
// Used by the UI and by the background alert service, so both agree.
import '../core/approach_alert.dart';
import '../core/eta.dart';
import '../core/freshness.dart';
import '../data/models.dart';

class BusView {
  const BusView({
    required this.bus,
    required this.alongM,
    required this.freshness,
    required this.age,
    required this.smoothedKmh,
  });

  final Bus bus;
  final double alongM;
  final Freshness freshness;

  /// Total age of the position (report age + time since the poll).
  final Duration age;
  final double? smoothedKmh;

  bool get trusted => freshness == Freshness.live && bus.direction != null;
}

/// Per-bus view models for one snapshot. Also feeds the speed smoother.
List<BusView> buildBusViews(
  RouteDetail route,
  BusSnapshot snap,
  SpeedSmoother speeds, {
  FreshnessPolicy policy = const FreshnessPolicy(),
  DateTime? now,
}) {
  final t = now ?? DateTime.now();
  final sinceFetch = t.difference(snap.fetchedAt);
  final out = <BusView>[];
  for (final b in snap.buses) {
    final age = snap.reportAge(b);
    final fresh = policy.classify(age, sinceFetch.isNegative ? Duration.zero : sinceFetch);
    out.add(BusView(
      bus: b,
      alongM: route.alongOf(b),
      freshness: fresh,
      age: age + sinceFetch,
      smoothedKmh: fresh == Freshness.live ? speeds.add(b.id, b.speedKmh) : speeds.of(b.id),
    ));
  }
  speeds.retain(snap.buses.map((b) => b.id));
  return out;
}

class BusEta {
  const BusEta(this.view, this.eta);
  final BusView view;
  final EtaResult eta;
}

/// ETAs of buses heading in [direction] to stop [stopIndex], nearest first.
/// Buses that already passed the stop are left out unless [includePassed].
List<BusEta> etasToStop(
  RouteDetail route,
  List<BusView> views,
  int stopIndex,
  String direction, {
  EtaCalculator calc = const EtaCalculator(),
  bool includePassed = false,
}) {
  if (stopIndex < 0 || stopIndex >= route.stops.length) return const [];
  final stop = route.stops[stopIndex];
  final out = <BusEta>[];
  for (final v in views) {
    if (v.bus.direction != direction) continue;
    if (v.freshness == Freshness.offline) continue;
    final r = calc.toStop(
      busAlongM: v.alongM,
      stopAlongM: stop.alongM,
      forward: direction == 'fwd',
      smoothedKmh: v.smoothedKmh,
      stopsAlongM: route.stopsAlongM,
    );
    if (r.passed && !includePassed) continue;
    out.add(BusEta(v, r));
  }
  out.sort((a, b) => a.eta.remainingM.compareTo(b.eta.remainingM));
  return out;
}

/// What the alert engine needs from the latest snapshot.
List<BusApproach> approachesFor(
  AlertSettings s,
  RouteDetail route,
  List<BusView> views, {
  EtaCalculator calc = const EtaCalculator(),
}) {
  final etas = etasToStop(route, views, s.stopIndex, s.direction,
      calc: calc, includePassed: true);
  return [
    for (final e in etas)
      if (s.busId == null || e.view.bus.id == s.busId)
        BusApproach(
          busId: e.view.bus.id,
          remainingM: e.eta.remainingM,
          eta: e.eta.eta,
          passed: e.eta.passed,
          trusted: e.view.trusted,
        ),
  ];
}
