// Keeps an approach alert running while the app is in the background, using an
// Android foreground service (the ongoing "Tracking your bus" notification).
// If the service can't start, the alert keeps running inside the app instead.
import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';

import '../core/approach_alert.dart';
import '../core/eta.dart';
import '../data/api_client.dart';
import 'alert_monitor.dart';
import 'inbox.dart';
import 'notification_service.dart';

const _kSettings = 'alert_settings';
const _kState = 'alert_state';
const _kId = 'alert_id';
const _kBaseUrl = 'alert_base_url';
const _kEvents = 'alert_events';
const _stopButton = 'stop_alert';
const _pollMs = 5000;

// ----------------------------------------------------------------- background

@pragma('vm:entry-point')
void alertTaskCallback() {
  FlutterForegroundTask.setTaskHandler(AlertTaskHandler());
}

class AlertTaskHandler extends TaskHandler {
  AlertMonitor? _monitor;
  String _alertId = '';
  bool _busy = false;
  bool _stopping = false;

  @override
  Future<void> onStart(DateTime timestamp, TaskStarter starter) async {
    await SystemNotifications.instance.init();
    final raw = await FlutterForegroundTask.getData<String>(key: _kSettings);
    final base = await FlutterForegroundTask.getData<String>(key: _kBaseUrl);
    if (raw == null || base == null) {
      await FlutterForegroundTask.stopService();
      return;
    }
    final stateRaw = await FlutterForegroundTask.getData<String>(key: _kState);
    _alertId = await FlutterForegroundTask.getData<String>(key: _kId) ?? '';
    _monitor = AlertMonitor(
      FindMyBusApi(base),
      AlertSettings.fromJson(jsonDecode(raw) as Map<String, Object?>),
      savedState: stateRaw == null ? null : jsonDecode(stateRaw) as Map<String, Object?>,
    );
    await _tick();
  }

  @override
  void onRepeatEvent(DateTime timestamp) => _tick();

  Future<void> _tick() async {
    final m = _monitor;
    if (m == null || _busy || _stopping) return;
    _busy = true;
    try {
      final u = await m.tick();
      if (u.events.isNotEmpty) {
        await _record(m.settings, u.events);
      }
      await FlutterForegroundTask.saveData(
          key: _kState, value: jsonEncode(m.engine.stateToJson()));
      FlutterForegroundTask.sendDataToMain(u.toMessage());
      final (title, text) = ongoingText(m.settings, u);
      await FlutterForegroundTask.updateService(
          notificationTitle: title, notificationText: text);
      if (u.phase == AlertPhase.finished) {
        _stopping = true;
        await Future<void>.delayed(const Duration(seconds: 2));
        await FlutterForegroundTask.stopService();
      }
    } finally {
      _busy = false;
    }
  }

  Future<void> _record(AlertSettings s, List<AlertEvent> events) async {
    final prev = await FlutterForegroundTask.getData<String>(key: _kEvents);
    final list = prev == null ? <Object?>[] : (jsonDecode(prev) as List);
    for (final e in events) {
      final (title, body) = describeEvent(s, e);
      final id = '$_alertId-${e.kind.name}';
      await SystemNotifications.instance.show(id.hashCode & 0x7fffffff, title, body);
      final msg = {
        'id': id,
        'title': title,
        'body': body,
        'time': DateTime.now().millisecondsSinceEpoch,
      };
      list.add(msg);
      FlutterForegroundTask.sendDataToMain({'type': 'event', ...msg});
    }
    await FlutterForegroundTask.saveData(key: _kEvents, value: jsonEncode(list));
  }

  @override
  void onNotificationButtonPressed(String id) {
    if (id == _stopButton) {
      _stopping = true;
      FlutterForegroundTask.sendDataToMain({'type': 'stopped'});
      clearSavedAlert().then((_) => FlutterForegroundTask.stopService());
    }
  }

  @override
  void onNotificationPressed() => FlutterForegroundTask.launchApp();

  @override
  Future<void> onDestroy(DateTime timestamp, bool isTimeout) async {
    _monitor?.api.close();
  }
}

/// Title/body of the ongoing tracking notification.
(String, String) ongoingText(AlertSettings s, MonitorUpdate u) {
  final f = u.focus;
  if (u.phase == AlertPhase.finished) {
    return ('Alert finished', 'Your bus has reached ${s.stopName}.');
  }
  if (u.error != null && f == null) {
    return ('Watching ${s.stopName}', 'Reconnecting… (${u.error})');
  }
  if (f == null) {
    return (
      'Waiting for a bus to ${s.stopName}',
      'You will be alerted at ${formatDistance(s.thresholdM)}'
    );
  }
  final bus = f.busId;
  if (f.passed) return ('$bus passed ${s.stopName}', 'Alert ended');
  return (
    '$bus · ${formatEta(f.eta)} to ${s.stopName}',
    '${formatDistance(f.remainingM)} away · alert at ${formatDistance(s.thresholdM)}'
        '${f.trusted ? '' : ' · signal delayed'}'
  );
}

Future<void> clearSavedAlert() async {
  for (final k in const [_kSettings, _kState, _kId]) {
    await FlutterForegroundTask.removeData(key: k);
  }
}

// ----------------------------------------------------------------- UI side

class AlertStatus {
  const AlertStatus({
    this.phase = AlertPhase.watching,
    this.busId,
    this.remainingM,
    this.eta,
    this.trusted = true,
    this.error,
  });

  final AlertPhase phase;
  final String? busId;
  final double? remainingM;
  final Duration? eta;
  final bool trusted;
  final String? error;
}

class AlertController extends ChangeNotifier {
  AlertController(this.inbox);

  final Inbox inbox;
  AlertSettings? active;
  AlertStatus status = const AlertStatus();

  /// True while the foreground service does the watching.
  bool inBackgroundService = false;

  String _alertId = '';
  AlertMonitor? _local;
  Timer? _localTimer;
  bool _initialised = false;

  void _initService() {
    if (_initialised) return;
    _initialised = true;
    FlutterForegroundTask.init(
      androidNotificationOptions: AndroidNotificationOptions(
        channelId: 'bus_tracking',
        channelName: 'Bus tracking',
        channelDescription: 'Shows your bus while an arrival alert is on',
        channelImportance: NotificationChannelImportance.LOW,
        priority: NotificationPriority.LOW,
        onlyAlertOnce: true,
      ),
      iosNotificationOptions: const IOSNotificationOptions(showNotification: false),
      foregroundTaskOptions: ForegroundTaskOptions(
        eventAction: ForegroundTaskEventAction.repeat(_pollMs),
        allowWakeLock: true,
        allowWifiLock: true,
      ),
    );
    FlutterForegroundTask.addTaskDataCallback(_onTaskData);
  }

  /// Re-attach to an alert that kept running while the app was closed.
  Future<void> restore() async {
    _initService();
    await drainEvents();
    final raw = await FlutterForegroundTask.getData<String>(key: _kSettings);
    if (raw != null && await FlutterForegroundTask.isRunningService) {
      active = AlertSettings.fromJson(jsonDecode(raw) as Map<String, Object?>);
      _alertId = await FlutterForegroundTask.getData<String>(key: _kId) ?? '';
      inBackgroundService = true;
      notifyListeners();
    } else if (raw != null) {
      await clearSavedAlert(); // service died with the app: start clean
    }
  }

  /// Copies notifications the service raised while the UI wasn't listening.
  Future<void> drainEvents() async {
    final raw = await FlutterForegroundTask.getData<String>(key: _kEvents);
    if (raw == null) return;
    for (final e in (jsonDecode(raw) as List).cast<Map<String, Object?>>()) {
      inbox.add(InboxItem.fromJson(e), toast: false);
    }
    await FlutterForegroundTask.removeData(key: _kEvents);
  }

  /// Starts watching. Returns a note for the user when running in reduced mode.
  Future<String?> start(AlertSettings s, String baseUrl) async {
    await stop();
    _initService();
    active = s;
    status = const AlertStatus();
    _alertId = DateTime.now().millisecondsSinceEpoch.toString();
    notifyListeners();

    final granted = await SystemNotifications.instance.requestPermission();
    await FlutterForegroundTask.saveData(key: _kSettings, value: jsonEncode(s.toJson()));
    await FlutterForegroundTask.saveData(key: _kBaseUrl, value: baseUrl);
    await FlutterForegroundTask.saveData(key: _kId, value: _alertId);
    await FlutterForegroundTask.removeData(key: _kState);

    if (granted) {
      final r = await FlutterForegroundTask.startService(
        serviceId: 4242,
        serviceTypes: [ForegroundServiceTypes.dataSync],
        notificationTitle: 'Watching ${s.stopName}',
        notificationText: 'You will be alerted at ${formatDistance(s.thresholdM)}',
        notificationButtons: const [NotificationButton(id: _stopButton, text: 'Stop alert')],
        callback: alertTaskCallback,
      );
      if (r is ServiceRequestSuccess) {
        inBackgroundService = true;
        notifyListeners();
        return null;
      }
    }
    // Fallback: watch from the UI isolate (works while the app is open).
    inBackgroundService = false;
    _local = AlertMonitor(FindMyBusApi(baseUrl), s);
    _localTimer = Timer.periodic(const Duration(milliseconds: _pollMs), (_) => _localTick());
    unawaited(_localTick());
    notifyListeners();
    return granted
        ? 'Background tracking is unavailable, keep the app open for alerts.'
        : 'Notifications are off, so alerts only show inside the app.';
  }

  bool _localBusy = false;
  Future<void> _localTick() async {
    final m = _local;
    if (m == null || _localBusy) return;
    _localBusy = true;
    try {
      final u = await m.tick();
      for (final e in u.events) {
        final (title, body) = describeEvent(m.settings, e);
        final id = '$_alertId-${e.kind.name}';
        inbox.add(InboxItem(id: id, title: title, body: body, time: DateTime.now()));
        unawaited(SystemNotifications.instance
            .show(id.hashCode & 0x7fffffff, title, body)
            .catchError((_) {}));
      }
      _onTaskData(u.toMessage());
      if (u.phase == AlertPhase.finished) {
        _localTimer?.cancel();
        _local = null;
      }
    } finally {
      _localBusy = false;
    }
  }

  Future<void> stop() async {
    _localTimer?.cancel();
    _localTimer = null;
    _local?.api.close();
    _local = null;
    if (inBackgroundService || await FlutterForegroundTask.isRunningService) {
      await FlutterForegroundTask.stopService();
    }
    await clearSavedAlert();
    inBackgroundService = false;
    if (active != null) {
      active = null;
      status = const AlertStatus();
      notifyListeners();
    }
  }

  void _onTaskData(Object data) {
    if (data is! Map) return;
    switch (data['type']) {
      case 'tick':
        final etaS = data['etaS'] as int?;
        status = AlertStatus(
          phase: AlertPhase.values.byName(data['phase'] as String),
          busId: data['busId'] as String?,
          remainingM: (data['remainingM'] as num?)?.toDouble(),
          eta: etaS == null ? null : Duration(seconds: etaS),
          trusted: (data['trusted'] as bool?) ?? true,
          error: data['error'] as String?,
        );
        if (status.phase == AlertPhase.finished) inBackgroundService = false;
        notifyListeners();
      case 'event':
        inbox.add(InboxItem.fromJson(Map<String, Object?>.from(data)));
      case 'stopped':
        active = null;
        inBackgroundService = false;
        status = const AlertStatus();
        notifyListeners();
    }
  }

  /// Clears a finished alert from the screen.
  void dismissFinished() {
    if (status.phase == AlertPhase.finished) {
      active = null;
      status = const AlertStatus();
      clearSavedAlert();
      notifyListeners();
    }
  }

  @override
  void dispose() {
    FlutterForegroundTask.removeTaskDataCallback(_onTaskData);
    _localTimer?.cancel();
    super.dispose();
  }
}
