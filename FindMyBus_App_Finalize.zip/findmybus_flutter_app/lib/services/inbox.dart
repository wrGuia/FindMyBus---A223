// In-app notification history + a stream for on-screen toasts.
import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class InboxItem {
  InboxItem({
    required this.id,
    required this.title,
    required this.body,
    required this.time,
    this.read = false,
  });

  factory InboxItem.fromJson(Map<String, Object?> j) => InboxItem(
        id: j['id'] as String,
        title: j['title'] as String,
        body: j['body'] as String,
        time: DateTime.fromMillisecondsSinceEpoch((j['time'] as num).toInt()),
        read: (j['read'] as bool?) ?? false,
      );

  final String id;
  final String title;
  final String body;
  final DateTime time;
  bool read;

  Map<String, Object?> toJson() => {
        'id': id,
        'title': title,
        'body': body,
        'time': time.millisecondsSinceEpoch,
        'read': read,
      };
}

class Inbox extends ChangeNotifier {
  static const _key = 'inbox_v1';
  static const _max = 50;

  final List<InboxItem> _items = [];
  final StreamController<InboxItem> _toasts = StreamController.broadcast();

  List<InboxItem> get items => List.unmodifiable(_items);
  int get unread => _items.where((i) => !i.read).length;

  /// New items to flash on screen.
  Stream<InboxItem> get toasts => _toasts.stream;

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null) return;
    try {
      _items
        ..clear()
        ..addAll((jsonDecode(raw) as List)
            .cast<Map<String, Object?>>()
            .map(InboxItem.fromJson));
      notifyListeners();
    } catch (_) {
      // Corrupt history is not worth crashing for.
    }
  }

  /// Adds an item unless one with the same id exists. Returns true if added.
  bool add(InboxItem item, {bool toast = true}) {
    if (_items.any((i) => i.id == item.id)) return false;
    _items.insert(0, item);
    if (_items.length > _max) _items.removeRange(_max, _items.length);
    if (toast) _toasts.add(item);
    _save();
    notifyListeners();
    return true;
  }

  void markAllRead() {
    if (unread == 0) return;
    for (final i in _items) {
      i.read = true;
    }
    _save();
    notifyListeners();
  }

  void clear() {
    _items.clear();
    _save();
    notifyListeners();
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(_items.map((i) => i.toJson()).toList()));
  }

  @override
  void dispose() {
    _toasts.close();
    super.dispose();
  }
}
