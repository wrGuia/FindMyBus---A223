// One alert being watched: polls the API, runs ETA + alert engine.
// Same class runs in the background service or, as a fallback, in the UI.
import '../core/approach_alert.dart';
import '../core/eta.dart';
import '../data/api_client.dart';
import '../data/models.dart';
import 'arrivals.dart';

class MonitorUpdate {
  const MonitorUpdate({
    required this.events,
    required this.focus,
    required this.phase,
    this.error,
  });

  final List<AlertEvent> events;
  final BusApproach? focus;
  final AlertPhase phase;
  final String? error;

  Map<String, Object?> toMessage() => {
        'type': 'tick',
        'phase': phase.name,
        'busId': focus?.busId,
        'remainingM': focus?.remainingM,
        'etaS': focus?.eta.inSeconds,
        'trusted': focus?.trusted,
        'error': error,
      };
}

class AlertMonitor {
  AlertMonitor(this.api, this.settings, {Map<String, Object?>? savedState})
      : engine = AlertEngine(settings) {
    if (savedState != null) engine.restoreState(savedState);
  }

  final FindMyBusApi api;
  final AlertSettings settings;
  final AlertEngine engine;
  final SpeedSmoother _speeds = SpeedSmoother();
  RouteDetail? _route;

  Future<MonitorUpdate> tick() async {
    try {
      final route = _route ??= await api.route(settings.routeId);
      final snap = await api.buses(settings.routeId);
      final views = buildBusViews(route, snap, _speeds);
      final approaches = approachesFor(settings, route, views);
      final events = engine.evaluate(approaches);
      return MonitorUpdate(
          events: events, focus: engine.focus(approaches), phase: engine.phase);
    } on ApiException catch (e) {
      return MonitorUpdate(
          events: const [], focus: null, phase: engine.phase, error: e.message);
    }
  }
}

/// Notification texts, shared by the system and in-app notifications.
(String, String) describeEvent(AlertSettings s, AlertEvent e) {
  final bus = e.busId.startsWith('Bus ') ? e.busId : 'Bus ${e.busId}';
  switch (e.kind) {
    case AlertEventKind.approaching:
      return (
        '$bus is approaching ${s.stopName}',
        '${formatDistance(e.remainingM)} away · about ${formatEta(e.eta)}. Get ready!'
      );
    case AlertEventKind.arriving:
      return ('$bus is arriving now', 'It is pulling into ${s.stopName}.');
    case AlertEventKind.passed:
      return ('$bus has passed ${s.stopName}', 'Your alert has ended.');
  }
}
