// The passenger's position (asked once, on demand; no continuous tracking).
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';

enum LocationProblem { serviceOff, denied, deniedForever }

class LocationResult {
  const LocationResult(this.position, this.problem);
  final LatLng? position;
  final LocationProblem? problem;
}

class LocationService {
  Future<LocationResult> current() async {
    if (!await Geolocator.isLocationServiceEnabled()) {
      return const LocationResult(null, LocationProblem.serviceOff);
    }
    var perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) {
      perm = await Geolocator.requestPermission();
    }
    if (perm == LocationPermission.denied) {
      return const LocationResult(null, LocationProblem.denied);
    }
    if (perm == LocationPermission.deniedForever) {
      return const LocationResult(null, LocationProblem.deniedForever);
    }
    // A recent cached fix is good enough and returns instantly.
    final last = await Geolocator.getLastKnownPosition();
    if (last != null &&
        DateTime.now().difference(last.timestamp) < const Duration(minutes: 2)) {
      return LocationResult(LatLng(last.latitude, last.longitude), null);
    }
    final p = await Geolocator.getCurrentPosition(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high,
        timeLimit: Duration(seconds: 15),
      ),
    );
    return LocationResult(LatLng(p.latitude, p.longitude), null);
  }

  Future<void> openSettings() => Geolocator.openAppSettings();
}
