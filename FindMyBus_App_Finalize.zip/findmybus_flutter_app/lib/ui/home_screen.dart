import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';

import '../services/location_service.dart';
import 'app_scope.dart';
import 'notifications_screen.dart';
import 'search_screen.dart';
import 'settings_screen.dart';
import 'theme.dart';
import 'widgets/alert_widgets.dart';
import 'widgets/bus_map.dart';
import 'widgets/sheets.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with WidgetsBindingObserver {
  final MapController _map = MapController();
  final DraggableScrollableController _sheet = DraggableScrollableController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    final scope = AppScope.of(context);
    if (s == AppLifecycleState.resumed) {
      scope.state.resume();
      scope.alerts.drainEvents();
    } else if (s == AppLifecycleState.paused || s == AppLifecycleState.hidden) {
      scope.state.pause();
    }
  }

  Future<void> _openSearch() async {
    final scope = AppScope.of(context);
    final result = await Navigator.push<SearchResult>(
      context,
      MaterialPageRoute(builder: (_) => SearchScreen(state: scope.state)),
    );
    if (result == null || !mounted) return;
    if (result.stopIndex == null) {
      scope.state.selectRoute(result.routeId);
    } else {
      final note = scope.state.planTo(result.routeId, result.stopIndex!);
      if (note != null && mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(note), behavior: SnackBarBehavior.floating));
      }
    }
    if (_sheet.isAttached) {
      _sheet.animateTo(0.45, duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
    }
  }

  void _openInbox() {
    final scope = AppScope.of(context);
    Navigator.push(context, MaterialPageRoute(builder: (_) => NotificationsScreen(inbox: scope.inbox)));
  }

  Future<void> _locate() async {
    final s = AppScope.of(context).state;
    final problem = await s.locate();
    if (!mounted) return;
    if (s.userLocation != null) {
      _map.move(s.userLocation!, 15);
    } else if (problem != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        behavior: SnackBarBehavior.floating,
        content: Text(switch (problem) {
          LocationProblem.serviceOff => 'Turn on location services to see stops near you.',
          LocationProblem.denied => 'Location permission is needed to find stops near you.',
          LocationProblem.deniedForever => 'Location is blocked for FindMyBus. Enable it in Settings.',
        }),
        action: problem == LocationProblem.deniedForever
            ? SnackBarAction(label: 'Settings', onPressed: s.openLocationSettings)
            : null,
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    final scope = AppScope.of(context);
    final state = scope.state;
    final height = MediaQuery.sizeOf(context).height;

    return ListenableBuilder(
      listenable: state,
      builder: (context, _) {
        final route = state.selectedRoute;
        final bus = state.selectedBus;
        return PopScope(
          canPop: route == null,
          onPopInvokedWithResult: (didPop, _) {
            if (didPop) return;
            if (bus != null) {
              state.selectBus(null);
            } else {
              state.clearRoute();
            }
          },
          child: Scaffold(
            body: ToastHost(
              inbox: scope.inbox,
              onOpen: _openInbox,
              child: Stack(children: [
                Positioned.fill(
                  child: BusMap(state: state, controller: _map, bottomPadding: height * 0.42),
                ),
                // Search bar + alert banner
                Positioned(
                  left: 12,
                  right: 12,
                  top: 0,
                  child: SafeArea(
                    child: Column(children: [
                      const SizedBox(height: 8),
                      _TopBar(onSearch: _openSearch, onInbox: _openInbox),
                      const SizedBox(height: 8),
                      ActiveAlertBanner(alerts: scope.alerts),
                      if (state.error != null && state.routes.isNotEmpty) ...[
                        const SizedBox(height: 8),
                        _OfflineStrip(message: state.error!),
                      ],
                    ]),
                  ),
                ),
                // Map buttons, riding just above the sheet.
                AnimatedBuilder(
                  animation: _sheet,
                  builder: (context, child) {
                    final size = _sheet.isAttached ? _sheet.size : 0.38;
                    return Positioned(
                      right: 12,
                      bottom: height * size + 12,
                      // Hidden when the sheet is pulled up over the map.
                      child: IgnorePointer(
                        ignoring: size > 0.65,
                        child: AnimatedOpacity(
                          opacity: size > 0.65 ? 0 : 1,
                          duration: const Duration(milliseconds: 150),
                          child: child,
                        ),
                      ),
                    );
                  },
                  child: _MapButton(icon: Icons.my_location_rounded, tooltip: 'My location', onTap: _locate),
                ),
                DraggableScrollableSheet(
                  controller: _sheet,
                  initialChildSize: 0.38,
                  minChildSize: 0.18,
                  maxChildSize: 0.92,
                  snap: true,
                  snapSizes: const [0.38, 0.6],
                  builder: (context, scroll) => DecoratedBox(
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
                      boxShadow: [BoxShadow(color: Color(0x22000000), blurRadius: 16, offset: Offset(0, -2))],
                    ),
                    child: AnimatedSwitcher(
                      duration: const Duration(milliseconds: 220),
                      child: route == null
                          ? OverviewSheet(key: const ValueKey('overview'), state: state, scroll: scroll)
                          : bus != null
                              ? BusSheet(key: ValueKey('bus-${bus.bus.id}'), state: state, route: route, view: bus, scroll: scroll)
                              : RouteSheet(key: ValueKey('route-${route.id}'), state: state, route: route, scroll: scroll),
                    ),
                  ),
                ),
              ]),
            ),
          ),
        );
      },
    );
  }
}

class _TopBar extends StatelessWidget {
  const _TopBar({required this.onSearch, required this.onInbox});
  final VoidCallback onSearch;
  final VoidCallback onInbox;

  @override
  Widget build(BuildContext context) {
    final inbox = AppScope.of(context).inbox;
    return Row(children: [
      Expanded(
        child: Material(
          color: Colors.white,
          elevation: 3,
          shadowColor: const Color(0x44000000),
          borderRadius: BorderRadius.circular(28),
          child: InkWell(
            borderRadius: BorderRadius.circular(28),
            onTap: onSearch,
            child: const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              child: Row(children: [
                Icon(Icons.search_rounded, color: AppColors.green),
                SizedBox(width: 10),
                Expanded(
                  child: Text('Where are you going?',
                      style: TextStyle(color: AppColors.muted, fontSize: 16, fontWeight: FontWeight.w500)),
                ),
              ]),
            ),
          ),
        ),
      ),
      const SizedBox(width: 8),
      ListenableBuilder(
        listenable: inbox,
        builder: (context, _) => _MapButton(
          icon: Icons.notifications_none_rounded,
          tooltip: 'Notifications',
          badge: inbox.unread,
          onTap: onInbox,
        ),
      ),
      const SizedBox(width: 8),
      _MapButton(
        icon: Icons.settings_outlined,
        tooltip: 'Settings',
        onTap: () => Navigator.push(
            context, MaterialPageRoute(builder: (_) => const SettingsScreen())),
      ),
    ]);
  }
}

class _MapButton extends StatelessWidget {
  const _MapButton({required this.icon, required this.tooltip, required this.onTap, this.badge = 0});
  final IconData icon;
  final String tooltip;
  final VoidCallback onTap;
  final int badge;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      shape: const CircleBorder(),
      elevation: 3,
      shadowColor: const Color(0x44000000),
      child: IconButton(
        tooltip: tooltip,
        onPressed: onTap,
        icon: Badge(
          isLabelVisible: badge > 0,
          label: Text('$badge'),
          backgroundColor: AppColors.trafficHeavy,
          child: Icon(icon, color: AppColors.ink),
        ),
      ),
    );
  }
}

class _OfflineStrip extends StatelessWidget {
  const _OfflineStrip({required this.message});
  final String message;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(color: AppColors.ink, borderRadius: BorderRadius.circular(12)),
      child: Row(children: [
        const Icon(Icons.wifi_off_rounded, color: Colors.white, size: 18),
        const SizedBox(width: 8),
        Expanded(
          child: Text('$message. Positions may be out of date.',
              style: const TextStyle(color: Colors.white, fontSize: 13)),
        ),
      ]),
    );
  }
}
