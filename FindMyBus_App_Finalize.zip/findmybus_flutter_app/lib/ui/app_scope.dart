import 'package:flutter/widgets.dart';

import '../services/alert_service.dart';
import '../services/inbox.dart';
import '../state/app_settings.dart';
import '../state/app_state.dart';

/// Hands the app's controllers to every screen.
class AppScope extends InheritedWidget {
  const AppScope({
    super.key,
    required this.state,
    required this.alerts,
    required this.inbox,
    required this.settings,
    required super.child,
  });

  final AppState state;
  final AlertController alerts;
  final Inbox inbox;
  final AppSettings settings;

  static AppScope of(BuildContext context) =>
      context.getInheritedWidgetOfExactType<AppScope>()!;

  @override
  bool updateShouldNotify(AppScope oldWidget) => false;
}
