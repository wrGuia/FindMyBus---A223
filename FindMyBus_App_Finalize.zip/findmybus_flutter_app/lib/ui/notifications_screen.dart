import 'package:flutter/material.dart';

import '../services/inbox.dart';
import 'theme.dart';
import 'widgets/common.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key, required this.inbox});
  final Inbox inbox;

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  @override
  void dispose() {
    widget.inbox.markAllRead();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notifications'),
        actions: [
          ListenableBuilder(
            listenable: widget.inbox,
            builder: (context, _) => widget.inbox.items.isEmpty
                ? const SizedBox.shrink()
                : TextButton(onPressed: widget.inbox.clear, child: const Text('Clear all')),
          ),
        ],
      ),
      body: ListenableBuilder(
        listenable: widget.inbox,
        builder: (context, _) {
          final items = widget.inbox.items;
          if (items.isEmpty) {
            return const Center(
              child: Padding(
                padding: EdgeInsets.all(32),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.notifications_none_rounded, size: 64, color: AppColors.line),
                  SizedBox(height: 12),
                  Text('No notifications yet', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                  SizedBox(height: 4),
                  Text('Set an alert on a route and we will tell you when your bus is close.',
                      textAlign: TextAlign.center, style: TextStyle(color: AppColors.muted)),
                ]),
              ),
            );
          }
          return ListView.separated(
            itemCount: items.length,
            separatorBuilder: (_, _) => const Divider(indent: 72),
            itemBuilder: (_, i) {
              final it = items[i];
              return ListTile(
                leading: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: it.read ? AppColors.surface : AppColors.greenSoft,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(Icons.directions_bus_rounded,
                      color: it.read ? AppColors.muted : AppColors.green),
                ),
                title: Text(it.title,
                    style: TextStyle(fontWeight: it.read ? FontWeight.w500 : FontWeight.w800)),
                subtitle: Text('${it.body}\n${ageText(DateTime.now().difference(it.time))}'),
                isThreeLine: true,
              );
            },
          );
        },
      ),
    );
  }
}
