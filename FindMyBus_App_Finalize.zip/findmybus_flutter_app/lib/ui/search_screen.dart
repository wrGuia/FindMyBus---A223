import 'package:flutter/material.dart';

import '../core/eta.dart';
import '../core/geo.dart';
import '../data/models.dart';
import '../state/app_state.dart';
import 'theme.dart';
import 'widgets/common.dart';

class SearchResult {
  const SearchResult(this.routeId, [this.stopIndex]);
  final String routeId;
  final int? stopIndex;
}

class _StopHit {
  const _StopHit(this.route, this.stop, this.distanceM);
  final RouteDetail route;
  final Stop stop;
  final double? distanceM;
}

/// Search destinations (stops) and routes.
class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key, required this.state});
  final AppState state;

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    final s = widget.state;
    final q = _q.trim().toLowerCase();
    final me = s.userLocation;

    final routes = s.routes
        .where((r) => q.isEmpty || r.code.toLowerCase().contains(q) || r.title.toLowerCase().contains(q))
        .toList();
    final stops = <_StopHit>[
      if (q.isNotEmpty)
        for (final r in s.details.values)
          for (final st in r.stops)
            if (st.name.toLowerCase().contains(q))
              _StopHit(r, st, me == null ? null : haversineM(me, st.position)),
    ]..sort((a, b) => (a.distanceM ?? 0).compareTo(b.distanceM ?? 0));

    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        title: Padding(
          padding: const EdgeInsets.only(right: 16),
          child: TextField(
            autofocus: true,
            textInputAction: TextInputAction.search,
            decoration: const InputDecoration(
              hintText: 'Search a place, stop or route',
              prefixIcon: Icon(Icons.search_rounded),
              isDense: true,
            ),
            onChanged: (v) => setState(() => _q = v),
          ),
        ),
      ),
      body: ListView(padding: const EdgeInsets.symmetric(horizontal: 16), children: [
        if (q.isNotEmpty) ...[
          SectionTitle('Destinations (${stops.length})'),
          if (stops.isEmpty)
            const Text('No stops match. Try a street or area name, like "Koreatown".',
                style: TextStyle(color: AppColors.muted)),
          for (final h in stops.take(30))
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(color: AppColors.greenSoft, borderRadius: BorderRadius.circular(12)),
                child: const Icon(Icons.place_rounded, color: AppColors.green),
              ),
              title: Text(h.stop.name, maxLines: 1, overflow: TextOverflow.ellipsis),
              subtitle: Row(children: [
                RouteBadge(code: h.route.code, color: h.route.color),
                if (h.distanceM != null) ...[
                  const SizedBox(width: 6),
                  Text('${formatDistance(h.distanceM!)} from you',
                      style: const TextStyle(fontSize: 12, color: AppColors.muted)),
                ],
              ]),
              onTap: () => Navigator.pop(context, SearchResult(h.route.id, h.stop.index)),
            ),
        ],
        SectionTitle(q.isEmpty ? 'All routes' : 'Routes (${routes.length})'),
        for (final r in routes)
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: RouteBadge(code: r.code, color: r.color, large: true),
            title: Text(r.title, maxLines: 1, overflow: TextOverflow.ellipsis),
            subtitle: Text('${r.headsigns.rev} – ${r.headsigns.fwd}',
                maxLines: 1, overflow: TextOverflow.ellipsis),
            onTap: () => Navigator.pop(context, SearchResult(r.id)),
          ),
        const SizedBox(height: 24),
      ]),
    );
  }
}
