import 'package:flutter/material.dart';

import '../core/eta.dart';
import '../data/api_client.dart';
import '../state/app_settings.dart';
import 'app_scope.dart';
import 'theme.dart';
import 'widgets/common.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late final TextEditingController _url;
  bool _inited = false;
  String? _test;
  bool _testing = false;
  bool _ok = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_inited) return;
    _inited = true;
    _url = TextEditingController(text: AppScope.of(context).settings.baseUrl);
  }

  @override
  void dispose() {
    _url.dispose();
    super.dispose();
  }

  Future<void> _testAndSave() async {
    final settings = AppScope.of(context).settings;
    final url = FindMyBusApi.normalizeBaseUrl(_url.text);
    setState(() {
      _testing = true;
      _test = null;
    });
    final api = FindMyBusApi(url);
    try {
      _test = await api.status();
      _ok = true;
      await settings.update(baseUrl: url);
      _url.text = url;
    } on ApiException catch (e) {
      _test = e.message;
      _ok = false;
    } finally {
      api.close();
    }
    if (mounted) setState(() => _testing = false);
  }

  @override
  Widget build(BuildContext context) {
    final settings = AppScope.of(context).settings;
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListenableBuilder(
        listenable: settings,
        builder: (context, _) => ListView(padding: const EdgeInsets.fromLTRB(16, 0, 16, 32), children: [
          const SectionTitle('Server'),
          TextField(
            controller: _url,
            keyboardType: TextInputType.url,
            decoration: const InputDecoration(
              labelText: 'FindMyBus server address',
              hintText: 'http://10.0.2.2:8000',
              prefixIcon: Icon(Icons.dns_outlined),
            ),
          ),
          const SizedBox(height: 6),
          const Text(
            'Emulator: http://10.0.2.2:8000 · Phone on the same Wi-Fi: http://<your-PC-IP>:8000 · '
            'Anywhere: your https tunnel or hosted URL.',
            style: TextStyle(fontSize: 12, color: AppColors.muted),
          ),
          const SizedBox(height: 10),
          FilledButton(
            onPressed: _testing ? null : _testAndSave,
            child: Text(_testing ? 'Connecting…' : 'Test & save'),
          ),
          if (_test != null) ...[
            const SizedBox(height: 8),
            Row(children: [
              Icon(_ok ? Icons.check_circle : Icons.error_outline,
                  color: _ok ? AppColors.green : AppColors.trafficHeavy, size: 18),
              const SizedBox(width: 6),
              Expanded(child: Text(_test!)),
            ]),
          ],
          const SectionTitle('Default alert distance'),
          Row(children: [
            Expanded(
              child: Slider(
                value: settings.defaultAlertM,
                min: 100,
                max: 3000,
                divisions: 58,
                label: formatDistance(settings.defaultAlertM),
                onChanged: (v) => settings.update(defaultAlertM: v),
              ),
            ),
            SizedBox(
              width: 64,
              child: Text(formatDistance(settings.defaultAlertM),
                  textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.w700)),
            ),
          ]),
          const SectionTitle('Live update speed'),
          RadioGroup<RefreshRate>(
            groupValue: settings.refreshRate,
            onChanged: (v) => settings.update(refreshRate: v),
            child: Column(children: [
              for (final r in RefreshRate.values)
                RadioListTile<RefreshRate>(
                  contentPadding: EdgeInsets.zero,
                  value: r,
                  title: Text(r.label),
                  subtitle: Text(r.detail),
                ),
            ]),
          ),
          const SectionTitle('About'),
          const Text(
            'FindMyBus shows Los Angeles Metro buses from the LA Metro open real-time API, '
            'via your FindMyBus server. When the live feed is unavailable the server shows '
            'simulated buses, marked "Simulated".\n\nMap data © OpenStreetMap contributors.',
            style: TextStyle(color: AppColors.muted),
          ),
        ]),
      ),
    );
  }
}
