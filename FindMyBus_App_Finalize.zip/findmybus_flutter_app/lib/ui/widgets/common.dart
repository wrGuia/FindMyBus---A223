import 'package:flutter/material.dart';

import '../../core/freshness.dart';
import '../../services/arrivals.dart';
import '../theme.dart';

/// Coloured pill with the route number, e.g. [720].
class RouteBadge extends StatelessWidget {
  const RouteBadge({super.key, required this.code, required this.color, this.large = false});

  final String code;
  final Color color;
  final bool large;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: large ? 12 : 8, vertical: large ? 6 : 3),
      decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(8)),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(Icons.directions_bus_rounded, size: large ? 18 : 14, color: Colors.white),
        const SizedBox(width: 4),
        Text(code,
            style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w800,
                fontSize: large ? 16 : 13)),
      ]),
    );
  }
}

class Pill extends StatelessWidget {
  const Pill(this.text, {super.key, required this.color, this.icon, this.filled = false});

  final String text;
  final Color color;
  final IconData? icon;
  final bool filled;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: filled ? color : color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        if (icon != null) ...[
          Icon(icon, size: 12, color: filled ? Colors.white : color),
          const SizedBox(width: 3),
        ],
        Text(text,
            style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: filled ? Colors.white : color)),
      ]),
    );
  }
}

/// Live / Simulated badge for a route's data source.
class SourcePill extends StatelessWidget {
  const SourcePill(this.source, {super.key});
  final String source;

  @override
  Widget build(BuildContext context) {
    return switch (source) {
      'live' => const Pill('Live GPS', color: AppColors.green, icon: Icons.sensors),
      'mixed' => const Pill('Partly live', color: AppColors.green, icon: Icons.sensors),
      'empty' => const Pill('No buses running', color: AppColors.muted),
      'simulated' => const Pill('Simulated', color: AppColors.delayed, icon: Icons.science_outlined),
      _ => const SizedBox.shrink(),
    };
  }
}

/// Status chips for one bus: on time/delayed, off route, signal freshness.
class BusStatusPills extends StatelessWidget {
  const BusStatusPills(this.view, {super.key});
  final BusView view;

  @override
  Widget build(BuildContext context) {
    final b = view.bus;
    return Wrap(spacing: 6, runSpacing: 4, children: [
      if (view.freshness == Freshness.offline)
        const Pill('Offline', color: AppColors.stale, icon: Icons.signal_wifi_off)
      else if (view.freshness == Freshness.stale)
        Pill('Last seen ${ageText(view.age)}', color: AppColors.stale, icon: Icons.history)
      else if (b.status == 'Delayed')
        const Pill('Delayed', color: AppColors.delayed)
      else
        const Pill('On time', color: AppColors.green),
      if (b.deviation) const Pill('Off route', color: AppColors.trafficHeavy, icon: Icons.alt_route),
      if (b.direction == null) const Pill('Finding direction…', color: AppColors.muted),
    ]);
  }
}

String ageText(Duration d) {
  if (d.inSeconds < 60) return '${d.inSeconds}s ago';
  if (d.inMinutes < 60) return '${d.inMinutes} min ago';
  return '${d.inHours} h ago';
}

class SheetHandle extends StatelessWidget {
  const SheetHandle({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        margin: const EdgeInsets.only(top: 10, bottom: 8),
        width: 40,
        height: 4,
        decoration: BoxDecoration(color: AppColors.line, borderRadius: BorderRadius.circular(2)),
      ),
    );
  }
}

class SectionTitle extends StatelessWidget {
  const SectionTitle(this.text, {super.key, this.trailing});
  final String text;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(0, 18, 0, 8),
      child: Row(children: [
        Expanded(
          child: Text(text,
              style: const TextStyle(
                  fontSize: 16, fontWeight: FontWeight.w700, color: AppColors.ink)),
        ),
        ?trailing,
      ]),
    );
  }
}

/// Small coloured square with a bus icon, used in lists and on the map.
class BusIcon extends StatelessWidget {
  const BusIcon({super.key, required this.color, this.size = 36});
  final Color color;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(size * 0.3),
        border: Border.all(color: Colors.white, width: 2),
        boxShadow: const [BoxShadow(color: Color(0x33000000), blurRadius: 4, offset: Offset(0, 1))],
      ),
      child: Icon(Icons.directions_bus_rounded, color: Colors.white, size: size * 0.6),
    );
  }
}

Color busColor(BusView v) {
  if (v.freshness != Freshness.live) return AppColors.stale;
  if (v.bus.deviation || v.bus.status == 'Delayed') return AppColors.delayed;
  return AppColors.green;
}

class TrafficLegend extends StatelessWidget {
  const TrafficLegend({super.key});

  @override
  Widget build(BuildContext context) {
    Widget item(Color c, String t) => Row(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 18, height: 5, decoration: BoxDecoration(color: c, borderRadius: BorderRadius.circular(3))),
          const SizedBox(width: 6),
          Text(t, style: const TextStyle(fontSize: 12, color: AppColors.muted)),
        ]);
    return Wrap(spacing: 14, runSpacing: 6, children: [
      item(AppColors.trafficHeavy, 'Heavy traffic'),
      item(AppColors.trafficLight, 'Light traffic'),
      item(AppColors.routeBase, 'Clear / no report'),
    ]);
  }
}
