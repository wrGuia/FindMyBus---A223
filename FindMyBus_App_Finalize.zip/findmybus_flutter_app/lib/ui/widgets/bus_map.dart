// The live map: route lines with traffic colours, stops, animated buses, you.
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

import '../../core/traffic.dart';
import '../../data/models.dart';
import '../../services/arrivals.dart';
import '../../state/app_state.dart';
import '../theme.dart';
import 'common.dart';

const _losAngeles = LatLng(34.0522, -118.2937);

/// Tests swap the network tile source for an offline one.
@visibleForTesting
TileProvider? debugTileProvider;

class BusMap extends StatefulWidget {
  const BusMap({super.key, required this.state, required this.controller, this.bottomPadding = 0});

  final AppState state;
  final MapController controller;

  /// Height covered by the bottom sheet, so fitted routes stay visible.
  final double bottomPadding;

  @override
  State<BusMap> createState() => _BusMapState();
}

class _BusMapState extends State<BusMap> {
  // Polylines are rebuilt only when the data version changes.
  int _builtVersion = -1;
  List<Polyline> _lines = const [];
  String? _fittedRoute;

  AppState get s => widget.state;

  @override
  void initState() {
    super.initState();
    s.addListener(_onState);
  }

  @override
  void dispose() {
    s.removeListener(_onState);
    super.dispose();
  }

  void _onState() {
    if (!mounted) return;
    final id = s.selectedRouteId;
    if (id != null && id != _fittedRoute && s.details[id] != null) {
      _fittedRoute = id;
      WidgetsBinding.instance.addPostFrameCallback((_) => _fitRoute(s.details[id]!));
    } else if (id == null) {
      _fittedRoute = null;
    }
    final follow = s.followBus ? s.selectedBus : null;
    if (follow != null) {
      widget.controller.move(follow.bus.position, widget.controller.camera.zoom);
    }
    setState(() {});
  }

  void _fitRoute(RouteDetail r) {
    if (r.path.isEmpty) return;
    widget.controller.fitCamera(CameraFit.bounds(
      bounds: LatLngBounds.fromPoints(r.path.points),
      padding: EdgeInsets.fromLTRB(40, 160, 40, widget.bottomPadding + 30),
    ));
  }

  List<Polyline> _buildLines() {
    final sel = s.selectedRoute;
    if (sel == null) {
      // Overview: every route in its own colour.
      return [
        for (final r in s.details.values)
          Polyline(
            points: r.path.points,
            color: r.color.withValues(alpha: 0.85),
            strokeWidth: 4,
            borderColor: Colors.white,
            borderStrokeWidth: 1.5,
          ),
      ];
    }
    final lines = <Polyline>[
      Polyline(
        points: sel.path.points,
        color: AppColors.routeBase,
        strokeWidth: 6,
        borderColor: Colors.white,
        borderStrokeWidth: 2,
      ),
    ];
    for (final seg in s.trafficOf(sel.id)) {
      if (seg.level != TrafficLevel.light && seg.level != TrafficLevel.heavy) continue;
      lines.add(Polyline(
        points: sel.path.slice(seg.startM, seg.endM),
        color: AppColors.traffic(seg.level),
        strokeWidth: 6,
      ));
    }
    return lines;
  }

  @override
  Widget build(BuildContext context) {
    if (_builtVersion != s.version) {
      _builtVersion = s.version;
      _lines = _buildLines();
    }
    final sel = s.selectedRoute;
    // Buses are only shown once the passenger opens a route.
    final buses = sel != null ? s.viewsOf(sel.id) : const <BusView>[];

    return FlutterMap(
      mapController: widget.controller,
      options: MapOptions(
        initialCenter: s.userLocation ?? _losAngeles,
        initialZoom: 12,
        minZoom: 9,
        maxZoom: 18,
        interactionOptions: const InteractionOptions(
          flags: InteractiveFlag.all & ~InteractiveFlag.rotate,
        ),
        onPositionChanged: (_, hasGesture) {
          if (hasGesture && s.followBus) s.setFollow(false);
        },
      ),
      children: [
        TileLayer(
          urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
          userAgentPackageName: 'com.findmybus.findmybus',
          maxNativeZoom: 19,
          tileProvider: debugTileProvider,
        ),
        PolylineLayer(polylines: _lines),
        if (sel != null) _StopsLayer(route: sel, state: s),
        if (s.userLocation != null)
          MarkerLayer(markers: [
            Marker(point: s.userLocation!, width: 28, height: 28, child: const _UserDot()),
          ]),
        _AnimatedBuses(
          buses: buses,
          selectedId: s.selectedBusId,
          onTap: (v) {
            if (s.selectedRouteId != v.bus.routeId) s.selectRoute(v.bus.routeId);
            s.selectBus(v.bus.id);
          },
        ),
        const Align(
          alignment: Alignment.topRight,
          child: Padding(
            padding: EdgeInsets.only(top: 120, right: 6),
            child: Text('© OpenStreetMap',
                style: TextStyle(fontSize: 10, color: Color(0x99000000))),
          ),
        ),
      ],
    );
  }
}

class _StopsLayer extends StatelessWidget {
  const _StopsLayer({required this.route, required this.state});
  final RouteDetail route;
  final AppState state;

  @override
  Widget build(BuildContext context) {
    final zoom = MapCamera.of(context).zoom;
    final mine = state.myStopIndex;
    final dest = state.destinationStopIndex;
    final markers = <Marker>[];
    for (final st in route.stops) {
      final isMine = st.index == mine;
      final isDest = st.index == dest;
      // Hide ordinary stops when zoomed far out, to keep the map readable.
      if (!isMine && !isDest && zoom < 12.5) continue;
      markers.add(Marker(
        point: st.position,
        width: isMine || isDest ? 36 : 16,
        height: isMine || isDest ? 36 : 16,
        alignment: isMine || isDest ? Alignment.topCenter : Alignment.center,
        child: GestureDetector(
          onTap: () => state.setMyStop(st.index),
          child: isDest
              ? const Icon(Icons.flag_rounded, color: AppColors.trafficHeavy, size: 34)
              : isMine
                  ? const Icon(Icons.location_on_rounded, color: AppColors.green, size: 36)
                  : Container(
                      decoration: BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                        border: Border.all(color: AppColors.routeBase, width: 3),
                      ),
                    ),
        ),
      ));
    }
    return MarkerLayer(markers: markers);
  }
}

class _UserDot extends StatelessWidget {
  const _UserDot();

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.userDot.withValues(alpha: 0.18),
        shape: BoxShape.circle,
      ),
      alignment: Alignment.center,
      child: Container(
        width: 14,
        height: 14,
        decoration: BoxDecoration(
          color: AppColors.userDot,
          shape: BoxShape.circle,
          border: Border.all(color: Colors.white, width: 2.5),
        ),
      ),
    );
  }
}

/// Glides buses from their previous to their new position instead of jumping.
class _AnimatedBuses extends StatefulWidget {
  const _AnimatedBuses({required this.buses, required this.selectedId, required this.onTap});

  final List<BusView> buses;
  final String? selectedId;
  final ValueChanged<BusView> onTap;

  @override
  State<_AnimatedBuses> createState() => _AnimatedBusesState();
}

class _AnimatedBusesState extends State<_AnimatedBuses> with SingleTickerProviderStateMixin {
  late final AnimationController _anim =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 1200));
  final Map<String, LatLng> _from = {};
  final Map<String, LatLng> _to = {};

  @override
  void initState() {
    super.initState();
    for (final v in widget.buses) {
      _from[v.bus.id] = _to[v.bus.id] = v.bus.position;
    }
    _anim.value = 1;
  }

  @override
  void didUpdateWidget(covariant _AnimatedBuses old) {
    super.didUpdateWidget(old);
    var moved = false;
    final t = Curves.easeInOut.transform(_anim.value);
    final ids = <String>{};
    for (final v in widget.buses) {
      final id = v.bus.id;
      ids.add(id);
      final current = _lerp(_from[id], _to[id], t) ?? v.bus.position;
      if (_to[id] != v.bus.position) moved = true;
      _from[id] = current;
      _to[id] = v.bus.position;
    }
    _from.removeWhere((k, _) => !ids.contains(k));
    _to.removeWhere((k, _) => !ids.contains(k));
    if (moved) _anim.forward(from: 0);
  }

  LatLng? _lerp(LatLng? a, LatLng? b, double t) {
    if (a == null || b == null) return b ?? a;
    return LatLng(a.latitude + (b.latitude - a.latitude) * t,
        a.longitude + (b.longitude - a.longitude) * t);
  }

  @override
  void dispose() {
    _anim.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _anim,
      builder: (context, _) {
        final t = Curves.easeInOut.transform(_anim.value);
        return MarkerLayer(markers: [
          for (final v in widget.buses)
            Marker(
              point: _lerp(_from[v.bus.id], _to[v.bus.id], t) ?? v.bus.position,
              width: v.bus.id == widget.selectedId ? 96 : 40,
              height: v.bus.id == widget.selectedId ? 64 : 40,
              child: GestureDetector(
                onTap: () => widget.onTap(v),
                child: v.bus.id == widget.selectedId
                    ? Column(mainAxisSize: MainAxisSize.min, children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: AppColors.ink,
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(v.bus.label,
                              style: const TextStyle(
                                  color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700)),
                        ),
                        const SizedBox(height: 2),
                        BusIcon(color: busColor(v), size: 38),
                      ])
                    : BusIcon(color: busColor(v), size: 32),
              ),
            ),
        ]);
      },
    );
  }
}
