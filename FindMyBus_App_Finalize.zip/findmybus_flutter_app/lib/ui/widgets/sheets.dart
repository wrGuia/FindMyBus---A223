// Bottom-sheet contents: overview, one route, one bus.
import 'package:flutter/material.dart';

import '../../core/eta.dart';
import '../../core/freshness.dart';
import '../../data/models.dart';
import '../../services/arrivals.dart';
import '../../services/location_service.dart';
import '../../state/app_state.dart';
import '../app_scope.dart';
import '../theme.dart';
import 'alert_widgets.dart';
import 'common.dart';

String _greeting() {
  final h = DateTime.now().hour;
  if (h < 12) return 'Good morning';
  if (h < 18) return 'Good afternoon';
  return 'Good evening';
}

// ------------------------------------------------------------------ overview

class OverviewSheet extends StatelessWidget {
  const OverviewSheet({super.key, required this.state, required this.scroll});
  final AppState state;
  final ScrollController scroll;

  @override
  Widget build(BuildContext context) {
    final s = state;
    final near = s.nearestStop;
    return ListView(controller: scroll, padding: const EdgeInsets.fromLTRB(16, 0, 16, 24), children: [
      const SheetHandle(),
      Text('${_greeting()} 👋', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
      const SizedBox(height: 2),
      const Text('Which bus are you catching today?', style: TextStyle(color: AppColors.muted)),
      if (s.loading) ...[
        const SizedBox(height: 32),
        const Center(child: CircularProgressIndicator()),
      ] else if (s.routes.isEmpty && s.error != null) ...[
        const SizedBox(height: 16),
        _ErrorCard(message: s.error!, onRetry: s.loadRoutes),
      ] else ...[
        if (near != null) ...[
          const SectionTitle('Nearest stop'),
          _NearestStopCard(near: near, state: s),
        ] else if (s.locationProblem != null) ...[
          const SizedBox(height: 14),
          _LocationHint(state: s),
        ],
        const SectionTitle('Routes'),
        for (final r in s.routes) ...[
          _RouteCard(route: r, state: s),
          const SizedBox(height: 10),
        ],
      ],
    ]);
  }
}

class _ErrorCard extends StatelessWidget {
  const _ErrorCard({required this.message, required this.onRetry});
  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Row(children: [
            Icon(Icons.cloud_off_rounded, color: AppColors.trafficHeavy),
            SizedBox(width: 8),
            Text('Can\'t load buses', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          ]),
          const SizedBox(height: 6),
          Text(message, style: const TextStyle(color: AppColors.muted)),
          const SizedBox(height: 4),
          const Text('Check the server address in Settings and that the Django server is running.',
              style: TextStyle(color: AppColors.muted, fontSize: 13)),
          const SizedBox(height: 12),
          OutlinedButton.icon(onPressed: onRetry, icon: const Icon(Icons.refresh), label: const Text('Try again')),
        ]),
      ),
    );
  }
}

class _LocationHint extends StatelessWidget {
  const _LocationHint({required this.state});
  final AppState state;

  @override
  Widget build(BuildContext context) {
    final forever = state.locationProblem == LocationProblem.deniedForever;
    return Card(
      color: AppColors.surface,
      child: ListTile(
        leading: const Icon(Icons.my_location_rounded, color: AppColors.userDot),
        title: const Text('Find stops near you'),
        subtitle: Text(state.locationProblem == LocationProblem.serviceOff
            ? 'Turn on location services'
            : 'Allow location access'),
        trailing: const Icon(Icons.chevron_right),
        onTap: forever ? state.openLocationSettings : () => state.locate(),
      ),
    );
  }
}

class _NearestStopCard extends StatelessWidget {
  const _NearestStopCard({required this.near, required this.state});
  final NearestStop near;
  final AppState state;

  @override
  Widget build(BuildContext context) {
    final r = near.route;
    final walkMin = (near.distanceM / 80).ceil(); // ~4.8 km/h walking
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => state.selectRoute(r.id, stopIndex: near.stop.index),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(color: AppColors.greenSoft, borderRadius: BorderRadius.circular(12)),
              child: const Icon(Icons.hail_rounded, color: AppColors.green),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(near.stop.name,
                    maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                const SizedBox(height: 3),
                Row(children: [
                  RouteBadge(code: r.code, color: r.color),
                  const SizedBox(width: 6),
                  Flexible(
                    child: Text('${formatDistance(near.distanceM)} · $walkMin min walk',
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: AppColors.muted, fontSize: 13)),
                  ),
                ]),
              ]),
            ),
          ]),
        ),
      ),
    );
  }
}

class _RouteCard extends StatelessWidget {
  const _RouteCard({required this.route, required this.state});
  final RouteSummary route;
  final AppState state;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => state.selectRoute(route.id),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              RouteBadge(code: route.code, color: route.color, large: true),
              const SizedBox(width: 10),
              Expanded(
                child: Text(route.title,
                    maxLines: 2, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w700)),
              ),
              const Icon(Icons.chevron_right, color: AppColors.muted),
            ]),
            const SizedBox(height: 10),
            Row(children: [
              const Icon(Icons.swap_horiz_rounded, size: 16, color: AppColors.muted),
              const SizedBox(width: 4),
              Expanded(
                child: Text('${route.headsigns.rev}  –  ${route.headsigns.fwd}',
                    maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: AppColors.muted, fontSize: 13)),
              ),
            ]),
          ]),
        ),
      ),
    );
  }
}

// ------------------------------------------------------------------ one route

class RouteSheet extends StatelessWidget {
  const RouteSheet({super.key, required this.state, required this.route, required this.scroll});
  final AppState state;
  final RouteDetail route;
  final ScrollController scroll;

  @override
  Widget build(BuildContext context) {
    final s = state;
    final dir = s.direction;
    final stopIdx = s.myStopIndex;
    final views = s.viewsOf(route.id).where((v) => v.bus.direction == dir).toList();
    final arrivals = stopIdx == null ? const <BusEta>[] : s.arrivalsAt(route.id, stopIdx, dir);
    final source = s.snapshotOf(route.id)?.source ?? 'unknown';
    final ordered = dir == 'fwd' ? route.stops : route.stops.reversed.toList();

    return ListView(controller: scroll, padding: const EdgeInsets.fromLTRB(16, 0, 16, 24), children: [
      const SheetHandle(),
      Row(children: [
        RouteBadge(code: route.code, color: route.color, large: true),
        const SizedBox(width: 10),
        Expanded(
          child: Text(route.title,
              maxLines: 2, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
        ),
        IconButton(
          tooltip: 'Close route',
          onPressed: s.clearRoute,
          icon: const Icon(Icons.close_rounded),
        ),
      ]),
      Row(children: [SourcePill(source)]),
      const SizedBox(height: 12),
      SegmentedButton<String>(
        showSelectedIcon: false,
        style: SegmentedButton.styleFrom(
          selectedBackgroundColor: AppColors.greenSoft,
          selectedForegroundColor: AppColors.greenDark,
        ),
        segments: [
          ButtonSegment(value: 'fwd', label: Text('To ${route.headsigns.fwd}', overflow: TextOverflow.ellipsis)),
          ButtonSegment(value: 'rev', label: Text('To ${route.headsigns.rev}', overflow: TextOverflow.ellipsis)),
        ],
        selected: {dir},
        onSelectionChanged: (v) => s.setDirection(v.first),
      ),
      const SizedBox(height: 12),
      _MyStopCard(state: s, route: route),
      const SectionTitle('Next buses'),
      if (stopIdx == null && views.isEmpty || stopIdx != null && arrivals.isEmpty)
        const _EmptyBuses()
      else if (stopIdx == null)
        for (final v in views) _BusRow(view: v, eta: null, onTap: () => s.selectBus(v.bus.id))
      else
        for (final a in arrivals.take(5)) _BusRow(view: a.view, eta: a.eta, onTap: () => s.selectBus(a.view.bus.id)),
      if (stopIdx != null) ...[
        const SizedBox(height: 12),
        FilledButton.icon(
          onPressed: () => showAlertSetup(context,
              route: route,
              direction: dir,
              stopIndex: stopIdx,
              altStopIndex: s.destinationStopIndex),
          icon: const Icon(Icons.notifications_active_rounded),
          label: const Text('Notify me when a bus is near'),
        ),
      ],
      const SectionTitle('Traffic on this route'),
      const TrafficLegend(),
      const SizedBox(height: 4),
      const Text('Colours come from how fast buses are moving on each stretch.',
          style: TextStyle(fontSize: 12, color: AppColors.muted)),
      SectionTitle('Stops (${route.stops.length})'),
      _StopTimeline(state: s, route: route, ordered: ordered),
    ]);
  }
}

class _MyStopCard extends StatelessWidget {
  const _MyStopCard({required this.state, required this.route});
  final AppState state;
  final RouteDetail route;

  Future<void> _pick(BuildContext context) async {
    final picked = await showModalBottomSheet<int>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      backgroundColor: Colors.white,
      builder: (_) => _StopPicker(route: route, selected: state.myStopIndex),
    );
    if (picked != null) state.setMyStop(picked);
  }

  @override
  Widget build(BuildContext context) {
    final idx = state.myStopIndex;
    final dest = state.destinationStopIndex;
    return Card(
      color: AppColors.surface,
      child: Column(children: [
        ListTile(
          onTap: () => _pick(context),
          leading: const Icon(Icons.location_on_rounded, color: AppColors.green),
          title: Text(idx == null ? 'Choose your stop' : route.stops[idx].name,
              maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Text(dest != null ? 'Board here' : 'Your stop · tap to change'),
          trailing: const Icon(Icons.edit_location_alt_outlined),
        ),
        if (dest != null) ...[
          const Divider(indent: 16, endIndent: 16),
          ListTile(
            leading: const Icon(Icons.flag_rounded, color: AppColors.trafficHeavy),
            title: Text(route.stops[dest].name,
                maxLines: 1, overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontWeight: FontWeight.w700)),
            subtitle: Text('Get off here · ${(dest - (idx ?? dest)).abs()} stops'),
          ),
        ],
      ]),
    );
  }
}

class _StopPicker extends StatefulWidget {
  const _StopPicker({required this.route, this.selected});
  final RouteDetail route;
  final int? selected;

  @override
  State<_StopPicker> createState() => _StopPickerState();
}

class _StopPickerState extends State<_StopPicker> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    final stops = widget.route.stops
        .where((s) => s.name.toLowerCase().contains(_q.toLowerCase()))
        .toList();
    return SizedBox(
      height: MediaQuery.sizeOf(context).height * 0.75,
      child: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
          child: TextField(
            autofocus: false,
            decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search stops'),
            onChanged: (v) => setState(() => _q = v),
          ),
        ),
        Expanded(
          child: ListView.builder(
            itemCount: stops.length,
            itemBuilder: (_, i) => ListTile(
              leading: Icon(Icons.location_on_outlined,
                  color: stops[i].index == widget.selected ? AppColors.green : AppColors.muted),
              title: Text(stops[i].name),
              trailing: stops[i].index == widget.selected
                  ? const Icon(Icons.check, color: AppColors.green)
                  : null,
              onTap: () => Navigator.pop(context, stops[i].index),
            ),
          ),
        ),
      ]),
    );
  }
}

class _EmptyBuses extends StatelessWidget {
  const _EmptyBuses();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(14)),
      child: const Row(children: [
        Icon(Icons.hourglass_empty_rounded, color: AppColors.muted),
        SizedBox(width: 10),
        Expanded(
          child: Text('No buses heading to this stop right now. We keep checking.',
              style: TextStyle(color: AppColors.muted)),
        ),
      ]),
    );
  }
}

class _BusRow extends StatelessWidget {
  const _BusRow({required this.view, required this.eta, required this.onTap});
  final BusView view;
  final EtaResult? eta;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final b = view.bus;
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(children: [
          BusIcon(color: busColor(view), size: 40),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Bus ${b.label}', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
              const SizedBox(height: 2),
              Text(
                eta != null
                    ? '${formatDistance(eta!.remainingM)} away · ${eta!.stopsAway} stops'
                    : 'Next: ${b.nextStop}',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: AppColors.muted, fontSize: 13),
              ),
              const SizedBox(height: 4),
              BusStatusPills(view),
            ]),
          ),
          if (eta != null)
            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              Text(formatEta(eta!.eta),
                  style: TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 20,
                      color: view.freshness == Freshness.live ? AppColors.green : AppColors.stale)),
              if (view.freshness != Freshness.live)
                const Text('approx.', style: TextStyle(fontSize: 11, color: AppColors.muted)),
            ])
          else
            const Icon(Icons.chevron_right, color: AppColors.muted),
        ]),
      ),
    );
  }
}

class _StopTimeline extends StatelessWidget {
  const _StopTimeline({required this.state, required this.route, required this.ordered});
  final AppState state;
  final RouteDetail route;
  final List<Stop> ordered;

  @override
  Widget build(BuildContext context) {
    final dir = state.direction;
    return Column(children: [
      for (var i = 0; i < ordered.length; i++)
        _timelineRow(context, ordered[i], i == 0, i == ordered.length - 1, dir),
    ]);
  }

  Widget _timelineRow(BuildContext context, Stop stop, bool first, bool last, String dir) {
    final mine = stop.index == state.myStopIndex;
    final dest = stop.index == state.destinationStopIndex;
    final next = state.arrivalsAt(route.id, stop.index, dir);
    return InkWell(
      onTap: () => state.setMyStop(stop.index),
      child: SizedBox(
        height: 48,
        child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          SizedBox(
            width: 24,
            child: Column(children: [
              Expanded(child: Container(width: 3, color: first ? Colors.transparent : AppColors.routeBase)),
              Container(
                width: mine || dest ? 16 : 12,
                height: mine || dest ? 16 : 12,
                decoration: BoxDecoration(
                  color: mine ? AppColors.green : (dest ? AppColors.trafficHeavy : Colors.white),
                  shape: BoxShape.circle,
                  border: Border.all(color: mine ? AppColors.green : AppColors.routeBase, width: 3),
                ),
              ),
              Expanded(child: Container(width: 3, color: last ? Colors.transparent : AppColors.routeBase)),
            ]),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(stop.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontWeight: mine || dest ? FontWeight.w800 : FontWeight.w500)),
            ),
          ),
          Center(
            child: Text(next.isEmpty ? '' : formatEta(next.first.eta.eta),
                style: const TextStyle(color: AppColors.muted, fontWeight: FontWeight.w600)),
          ),
        ]),
      ),
    );
  }
}

// ------------------------------------------------------------------ one bus

class BusSheet extends StatelessWidget {
  const BusSheet({super.key, required this.state, required this.route, required this.view, required this.scroll});
  final AppState state;
  final RouteDetail route;
  final BusView view;
  final ScrollController scroll;

  @override
  Widget build(BuildContext context) {
    final s = state;
    final b = view.bus;
    final stopIdx = s.myStopIndex;
    EtaResult? eta;
    if (stopIdx != null && b.direction != null) {
      final list = etasToStop(route, [view], stopIdx, b.direction!, includePassed: true);
      if (list.isNotEmpty) eta = list.first.eta;
    }
    final alerts = AppScope.of(context).alerts;

    return ListView(controller: scroll, padding: const EdgeInsets.fromLTRB(16, 0, 16, 24), children: [
      const SheetHandle(),
      Row(children: [
        IconButton(
          tooltip: 'Back',
          onPressed: () => s.selectBus(null),
          icon: const Icon(Icons.arrow_back_rounded),
        ),
        BusIcon(color: busColor(view), size: 42),
        const SizedBox(width: 12),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Bus ${b.label}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
            Text('${route.code} · ${b.heading}',
                maxLines: 1, overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: AppColors.muted)),
          ]),
        ),
      ]),
      const SizedBox(height: 8),
      BusStatusPills(view),
      const SizedBox(height: 14),
      if (stopIdx != null && eta != null)
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: AppColors.greenSoft, borderRadius: BorderRadius.circular(16)),
          child: eta.passed
              ? Text('Already passed ${route.stops[stopIdx].name}',
                  style: const TextStyle(fontWeight: FontWeight.w700))
              : Row(children: [
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('Arrives at ${route.stops[stopIdx].name}',
                          maxLines: 1, overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: AppColors.greenDark, fontWeight: FontWeight.w600)),
                      const SizedBox(height: 4),
                      Text('${formatDistance(eta.remainingM)} · ${eta.stopsAway} stops away',
                          style: const TextStyle(color: AppColors.muted)),
                    ]),
                  ),
                  Text(formatEta(eta.eta),
                      style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900, color: AppColors.greenDark)),
                ]),
        ),
      const SizedBox(height: 8),
      _InfoRow(icon: Icons.near_me_outlined, label: 'Next stop', value: b.nextStop),
      _InfoRow(
          icon: Icons.speed_rounded,
          label: 'Speed',
          value: b.speedKmh == null ? 'Not reported' : '${b.speedKmh!.round()} km/h'),
      _InfoRow(
          icon: Icons.update_rounded,
          label: 'Updated',
          value: view.age.inSeconds < 5 ? 'Just now' : ageText(view.age)),
      _InfoRow(
          icon: b.live ? Icons.satellite_alt_outlined : Icons.science_outlined,
          label: 'Source',
          value: b.live ? 'LA Metro live GPS' : 'Simulated bus'),
      const SizedBox(height: 14),
      if (stopIdx != null && b.direction != null && !(eta?.passed ?? true))
        FilledButton.icon(
          onPressed: () => showAlertSetup(context,
              route: route,
              direction: b.direction!,
              stopIndex: stopIdx,
              altStopIndex: s.destinationStopIndex,
              busId: b.id),
          icon: const Icon(Icons.notifications_active_rounded),
          label: Text(alerts.active == null ? 'Alert me for this bus' : 'Replace my alert'),
        ),
      const SizedBox(height: 8),
      OutlinedButton.icon(
        onPressed: () => s.setFollow(!s.followBus),
        icon: Icon(s.followBus ? Icons.gps_fixed : Icons.gps_not_fixed),
        label: Text(s.followBus ? 'Following on map' : 'Follow on map'),
      ),
    ]);
  }
}

class _InfoRow extends StatelessWidget {
  const _InfoRow({required this.icon, required this.label, required this.value});
  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(children: [
        Icon(icon, size: 20, color: AppColors.muted),
        const SizedBox(width: 12),
        Text(label, style: const TextStyle(color: AppColors.muted)),
        const SizedBox(width: 12),
        Expanded(
          child: Text(value,
              textAlign: TextAlign.right,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w600)),
        ),
      ]),
    );
  }
}
