// Alert setup sheet, the active-alert banner and the in-app toast.
import 'dart:async';

import 'package:flutter/material.dart';

import '../../core/approach_alert.dart';
import '../../core/eta.dart';
import '../../data/models.dart';
import '../../services/alert_service.dart';
import '../../services/inbox.dart';
import '../app_scope.dart';
import '../theme.dart';

const _presetsM = [200.0, 500.0, 1000.0, 2000.0];

/// Opens the "Notify me" sheet. Returns true if an alert was started.
Future<bool?> showAlertSetup(
  BuildContext context, {
  required RouteDetail route,
  required String direction,
  required int stopIndex,
  int? altStopIndex,
  String? busId,
}) {
  return showModalBottomSheet<bool>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    backgroundColor: Colors.white,
    builder: (_) => _AlertSetupSheet(
      route: route,
      direction: direction,
      stopIndex: stopIndex,
      altStopIndex: altStopIndex,
      busId: busId,
    ),
  );
}

class _AlertSetupSheet extends StatefulWidget {
  const _AlertSetupSheet({
    required this.route,
    required this.direction,
    required this.stopIndex,
    this.altStopIndex,
    this.busId,
  });

  final RouteDetail route;
  final String direction;
  final int stopIndex;
  final int? altStopIndex;
  final String? busId;

  @override
  State<_AlertSetupSheet> createState() => _AlertSetupSheetState();
}

class _AlertSetupSheetState extends State<_AlertSetupSheet> {
  late int _stop = widget.stopIndex;
  late bool _thisBus = widget.busId != null;
  double? _metresOrNull;
  double get _metres => _metresOrNull!;
  set _metres(double v) => _metresOrNull = v;
  bool _arriving = true;
  bool _starting = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _metresOrNull ??= AppScope.of(context).settings.defaultAlertM;
  }

  Future<void> _start() async {
    final scope = AppScope.of(context);
    setState(() => _starting = true);
    final r = widget.route;
    final settings = AlertSettings(
      routeId: r.id,
      routeLabel: '${r.code} to ${r.headsigns.of(widget.direction)}',
      stopIndex: _stop,
      stopName: r.stops[_stop].name,
      direction: widget.direction,
      thresholdM: _metres,
      busId: _thisBus ? widget.busId : null,
      notifyArriving: _arriving,
    );
    final note = await scope.alerts.start(settings, scope.settings.baseUrl);
    if (!mounted) return;
    final messenger = ScaffoldMessenger.of(context);
    Navigator.pop(context, true);
    messenger.showSnackBar(SnackBar(
      content: Text(note ?? 'Alert on. We will notify you at ${formatDistance(_metres)}.'),
      behavior: SnackBarBehavior.floating,
    ));
  }

  @override
  Widget build(BuildContext context) {
    final r = widget.route;
    // Rough "how much warning is that" at a typical city bus speed.
    final warn = const EtaCalculator().toStop(
        busAlongM: 0, stopAlongM: _metres, forward: true, smoothedKmh: null);
    final stops = {widget.stopIndex, ?widget.altStopIndex}.toList();

    return SafeArea(
      child: Padding(
        padding: EdgeInsets.fromLTRB(20, 0, 20, 16 + MediaQuery.viewInsetsOf(context).bottom),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Notify me when the bus is near',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          Text('${r.code} · To ${r.headsigns.of(widget.direction)}',
              style: const TextStyle(color: AppColors.muted)),
          const SizedBox(height: 16),
          const Text('Stop', style: TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          for (final i in stops)
            _ChoiceTile(
              selected: _stop == i,
              icon: i == widget.altStopIndex ? Icons.flag_rounded : Icons.location_on_rounded,
              title: r.stops[i].name,
              subtitle: stops.length > 1
                  ? (i == widget.altStopIndex ? 'Where you get off' : 'Where you board')
                  : null,
              onTap: () => setState(() => _stop = i),
            ),
          if (widget.busId != null) ...[
            const SizedBox(height: 12),
            const Text('Bus', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            Row(children: [
              Expanded(
                child: _ChoiceTile(
                  selected: _thisBus,
                  icon: Icons.directions_bus_rounded,
                  title: widget.busId!,
                  onTap: () => setState(() => _thisBus = true),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _ChoiceTile(
                  selected: !_thisBus,
                  icon: Icons.schedule,
                  title: 'Next bus',
                  onTap: () => setState(() => _thisBus = false),
                ),
              ),
            ]),
          ],
          const SizedBox(height: 16),
          Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
            const Expanded(child: Text('Alert distance', style: TextStyle(fontWeight: FontWeight.w700))),
            Text(formatDistance(_metres),
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: AppColors.green)),
          ]),
          Slider(
            value: _metres,
            min: 100,
            max: 3000,
            divisions: 58,
            label: formatDistance(_metres),
            onChanged: (v) => setState(() => _metres = v),
          ),
          Wrap(spacing: 8, children: [
            for (final p in _presetsM)
              ChoiceChip(
                label: Text(formatDistance(p)),
                selected: _metres == p,
                selectedColor: AppColors.greenSoft,
                onSelected: (_) => setState(() => _metres = p),
              ),
          ]),
          const SizedBox(height: 6),
          Text('That is roughly ${formatEta(warn.eta)} of warning in normal traffic.',
              style: const TextStyle(color: AppColors.muted, fontSize: 13)),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            value: _arriving,
            activeThumbColor: AppColors.green,
            onChanged: (v) => setState(() => _arriving = v),
            title: const Text('Also alert me when it is arriving'),
            subtitle: const Text('A second notification at about 150 m'),
          ),
          const SizedBox(height: 8),
          FilledButton.icon(
            onPressed: _starting ? null : _start,
            icon: _starting
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                : const Icon(Icons.notifications_active_rounded),
            label: const Text('Start alert'),
          ),
        ]),
      ),
    );
  }
}

class _ChoiceTile extends StatelessWidget {
  const _ChoiceTile({
    required this.selected,
    required this.icon,
    required this.title,
    required this.onTap,
    this.subtitle,
  });

  final bool selected;
  final IconData icon;
  final String title;
  final String? subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Material(
        color: selected ? AppColors.greenSoft : AppColors.surface,
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: selected ? AppColors.green : Colors.transparent, width: 1.5),
            ),
            child: Row(children: [
              Icon(icon, color: selected ? AppColors.green : AppColors.muted, size: 20),
              const SizedBox(width: 10),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(title, maxLines: 1, overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w600)),
                  if (subtitle != null)
                    Text(subtitle!, style: const TextStyle(fontSize: 12, color: AppColors.muted)),
                ]),
              ),
              if (selected) const Icon(Icons.check_circle, color: AppColors.green, size: 20),
            ]),
          ),
        ),
      ),
    );
  }
}

/// Green card under the search bar while an alert is running.
class ActiveAlertBanner extends StatelessWidget {
  const ActiveAlertBanner({super.key, required this.alerts});
  final AlertController alerts;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: alerts,
      builder: (context, _) {
        final a = alerts.active;
        if (a == null) return const SizedBox.shrink();
        final st = alerts.status;
        final finished = st.phase == AlertPhase.finished;
        final String title;
        final String sub;
        if (finished) {
          title = 'Alert finished';
          sub = a.stopName;
        } else if (st.busId == null) {
          title = st.error != null ? 'Reconnecting…' : 'Waiting for a bus';
          sub = '${a.stopName} · alert at ${formatDistance(a.thresholdM)}';
        } else {
          title = '${st.busId} · ${formatEta(st.eta ?? Duration.zero)}';
          sub = '${formatDistance(st.remainingM ?? 0)} to ${a.stopName}'
              '${st.trusted ? '' : ' · signal delayed'}';
        }
        final badge = switch (st.phase) {
          AlertPhase.approaching => 'Get ready',
          AlertPhase.arriving => 'Arriving',
          _ => null,
        };
        return Material(
          color: finished ? AppColors.ink : AppColors.green,
          borderRadius: BorderRadius.circular(16),
          elevation: 4,
          shadowColor: const Color(0x55000000),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(14, 10, 4, 10),
            child: Row(children: [
              Icon(finished ? Icons.check_circle : Icons.notifications_active_rounded, color: Colors.white),
              const SizedBox(width: 10),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Flexible(
                      child: Text(title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15)),
                    ),
                    if (badge != null) ...[
                      const SizedBox(width: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10)),
                        child: Text(badge,
                            style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: AppColors.greenDark)),
                      ),
                    ],
                  ]),
                  Text(sub,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: Colors.white, fontSize: 13)),
                ]),
              ),
              IconButton(
                tooltip: finished ? 'Dismiss' : 'Stop alert',
                icon: const Icon(Icons.close_rounded, color: Colors.white),
                onPressed: finished ? alerts.dismissFinished : alerts.stop,
              ),
            ]),
          ),
        );
      },
    );
  }
}

/// Slides in new in-app notifications at the top of the screen.
class ToastHost extends StatefulWidget {
  const ToastHost({super.key, required this.inbox, required this.onOpen, required this.child});

  final Inbox inbox;
  final VoidCallback onOpen;
  final Widget child;

  @override
  State<ToastHost> createState() => _ToastHostState();
}

class _ToastHostState extends State<ToastHost> {
  StreamSubscription<InboxItem>? _sub;
  InboxItem? _current;
  Timer? _hide;

  @override
  void initState() {
    super.initState();
    _sub = widget.inbox.toasts.listen((item) {
      _hide?.cancel();
      setState(() => _current = item);
      _hide = Timer(const Duration(seconds: 5), () {
        if (mounted) setState(() => _current = null);
      });
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    _hide?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final item = _current;
    return Stack(children: [
      widget.child,
      AnimatedPositioned(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOutCubic,
        left: 12,
        right: 12,
        top: item == null ? -140 : MediaQuery.paddingOf(context).top + 8,
        child: item == null
            ? const SizedBox.shrink()
            : Material(
                elevation: 8,
                shadowColor: const Color(0x66000000),
                borderRadius: BorderRadius.circular(16),
                color: Colors.white,
                child: InkWell(
                  borderRadius: BorderRadius.circular(16),
                  onTap: () {
                    setState(() => _current = null);
                    widget.onOpen();
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Row(children: [
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(color: AppColors.greenSoft, borderRadius: BorderRadius.circular(12)),
                        child: const Icon(Icons.notifications_active_rounded, color: AppColors.green),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(item.title, style: const TextStyle(fontWeight: FontWeight.w800)),
                          const SizedBox(height: 2),
                          Text(item.body, style: const TextStyle(color: AppColors.muted, fontSize: 13)),
                        ]),
                      ),
                    ]),
                  ),
                ),
              ),
      ),
    ]);
  }
}
