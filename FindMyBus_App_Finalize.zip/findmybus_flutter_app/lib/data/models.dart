// Typed views of the Django API's JSON.
import 'dart:ui' show Color;

import 'package:latlong2/latlong.dart';

import '../core/geo.dart';

double? _d(Object? v) => v is num ? v.toDouble() : null;

Color _rgb(Object? v, Color fallback) {
  if (v is List && v.length >= 3) {
    return Color.fromARGB(
        255, (v[0] as num).toInt(), (v[1] as num).toInt(), (v[2] as num).toInt());
  }
  return fallback;
}

const _defaultRouteColor = Color(0xFF00B14F);

/// "720 - Wilshire Rapid (...)" -> ("720", "Wilshire Rapid (...)").
(String, String) splitRouteName(String name, String fallbackCode) {
  final i = name.indexOf(' - ');
  if (i > 0) return (name.substring(0, i).trim(), name.substring(i + 3).trim());
  return (fallbackCode, name);
}

class Headsigns {
  const Headsigns(this.fwd, this.rev);
  factory Headsigns.fromJson(Object? j) {
    final m = j is Map ? j : const {};
    return Headsigns(
        (m['fwd'] as String?) ?? 'End of line', (m['rev'] as String?) ?? 'Start of line');
  }
  final String fwd;
  final String rev;
  String of(String direction) => direction == 'rev' ? rev : fwd;
}

class RouteSummary {
  const RouteSummary({
    required this.id,
    required this.code,
    required this.title,
    required this.color,
    required this.headsigns,
    required this.stopNames,
    required this.busCount,
    required this.source,
  });

  factory RouteSummary.fromJson(Map<String, Object?> j) {
    final (code, title) =
        splitRouteName(j['name'] as String? ?? '', (j['code'] ?? j['id']).toString());
    return RouteSummary(
      id: j['id'] as String,
      code: (j['code'] as String?) ?? code,
      title: title,
      color: _rgb(j['color'], _defaultRouteColor),
      headsigns: Headsigns.fromJson(j['headsigns']),
      stopNames: ((j['stops'] as List?) ?? const []).cast<String>(),
      busCount: (j['buses'] as num?)?.toInt() ?? 0,
      source: (j['source'] as String?) ?? 'unknown',
    );
  }

  final String id;
  final String code;
  final String title;
  final Color color;
  final Headsigns headsigns;
  final List<String> stopNames;
  final int busCount;

  /// 'live' | 'simulated' | 'mixed' | 'empty'.
  final String source;
}

class Stop {
  const Stop(this.index, this.name, this.position, this.alongM);
  final int index;
  final String name;
  final LatLng position;
  final double alongM;
}

class RouteDetail {
  RouteDetail({
    required this.id,
    required this.code,
    required this.title,
    required this.color,
    required this.headsigns,
    required this.stops,
    required this.path,
    required this.alongFromServer,
    this.geometryId,
  });

  factory RouteDetail.fromJson(Map<String, Object?> j) {
    final (code, title) = splitRouteName(j['name'] as String? ?? '', j['route_id'] as String);
    final raw = ((j['path'] as List?) ?? const [])
        .whereType<List>()
        .map((p) => LatLng((p[0] as num).toDouble(), (p[1] as num).toDouble()))
        .toList();
    final stopsJson = ((j['stops'] as List?) ?? const []).cast<Map>();
    final stopPts = stopsJson
        .map((s) => LatLng((s['lat'] as num).toDouble(), (s['lon'] as num).toDouble()))
        .toList();
    final path = RoutePath.fromPoints(raw.length >= 2 ? raw : stopPts);
    final serverAlong = stopsJson.every((s) => s['along_km'] is num);
    final stops = <Stop>[
      for (var i = 0; i < stopsJson.length; i++)
        Stop(
          i,
          stopsJson[i]['name'] as String,
          stopPts[i],
          serverAlong
              ? (stopsJson[i]['along_km'] as num).toDouble() * 1000
              : path.project(stopPts[i]),
        ),
    ];
    return RouteDetail(
      id: j['route_id'] as String,
      code: code,
      title: title,
      color: _rgb(j['color'], _defaultRouteColor),
      headsigns: Headsigns.fromJson(j['headsigns']),
      stops: stops,
      path: path,
      alongFromServer: serverAlong,
      geometryId: j['geometry_id'] as String?,
    );
  }

  final String id;
  final String code;
  final String title;
  final Color color;
  final Headsigns headsigns;
  final List<Stop> stops;
  final RoutePath path;

  /// Identifies the line the server drew; when it changes the app downloads the route again.
  final String? geometryId;

  /// True when the backend sends positions along the line (newer backend).
  final bool alongFromServer;

  late final List<double> stopsAlongM = [for (final s in stops) s.alongM];

  /// Metres along the route for a bus (server value when consistent).
  double alongOf(Bus b) =>
      (alongFromServer && b.alongM != null) ? b.alongM! : path.project(b.position);

  RouteSummary toSummary({int busCount = 0, String source = 'unknown'}) => RouteSummary(
        id: id,
        code: code,
        title: title,
        color: color,
        headsigns: headsigns,
        stopNames: [for (final s in stops) s.name],
        busCount: busCount,
        source: source,
      );
}

class Bus {
  const Bus({
    required this.id,
    required this.routeId,
    required this.position,
    required this.status,
    required this.speedKmh,
    required this.deviation,
    required this.live,
    required this.nextStop,
    required this.nextStopIndex,
    required this.direction,
    required this.heading,
    required this.alongM,
    required this.updatedAt,
  });

  factory Bus.fromJson(Map<String, Object?> j) => Bus(
        id: j['id'] as String,
        routeId: j['route_id'] as String,
        position: LatLng((j['lat'] as num).toDouble(), (j['lon'] as num).toDouble()),
        status: (j['status'] as String?) ?? 'On Time',
        speedKmh: _d(j['speed_kmh']),
        deviation: (j['deviation'] as bool?) ?? false,
        live: (j['live'] as bool?) ?? false,
        nextStop: (j['next_stop'] as String?) ?? '',
        nextStopIndex: (j['next_stop_index'] as num?)?.toInt() ?? 0,
        direction: j['direction'] as String?,
        heading: (j['heading'] as String?) ?? '',
        alongM: _d(j['along_km']) == null ? null : _d(j['along_km'])! * 1000,
        updatedAt: _d(j['updated_at']),
      );

  final String id;
  final String routeId;
  final LatLng position;
  final String status;
  final double? speedKmh;
  final bool deviation;

  /// Real GPS from LA Metro (false = simulator).
  final bool live;
  final String nextStop;
  final int nextStopIndex;

  /// 'fwd' | 'rev' | null while the backend is still detecting it.
  final String? direction;
  final String heading;
  final double? alongM;

  /// Epoch seconds of the last real position fix (null on older backends).
  final double? updatedAt;

  /// Short label for the UI: "Sim 01" -> "Sim 01", "Bus 5123" -> "5123".
  String get label => id.startsWith('Bus ') ? id.substring(4) : id;
}

class BusSnapshot {
  BusSnapshot({
    required this.routeId,
    required this.buses,
    required this.serverTime,
    required this.fetchedAt,
    required this.source,
    this.geometryId,
  });

  factory BusSnapshot.fromJson(String routeId, Map<String, Object?> j) {
    final src = j['source'];
    return BusSnapshot(
      routeId: routeId,
      buses: ((j['buses'] as List?) ?? const [])
          .cast<Map<String, Object?>>()
          .map(Bus.fromJson)
          .toList(),
      serverTime: _d(j['server_time']),
      fetchedAt: DateTime.now(),
      source: src is Map ? (src['state'] as String? ?? 'unknown') : 'unknown',
      geometryId: j['geometry_id'] as String?,
    );
  }

  final String routeId;
  final List<Bus> buses;
  final double? serverTime;
  final DateTime fetchedAt;
  final String source;
  final String? geometryId;

  /// How old [b]'s position was when the server answered.
  Duration reportAge(Bus b) {
    if (serverTime == null || b.updatedAt == null) return Duration.zero;
    final s = serverTime! - b.updatedAt!;
    return Duration(milliseconds: (s < 0 ? 0 : s * 1000).round());
  }
}
