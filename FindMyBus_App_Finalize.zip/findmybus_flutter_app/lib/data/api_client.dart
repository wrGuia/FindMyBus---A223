// HTTP client for the FindMyBus Django API.
import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import 'models.dart';

class ApiException implements Exception {
  ApiException(this.message);
  final String message;
  @override
  String toString() => message;
}

class FindMyBusApi {
  FindMyBusApi(String baseUrl, {http.Client? client, this.timeout = const Duration(seconds: 8)})
      : baseUrl = normalizeBaseUrl(baseUrl),
        _client = client ?? http.Client();

  final String baseUrl;
  final Duration timeout;
  final http.Client _client;

  static String normalizeBaseUrl(String url) {
    var u = url.trim();
    if (u.isNotEmpty && !u.startsWith('http://') && !u.startsWith('https://')) {
      u = 'http://$u';
    }
    while (u.endsWith('/')) {
      u = u.substring(0, u.length - 1);
    }
    return u;
  }

  Future<Map<String, Object?>> _get(String path, [Map<String, String>? query]) async {
    final uri = Uri.parse('$baseUrl$path').replace(queryParameters: query);
    final http.Response res;
    try {
      res = await _client.get(uri, headers: const {'Accept': 'application/json'}).timeout(timeout);
    } on TimeoutException {
      throw ApiException('The server took too long to answer');
    } catch (_) {
      throw ApiException('Cannot reach the server at $baseUrl');
    }
    if (res.statusCode == 404) throw _NotFound();
    if (res.statusCode != 200) {
      throw ApiException('Server error ${res.statusCode}');
    }
    final body = jsonDecode(utf8.decode(res.bodyBytes));
    if (body is! Map<String, Object?>) throw ApiException('Unexpected response');
    return body;
  }

  /// All routes. Falls back to probing route details on backends without /api/routes/.
  Future<List<RouteSummary>> routes() async {
    try {
      final j = await _get('/api/routes/');
      return ((j['routes'] as List?) ?? const [])
          .cast<Map<String, Object?>>()
          .map(RouteSummary.fromJson)
          .toList();
    } on _NotFound {
      final out = <RouteSummary>[];
      for (final id in const ['R1', 'R2', 'R3', 'R4', 'R5']) {
        try {
          final j = await _get('/api/route/$id/');
          out.add(RouteDetail.fromJson(j).toSummary(
              busCount: ((j['buses'] as List?) ?? const []).length));
        } on _NotFound {
          break;
        }
      }
      return out;
    }
  }

  Future<RouteDetail> route(String id) async {
    try {
      return RouteDetail.fromJson(await _get('/api/route/$id/'));
    } on _NotFound {
      throw ApiException('Route $id not found');
    }
  }

  /// Live buses of one route (lightweight endpoint, with fallback).
  Future<BusSnapshot> buses(String routeId) async {
    try {
      return BusSnapshot.fromJson(routeId, await _get('/api/buses/', {'route': routeId}));
    } on _NotFound {
      try {
        return BusSnapshot.fromJson(routeId, await _get('/api/route/$routeId/'));
      } on _NotFound {
        throw ApiException('Route $routeId not found');
      }
    }
  }

  /// Connection check for the settings screen.
  Future<String> status() async {
    try {
      final j = await _get('/api/status/');
      return 'Connected · data mode: ${j['mode'] ?? 'unknown'}';
    } on _NotFound {
      throw ApiException('This server is not a FindMyBus backend');
    }
  }

  void close() => _client.close();
}

class _NotFound implements Exception {}
