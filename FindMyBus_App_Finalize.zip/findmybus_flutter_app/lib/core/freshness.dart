// How much to trust a bus position, based on when it was last reported.

enum Freshness { live, stale, offline }

class FreshnessPolicy {
  const FreshnessPolicy({
    this.staleAfter = const Duration(seconds: 45),
    this.offlineAfter = const Duration(seconds: 120),
  });

  final Duration staleAfter;
  final Duration offlineAfter;

  /// [reportAge] is how old the position was when the server answered;
  /// [sinceFetch] is how long ago that answer arrived (grows if polling fails).
  Freshness classify(Duration reportAge, Duration sinceFetch) {
    final age = reportAge + sinceFetch;
    if (age >= offlineAfter) return Freshness.offline;
    if (age >= staleAfter) return Freshness.stale;
    return Freshness.live;
  }
}
