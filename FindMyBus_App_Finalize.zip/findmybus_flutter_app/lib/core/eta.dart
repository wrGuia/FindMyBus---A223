// ETA estimation from live position and progress along the route.
//
// Deliberately simple and isolated so it can be improved later:
//   ETA = remaining distance / smoothed recent speed + a short dwell per stop.

/// Smooths each bus's reported speed so a single red light doesn't swing the ETA.
class SpeedSmoother {
  SpeedSmoother({this.alpha = 0.3});

  final double alpha;
  final Map<String, double> _ema = {};

  /// Feeds a reported speed (km/h, may be null) and returns the smoothed value.
  double? add(String busId, double? kmh) {
    if (kmh == null || kmh.isNaN || kmh < 0) return _ema[busId];
    final prev = _ema[busId];
    final next = prev == null ? kmh : prev + alpha * (kmh - prev);
    _ema[busId] = next;
    return next;
  }

  double? of(String busId) => _ema[busId];

  /// Forget buses that are no longer in the feed.
  void retain(Iterable<String> busIds) {
    final keep = busIds.toSet();
    _ema.removeWhere((k, _) => !keep.contains(k));
  }
}

class EtaConfig {
  const EtaConfig({
    this.fallbackKmh = 18,
    this.minKmh = 8,
    this.maxKmh = 70,
    this.dwellPerStop = const Duration(seconds: 15),
    this.passedMarginM = 50,
  });

  /// Used when a bus has never reported a speed.
  final double fallbackKmh;

  /// Clamp so a stopped bus doesn't produce a near-infinite ETA.
  final double minKmh;
  final double maxKmh;
  final Duration dwellPerStop;

  /// A stop this far behind the bus counts as passed.
  final double passedMarginM;
}

class EtaResult {
  const EtaResult({
    required this.remainingM,
    required this.eta,
    required this.passed,
    required this.stopsAway,
  });

  final double remainingM;
  final Duration eta;
  final bool passed;

  /// Stops strictly between the bus and the target stop.
  final int stopsAway;
}

class EtaCalculator {
  const EtaCalculator([this.config = const EtaConfig()]);

  final EtaConfig config;

  double effectiveKmh(double? smoothedKmh) {
    if (smoothedKmh == null) return config.fallbackKmh;
    return smoothedKmh.clamp(config.minKmh, config.maxKmh).toDouble();
  }

  /// [forward] = the bus travels toward increasing distance along the route.
  /// [stopsAlongM] are all stop positions on the route (any order).
  EtaResult toStop({
    required double busAlongM,
    required double stopAlongM,
    required bool forward,
    required double? smoothedKmh,
    List<double> stopsAlongM = const [],
  }) {
    final signed = forward ? stopAlongM - busAlongM : busAlongM - stopAlongM;
    final passed = signed < -config.passedMarginM;
    final remaining = passed ? signed.abs() : (signed < 0 ? 0.0 : signed);
    if (passed) {
      return EtaResult(
          remainingM: remaining, eta: Duration.zero, passed: true, stopsAway: 0);
    }
    var between = 0;
    for (final s in stopsAlongM) {
      final ahead = forward ? s - busAlongM : busAlongM - s;
      final beforeTarget = forward ? s < stopAlongM - 1 : s > stopAlongM + 1;
      if (ahead > 1 && beforeTarget) between++;
    }
    final mps = effectiveKmh(smoothedKmh) / 3.6;
    final seconds = remaining / mps + between * config.dwellPerStop.inSeconds;
    return EtaResult(
      remainingM: remaining,
      eta: Duration(seconds: seconds.round()),
      passed: false,
      stopsAway: between,
    );
  }
}

/// "Now", "3 min", "1 h 05 min".
String formatEta(Duration eta) {
  final m = (eta.inSeconds / 60).round();
  if (m < 1) return 'Now';
  if (m < 60) return '$m min';
  return '${m ~/ 60} h ${(m % 60).toString().padLeft(2, '0')} min';
}

/// "850 m", "1.2 km".
String formatDistance(double metres) {
  if (metres < 1000) return '${(metres / 10).round() * 10} m';
  return '${(metres / 1000).toStringAsFixed(1)} km';
}
