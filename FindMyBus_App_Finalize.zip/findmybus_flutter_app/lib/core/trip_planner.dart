// Picks where to board and which direction to ride for a chosen destination stop.
import 'package:latlong2/latlong.dart';

import 'geo.dart';

class TripPlan {
  const TripPlan({
    required this.boardStopIndex,
    required this.destinationStopIndex,
    required this.direction,
    required this.walkM,
  });

  final int boardStopIndex;
  final int destinationStopIndex;

  /// 'fwd' (towards the last stop) or 'rev' (towards the first stop).
  final String direction;

  /// Straight-line distance from the passenger to the boarding stop.
  final double walkM;
}

/// [stops] in route order. Returns null when the passenger is nearest to the
/// destination itself (nothing to ride) or there are no stops.
TripPlan? planTrip({
  required List<LatLng> stops,
  required LatLng from,
  required int destinationStopIndex,
}) {
  if (stops.isEmpty) return null;
  var board = 0;
  var best = double.infinity;
  for (var i = 0; i < stops.length; i++) {
    final d = haversineM(from, stops[i]);
    if (d < best) {
      best = d;
      board = i;
    }
  }
  if (board == destinationStopIndex) return null;
  return TripPlan(
    boardStopIndex: board,
    destinationStopIndex: destinationStopIndex,
    direction: destinationStopIndex > board ? 'fwd' : 'rev',
    walkM: best,
  );
}
