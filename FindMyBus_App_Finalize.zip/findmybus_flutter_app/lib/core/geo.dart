// Pure geometry helpers (no Flutter imports) shared by ETA, traffic and alerts.
import 'dart:math' as math;

import 'package:latlong2/latlong.dart';

const double _earthRadiusM = 6371000.0;

/// Great-circle distance in metres.
double haversineM(LatLng a, LatLng b) {
  final lat1 = a.latitude * math.pi / 180;
  final lat2 = b.latitude * math.pi / 180;
  final dLat = lat2 - lat1;
  final dLon = (b.longitude - a.longitude) * math.pi / 180;
  final h = math.pow(math.sin(dLat / 2), 2) +
      math.cos(lat1) * math.cos(lat2) * math.pow(math.sin(dLon / 2), 2);
  return 2 * _earthRadiusM * math.asin(math.min(1.0, math.sqrt(h)));
}

/// A route line with cumulative distances, so positions can be expressed as
/// "metres along the route". Built once per route and reused.
class RoutePath {
  RoutePath._(this.points, this.cumM);

  /// Builds a path, inserting extra points so no gap is longer than [maxGapM].
  /// The backend sends a ~30 m line when it has official stops, but only the
  /// stops themselves when it falls back, so densifying keeps traffic colouring
  /// and projection smooth either way.
  factory RoutePath.fromPoints(List<LatLng> raw, {double maxGapM = 60}) {
    if (raw.isEmpty) return RoutePath._(const [], const [0]);
    final pts = <LatLng>[raw.first];
    for (var i = 1; i < raw.length; i++) {
      final a = raw[i - 1], b = raw[i];
      final d = haversineM(a, b);
      final n = (d / maxGapM).ceil();
      for (var k = 1; k < n; k++) {
        final t = k / n;
        pts.add(LatLng(a.latitude + (b.latitude - a.latitude) * t,
            a.longitude + (b.longitude - a.longitude) * t));
      }
      pts.add(b);
    }
    final cum = List<double>.filled(pts.length, 0);
    for (var i = 1; i < pts.length; i++) {
      cum[i] = cum[i - 1] + haversineM(pts[i - 1], pts[i]);
    }
    return RoutePath._(List.unmodifiable(pts), List.unmodifiable(cum));
  }

  final List<LatLng> points;
  final List<double> cumM;

  double get lengthM => cumM.last;
  bool get isEmpty => points.isEmpty;

  /// Index of the path point nearest to [p] (equirectangular, fast enough for
  /// a few thousand points per poll).
  int nearestIndex(LatLng p) {
    var best = 0;
    var bestD = double.infinity;
    final cosLat = math.cos(p.latitude * math.pi / 180);
    for (var i = 0; i < points.length; i++) {
      final dx = (points[i].longitude - p.longitude) * cosLat;
      final dy = points[i].latitude - p.latitude;
      final d = dx * dx + dy * dy;
      if (d < bestD) {
        bestD = d;
        best = i;
      }
    }
    return best;
  }

  /// Metres along the route of the point nearest to [p].
  double project(LatLng p) => points.isEmpty ? 0 : cumM[nearestIndex(p)];

  /// Distance in metres from [p] to the nearest point on the line.
  double offRouteM(LatLng p) =>
      points.isEmpty ? 0 : haversineM(p, points[nearestIndex(p)]);

  /// Position at [alongM] metres along the route.
  LatLng pointAt(double alongM) {
    if (points.isEmpty) return const LatLng(0, 0);
    if (alongM <= 0) return points.first;
    if (alongM >= lengthM) return points.last;
    final i = _upperIndex(alongM);
    final seg = cumM[i] - cumM[i - 1];
    final t = seg <= 0 ? 0.0 : (alongM - cumM[i - 1]) / seg;
    final a = points[i - 1], b = points[i];
    return LatLng(a.latitude + (b.latitude - a.latitude) * t,
        a.longitude + (b.longitude - a.longitude) * t);
  }

  /// The part of the line between two distances (used to draw traffic bands).
  List<LatLng> slice(double startM, double endM) {
    if (points.isEmpty || endM <= startM) return const [];
    final out = <LatLng>[pointAt(startM)];
    for (var i = 0; i < points.length; i++) {
      if (cumM[i] > startM && cumM[i] < endM) out.add(points[i]);
    }
    out.add(pointAt(endM));
    return out;
  }

  // First index whose cumulative distance is >= alongM (binary search).
  int _upperIndex(double alongM) {
    var lo = 1, hi = cumM.length - 1;
    while (lo < hi) {
      final mid = (lo + hi) >> 1;
      if (cumM[mid] < alongM) {
        lo = mid + 1;
      } else {
        hi = mid;
      }
    }
    return lo;
  }
}
