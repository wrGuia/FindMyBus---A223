// Approach alert state machine: "tell me when a bus is within N metres of my stop".
//
// Rules:
//  * Each notification kind fires at most once per alert (one trip).
//  * With "any bus", the alert locks onto the first bus that comes within
//    range and follows only that bus afterwards.
//  * Stale or offline positions never trigger anything.
//  * Once the followed bus passes the stop, the alert is finished.

enum AlertPhase { watching, approaching, arriving, finished }

enum AlertEventKind { approaching, arriving, passed }

class AlertSettings {
  const AlertSettings({
    required this.routeId,
    required this.routeLabel,
    required this.stopIndex,
    required this.stopName,
    required this.direction,
    required this.thresholdM,
    this.busId,
    this.notifyArriving = true,
    this.arrivingM = 150,
  });

  final String routeId;
  final String routeLabel;
  final int stopIndex;
  final String stopName;

  /// 'fwd' or 'rev'.
  final String direction;

  /// Distance the passenger picked for the approach alert.
  final double thresholdM;

  /// A specific bus, or null for "the next bus".
  final String? busId;
  final bool notifyArriving;
  final double arrivingM;

  Map<String, Object?> toJson() => {
        'routeId': routeId,
        'routeLabel': routeLabel,
        'stopIndex': stopIndex,
        'stopName': stopName,
        'direction': direction,
        'thresholdM': thresholdM,
        'busId': busId,
        'notifyArriving': notifyArriving,
        'arrivingM': arrivingM,
      };

  factory AlertSettings.fromJson(Map<String, Object?> j) => AlertSettings(
        routeId: j['routeId'] as String,
        routeLabel: (j['routeLabel'] as String?) ?? j['routeId'] as String,
        stopIndex: (j['stopIndex'] as num).toInt(),
        stopName: j['stopName'] as String,
        direction: j['direction'] as String,
        thresholdM: (j['thresholdM'] as num).toDouble(),
        busId: j['busId'] as String?,
        notifyArriving: (j['notifyArriving'] as bool?) ?? true,
        arrivingM: ((j['arrivingM'] as num?) ?? 150).toDouble(),
      );
}

/// One bus's progress toward the alert's stop, computed by the ETA module.
class BusApproach {
  const BusApproach({
    required this.busId,
    required this.remainingM,
    required this.eta,
    required this.passed,
    required this.trusted,
  });

  final String busId;
  final double remainingM;
  final Duration eta;
  final bool passed;

  /// False for stale/offline positions.
  final bool trusted;
}

class AlertEvent {
  const AlertEvent(this.kind, this.busId, this.remainingM, this.eta);

  final AlertEventKind kind;
  final String busId;
  final double remainingM;
  final Duration eta;
}

class AlertEngine {
  AlertEngine(this.settings)
      : phase = AlertPhase.watching,
        followedBusId = settings.busId;

  final AlertSettings settings;
  AlertPhase phase;
  String? followedBusId;
  final Set<AlertEventKind> _fired = {};

  bool get isFinished => phase == AlertPhase.finished;
  bool hasFired(AlertEventKind k) => _fired.contains(k);

  /// The bus this alert is about right now (followed, or nearest candidate).
  BusApproach? focus(List<BusApproach> buses) {
    final candidates = buses.where((b) => !b.passed).toList()
      ..sort((a, b) => a.remainingM.compareTo(b.remainingM));
    if (followedBusId != null) {
      for (final b in buses) {
        if (b.busId == followedBusId) return b;
      }
      return null;
    }
    return candidates.isEmpty ? null : candidates.first;
  }

  /// Feed the latest positions; returns the notifications to show (0..2).
  List<AlertEvent> evaluate(List<BusApproach> buses) {
    if (isFinished) return const [];
    final events = <AlertEvent>[];

    BusApproach? bus;
    if (followedBusId != null) {
      for (final b in buses) {
        if (b.busId == followedBusId) bus = b;
      }
    } else {
      final inRange = buses
          .where((b) =>
              b.trusted && !b.passed && b.remainingM <= settings.thresholdM)
          .toList()
        ..sort((a, b) => a.remainingM.compareTo(b.remainingM));
      if (inRange.isNotEmpty) {
        bus = inRange.first;
        followedBusId = bus.busId; // lock on for the rest of this trip
      }
    }
    if (bus == null) return events;

    if (bus.passed) {
      // Only a bus we were already following can "pass"; report it once.
      if (phase != AlertPhase.watching || settings.busId != null) {
        if (_fired.add(AlertEventKind.passed)) {
          events.add(AlertEvent(
              AlertEventKind.passed, bus.busId, bus.remainingM, bus.eta));
        }
        phase = AlertPhase.finished;
      }
      return events;
    }
    if (!bus.trusted) return events;

    final arriving =
        settings.notifyArriving && bus.remainingM <= settings.arrivingM;
    if (arriving) {
      // Skip the "approaching" message if the bus is already at the stop.
      _fired.add(AlertEventKind.approaching);
      if (_fired.add(AlertEventKind.arriving)) {
        events.add(AlertEvent(
            AlertEventKind.arriving, bus.busId, bus.remainingM, bus.eta));
      }
      phase = AlertPhase.arriving;
    } else if (bus.remainingM <= settings.thresholdM) {
      if (_fired.add(AlertEventKind.approaching)) {
        events.add(AlertEvent(
            AlertEventKind.approaching, bus.busId, bus.remainingM, bus.eta));
      }
      if (phase == AlertPhase.watching) phase = AlertPhase.approaching;
      if (!settings.notifyArriving) phase = AlertPhase.finished;
    }
    return events;
  }

  // ---- persistence (so a restarted background service never re-fires) ----
  Map<String, Object?> stateToJson() => {
        'phase': phase.name,
        'followedBusId': followedBusId,
        'fired': _fired.map((e) => e.name).toList(),
      };

  void restoreState(Map<String, Object?> j) {
    phase = AlertPhase.values.byName((j['phase'] as String?) ?? 'watching');
    followedBusId = j['followedBusId'] as String? ?? settings.busId;
    _fired
      ..clear()
      ..addAll(((j['fired'] as List?) ?? const [])
          .map((e) => AlertEventKind.values.byName(e as String)));
  }
}
