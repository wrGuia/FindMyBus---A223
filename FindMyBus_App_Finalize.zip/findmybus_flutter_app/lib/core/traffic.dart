// Traffic colouring derived from live bus speeds (there is no traffic API).
//
// The route is cut into fixed-length buckets. Each time a bus reports a speed,
// buckets near it get that speed blended in (exponential moving average).
// Observations expire, so a stretch no bus has driven recently goes back to
// "unknown" instead of showing old congestion.

enum TrafficLevel { unknown, clear, light, heavy }

class TrafficConfig {
  const TrafficConfig({
    this.bucketM = 300,
    this.influenceM = 450,
    this.heavyBelowKmh = 12,
    this.lightBelowKmh = 22,
    this.alpha = 0.4,
    this.memory = const Duration(minutes: 8),
  });

  final double bucketM;

  /// How far ahead/behind a bus its speed is applied.
  final double influenceM;

  /// Below this smoothed speed: heavy traffic (red).
  final double heavyBelowKmh;

  /// Below this smoothed speed: light traffic (yellow). Above: clear.
  final double lightBelowKmh;
  final double alpha;
  final Duration memory;
}

class TrafficSegment {
  const TrafficSegment(this.startM, this.endM, this.level);

  final double startM;
  final double endM;
  final TrafficLevel level;

  @override
  String toString() => 'TrafficSegment($startM-$endM $level)';
}

class _Bucket {
  double? kmh;
  DateTime? seen;
}

class TrafficModel {
  TrafficModel({required this.routeLengthM, this.config = const TrafficConfig()})
      : _buckets = List.generate(
            (routeLengthM / config.bucketM).ceil().clamp(1, 100000),
            (_) => _Bucket());

  final double routeLengthM;
  final TrafficConfig config;
  final List<_Bucket> _buckets;

  int get bucketCount => _buckets.length;

  void observe(double alongM, double kmh, DateTime at) {
    if (kmh.isNaN || kmh < 0) return;
    final from = ((alongM - config.influenceM) / config.bucketM).floor();
    final to = ((alongM + config.influenceM) / config.bucketM).floor();
    for (var i = from; i <= to; i++) {
      if (i < 0 || i >= _buckets.length) continue;
      final b = _buckets[i];
      final expired =
          b.seen == null || at.difference(b.seen!) > config.memory;
      b.kmh = (expired || b.kmh == null)
          ? kmh
          : b.kmh! + config.alpha * (kmh - b.kmh!);
      b.seen = at;
    }
  }

  TrafficLevel levelOf(double? kmh) {
    if (kmh == null) return TrafficLevel.unknown;
    if (kmh < config.heavyBelowKmh) return TrafficLevel.heavy;
    if (kmh < config.lightBelowKmh) return TrafficLevel.light;
    return TrafficLevel.clear;
  }

  TrafficLevel levelAt(double alongM, DateTime now) {
    final i = (alongM / config.bucketM).floor().clamp(0, _buckets.length - 1);
    return _levelOfBucket(_buckets[i], now);
  }

  TrafficLevel _levelOfBucket(_Bucket b, DateTime now) {
    if (b.seen == null || now.difference(b.seen!) > config.memory) {
      return TrafficLevel.unknown;
    }
    return levelOf(b.kmh);
  }

  /// Consecutive buckets with the same level merged into segments.
  List<TrafficSegment> segments(DateTime now) {
    final out = <TrafficSegment>[];
    TrafficLevel? cur;
    var start = 0.0;
    for (var i = 0; i < _buckets.length; i++) {
      final lvl = _levelOfBucket(_buckets[i], now);
      if (lvl != cur) {
        if (cur != null) out.add(TrafficSegment(start, i * config.bucketM, cur));
        cur = lvl;
        start = i * config.bucketM;
      }
    }
    if (cur != null) out.add(TrafficSegment(start, routeLengthM, cur));
    return out;
  }
}
