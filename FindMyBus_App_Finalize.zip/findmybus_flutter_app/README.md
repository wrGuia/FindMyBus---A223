# FindMyBus: Android passenger app (Flutter)

A Grab-style passenger app for the FindMyBus Django backend (LA Metro live buses,
with the backend's simulator as a fallback).

Screenshots of every screen are in `test/goldens/` (rendered by the widget tests
with offline placeholder map tiles; on a phone the map shows real OpenStreetMap streets).

## What it does

| Feature | Where |
|---|---|
| Live map of buses that glide between updates, no manual refresh | `lib/ui/widgets/bus_map.dart` |
| Route lines coloured by traffic: **red heavy, yellow light**, blue clear/no report | `lib/core/traffic.dart` |
| Search a destination or route; plans where to board from your location | `lib/ui/search_screen.dart`, `lib/core/trip_planner.dart` |
| Next buses to your stop with ETA, distance and stops away | `lib/core/eta.dart`, `lib/services/arrivals.dart` |
| Alert at a distance **you pick** (100 m to 3 km), plus an optional "arriving now" alert at 150 m | `lib/ui/widgets/alert_widgets.dart` |
| System notifications that keep working with the app in the background or closed | `lib/services/alert_service.dart` |
| In-app notifications: slide-down toast, bell badge and history | `lib/services/inbox.dart` |
| Stale/offline buses greyed out ("Last seen 1 min ago") and never trigger alerts | `lib/core/freshness.dart` |
| Settings: server address with connection test, default alert distance, update speed | `lib/ui/settings_screen.dart` |

Left out as agreed: Google sign-in, passenger capacity, weather.

### How the logic works
- **ETA** = remaining distance along the route ÷ the bus's smoothed recent speed
  (clamped 8–70 km/h, 18 km/h if unknown) + 15 s per intermediate stop.
- **Traffic**: the route is cut into 300 m pieces. Each live bus speed is blended
  into the pieces around it. Under 12 km/h is heavy, under 22 km/h is light.
  Readings expire after 8 minutes. There is no traffic API; this is inferred from the buses.
- **Alerts fire once per trip.** "Next bus" alerts lock onto the first bus that comes
  in range. The alert state is saved, so a restarted background service never
  repeats a notification. It ends when the bus passes your stop.
- **Freshness**: older than 45 s = stale, older than 2 min = offline.

All of these are plain Dart modules in `lib/core/` with unit tests, separate from the UI.

### Optimisations
- Route geometry downloaded once per session; polling uses the small `/api/buses/` endpoint.
- Polls only the open route (every 3 s by default; the overview polls half as often);
  polling stops when the app is in the background. "Battery saver" mode polls every 10 s.
- Map tiles are cached on the device (flutter_map's built-in cache).
- Polylines are rebuilt only when data changes. Far-zoom hides minor stops.
  The stop list uses fixed-height rows.
- Location is read on demand, not tracked continuously.

## Requirements
- Android Studio (current stable) with the Flutter and Dart plugins
- Flutter 3.44 or newer (built and tested with Flutter 3.47.7 / Dart 3.13)
- An Android emulator or phone, Android 7.0 (API 24) or newer
- The FindMyBus Django backend running (the `FindMyBus Flutter` folder in this project)

## 1. Start the backend
```bash
cd "FindMyBus Flutter"
pip install -r requirements.txt
python manage.py runserver 0.0.0.0:8000
```
`0.0.0.0` lets the emulator or a phone reach it. To demo without the live LA Metro feed:
`FINDMYBUS_DATA_SOURCE=simulated python manage.py runserver 0.0.0.0:8000`.
The emulator address `10.0.2.2` is allowed by default. For a phone on the same Wi-Fi, also allow your PC's IP:
`DJANGO_ALLOWED_HOSTS="localhost,127.0.0.1,10.0.2.2,192.168.1.23"`.

The app uses two small endpoints that were added to the backend for it:
`/api/routes/` and `/api/buses/?route=R1`. It also uses `along_km` and `updated_at` on buses and stops.
It still works against the older backend (it falls back to `/api/route/<id>/`),
but without stale detection.

## 2. Open and run in Android Studio
1. **File › Open** and choose this `findmybus_flutter_app` folder.
2. Accept the prompt to run **Pub get** (or run `flutter pub get`).
3. Start an emulator from **Device Manager** and press **Run ▶**.

The app connects to `http://10.0.2.2:8000` by default, which is your computer as seen from the emulator.

### Pointing the app at another server
- In the app: **⚙ Settings › Server address › Test & save**, or
- at build time: `flutter run --dart-define=API_BASE_URL=https://your-host.example.com`
  (in Android Studio: **Run › Edit Configurations › Additional run args**).

Phone on the same Wi-Fi: `http://<your-PC-IP>:8000`. Anywhere: an HTTPS tunnel (see the backend README).

## 3. Try the alerts
1. Open a route, pick **your stop**, tap **Notify me when a bus is near**.
2. Choose the distance and **Start alert**. Allow notifications when Android asks.
3. A quiet "Tracking your bus" notification shows the live ETA. Press Home: you
   still get a heads-up notification when the bus is within your distance, and
   again when it is arriving. **Stop alert** is on the notification and on the green banner.

On some phones (Xiaomi, Oppo, Samsung power saving), set battery use for
FindMyBus to "Unrestricted" so background alerts are not delayed.

## Tests
```bash
flutter analyze
flutter test                     # 32 tests: logic, API parsing, screens
flutter test --update-goldens    # re-render the screenshots in test/goldens/
```

## Project layout
```
lib/
  core/       eta, approach_alert, traffic, freshness, trip_planner, geo (pure Dart, unit-tested)
  data/       API client + models for the Django JSON
  services/   background alert service, notifications, inbox, location, arrivals glue
  state/      AppState (live data + selection), AppSettings
  ui/         home (map + bottom sheet), search, notifications, settings, widgets/
test/         unit + widget tests, fixtures captured from the backend, goldens/
```

## Dependencies
`flutter_map` + `latlong2` (OpenStreetMap, no API key), `http`,
`flutter_local_notifications`, `flutter_foreground_task` (background alerts),
`geolocator` (nearest stop), `shared_preferences`.

The public OpenStreetMap tile server is fine for development and demos. For a
public release, use a tile provider that allows production use (for example
MapTiler or Stadia, which need an API key). Pass that key with `--dart-define`
and never commit it.
