// Parses real responses captured from the Django backend and runs them through
// the same pipeline the UI and the background alert service use.
import 'dart:convert';
import 'dart:io';

import 'package:findmybus/core/approach_alert.dart';
import 'package:findmybus/core/eta.dart';
import 'package:findmybus/core/freshness.dart';
import 'package:findmybus/data/api_client.dart';
import 'package:findmybus/data/models.dart';
import 'package:findmybus/services/alert_monitor.dart';
import 'package:findmybus/services/arrivals.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';

Map<String, Object?> _fixture(String name) =>
    jsonDecode(File('test/fixtures/$name').readAsStringSync()) as Map<String, Object?>;

Map<String, Object?> _busJson(String id, String dir, double alongKm,
        {double speed = 20, double? updatedAt, double lat = 34.06, double lon = -118.35}) =>
    {
      'id': id,
      'route_id': 'R1',
      'lat': lat,
      'lon': lon,
      'status': 'On Time',
      'speed_kmh': speed,
      'deviation': false,
      'live': true,
      'next_stop': 'x',
      'next_stop_index': 0,
      'direction': dir,
      'heading': 'To Downtown LA',
      'along_km': alongKm,
      'updated_at': updatedAt ?? 1000,
    };

void main() {
  test('parses /api/routes/', () {
    final routes = ((_fixture('routes.json')['routes'] as List).cast<Map<String, Object?>>())
        .map(RouteSummary.fromJson)
        .toList();
    expect(routes, hasLength(3));
    expect(routes.first.code, '720');
    expect(routes.first.title, startsWith('Wilshire Rapid'));
    expect(routes.first.headsigns.fwd, 'Downtown LA');
  });

  test('parses /api/route/R1/ and /api/buses/', () {
    final route = RouteDetail.fromJson(_fixture('route_R1.json'));
    expect(route.code, '720');
    expect(route.stops, hasLength(7));
    expect(route.alongFromServer, isTrue);
    expect(route.path.lengthM, greaterThan(20000));
    // Stops are in increasing order along the route.
    for (var i = 1; i < route.stops.length; i++) {
      expect(route.stops[i].alongM, greaterThan(route.stops[i - 1].alongM));
    }
    final snap = BusSnapshot.fromJson('R1', _fixture('buses_R1.json'));
    expect(snap.buses, hasLength(4));
    expect(snap.serverTime, isNotNull);
    final views = buildBusViews(route, snap, SpeedSmoother(), now: snap.fetchedAt);
    expect(views.every((v) => v.freshness == Freshness.live), isTrue);
  });

  test('older backend without along_km falls back to projection', () {
    final j = Map<String, Object?>.from(_fixture('route_R1.json'));
    j['stops'] = [
      for (final s in (j['stops'] as List).cast<Map>()) {'name': s['name'], 'lat': s['lat'], 'lon': s['lon']}
    ];
    final route = RouteDetail.fromJson(j);
    expect(route.alongFromServer, isFalse);
    expect(route.stops.last.alongM, closeTo(route.path.lengthM, 50));
  });

  test('ETAs only include buses heading to the stop, nearest first', () {
    final route = RouteDetail.fromJson(_fixture('route_R1.json'));
    final stop = route.stops[4]; // Koreatown
    final stopKm = stop.alongM / 1000;
    final snap = BusSnapshot.fromJson('R1', {
      'server_time': 1000.0,
      'buses': [
        _busJson('far', 'fwd', stopKm - 5),
        _busJson('near', 'fwd', stopKm - 1),
        _busJson('passed', 'fwd', stopKm + 1),
        _busJson('other-way', 'rev', stopKm + 2),
        _busJson('old', 'fwd', stopKm - 0.5, updatedAt: 800), // 200 s old -> offline
      ],
    });
    final views = buildBusViews(route, snap, SpeedSmoother(), now: snap.fetchedAt);
    final etas = etasToStop(route, views, 4, 'fwd');
    expect(etas.map((e) => e.view.bus.id), ['near', 'far']);
    expect(etas.first.eta.remainingM, closeTo(1000, 1));
  });

  test('stale bus is shown but cannot trigger an alert', () {
    final route = RouteDetail.fromJson(_fixture('route_R1.json'));
    final stopKm = route.stops[4].alongM / 1000;
    final snap = BusSnapshot.fromJson('R1', {
      'server_time': 1000.0,
      'buses': [_busJson('S', 'fwd', stopKm - 0.2, updatedAt: 940)], // 60 s old -> stale
    });
    final views = buildBusViews(route, snap, SpeedSmoother(), now: snap.fetchedAt);
    expect(views.single.freshness, Freshness.stale);
    const s = AlertSettings(
        routeId: 'R1', routeLabel: '720', stopIndex: 4, stopName: 'K', direction: 'fwd', thresholdM: 500);
    final approaches = approachesFor(s, route, views);
    expect(approaches.single.trusted, isFalse);
    expect(AlertEngine(s).evaluate(approaches), isEmpty);
  });

  test('alert monitor end to end against a fake server', () async {
    final route = _fixture('route_R1.json');
    final stopKm = ((route['stops'] as List)[4] as Map)['along_km'] as num;
    var along = stopKm - 2.0; // bus 2 km before Koreatown, closing 0.8 km per poll
    final client = MockClient((req) async {
      if (req.url.path == '/api/route/R1/') return http.Response(jsonEncode(route), 200);
      if (req.url.path == '/api/buses/') {
        final body = {
          'server_time': 1000.0,
          'buses': [_busJson('Bus 7', 'fwd', along.toDouble())],
        };
        along += 0.8;
        return http.Response(jsonEncode(body), 200);
      }
      return http.Response('nope', 404);
    });
    final m = AlertMonitor(
      FindMyBusApi('http://test', client: client),
      const AlertSettings(
          routeId: 'R1', routeLabel: '720', stopIndex: 4, stopName: 'Koreatown', direction: 'fwd', thresholdM: 500),
    );
    final kinds = <AlertEventKind>[];
    for (var i = 0; i < 6; i++) {
      final u = await m.tick();
      kinds.addAll(u.events.map((e) => e.kind));
    }
    // 2.0 -> 1.2 -> 0.4 (approaching) -> -0.4 (passed): never arriving because
    // the bus jumped past 150 m between polls; and each fires once.
    expect(kinds, [AlertEventKind.approaching, AlertEventKind.passed]);
    final (title, _) = describeEvent(m.settings,
        const AlertEvent(AlertEventKind.approaching, 'Bus 7', 400, Duration(minutes: 1)));
    expect(title, 'Bus 7 is approaching Koreatown');
  });

  test('api falls back to /api/route/ on an older backend', () async {
    final route = _fixture('route_R1.json');
    final client = MockClient((req) async {
      if (req.url.path == '/api/route/R1/') return http.Response(jsonEncode(route), 200);
      return http.Response('nope', 404);
    });
    final api = FindMyBusApi('10.0.2.2:8000/', client: client);
    expect(api.baseUrl, 'http://10.0.2.2:8000');
    final snap = await api.buses('R1');
    expect(snap.buses, isNotEmpty);
    final routes = await api.routes();
    expect(routes.single.code, '720');
  });
}
