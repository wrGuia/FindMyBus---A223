// Renders the main screens against captured backend data, checks the key
// flows work without layout errors, and writes screenshots (goldens) to
// test/goldens/ when run with --update-goldens.
import 'dart:convert';
import 'dart:io';

import 'package:findmybus/data/api_client.dart';
import 'package:findmybus/main.dart';
import 'package:findmybus/services/alert_service.dart';
import 'package:findmybus/services/inbox.dart';
import 'package:findmybus/services/location_service.dart';
import 'package:findmybus/state/app_settings.dart';
import 'package:findmybus/state/app_state.dart';
import 'package:findmybus/ui/widgets/bus_map.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:latlong2/latlong.dart';
import 'package:shared_preferences/shared_preferences.dart';

class _FakeLocation extends LocationService {
  @override
  Future<LocationResult> current() async =>
      const LocationResult(LatLng(34.0605, -118.3480), null); // near Wilshire/Fairfax
}

class _OfflineTiles extends TileProvider {
  _OfflineTiles(this.bytes);
  final Uint8List bytes;
  @override
  ImageProvider getImage(TileCoordinates coordinates, TileLayer options) => MemoryImage(bytes);
}

String _fx(String name) => File('test/fixtures/$name').readAsStringSync();

Future<void> _loadFonts() async {
  final dir = '${Platform.environment['FLUTTER_ROOT'] ?? ''}/bin/cache/artifacts/material_fonts';
  if (!Directory(dir).existsSync()) return; // falls back to the test font
  final roboto = FontLoader('Roboto');
  for (final w in ['Regular', 'Medium', 'Bold', 'Black']) {
    roboto.addFont(Future.value(ByteData.sublistView(File('$dir/Roboto-$w.ttf').readAsBytesSync())));
  }
  await roboto.load();
  final icons = FontLoader('MaterialIcons')
    ..addFont(Future.value(ByteData.sublistView(File('$dir/MaterialIcons-Regular.otf').readAsBytesSync())));
  await icons.load();
}

Future<void> _settle(WidgetTester t) async {
  for (var i = 0; i < 12; i++) {
    await t.pump(const Duration(milliseconds: 200));
  }
}

void main() {
  final client = MockClient((req) async {
    final p = req.url.path;
    if (p == '/api/routes/') return http.Response(_fx('routes.json'), 200);
    final m = RegExp(r'^/api/route/(R\d)/$').firstMatch(p);
    if (m != null) return http.Response(_fx('route_${m[1]}.json'), 200);
    if (p == '/api/buses/') {
      // Make every bus look freshly reported.
      final j = jsonDecode(_fx('buses_${req.url.queryParameters['route']}.json')) as Map<String, dynamic>;
      final now = DateTime.now().millisecondsSinceEpoch / 1000;
      j['server_time'] = now;
      for (final b in j['buses'] as List) {
        (b as Map)['updated_at'] = now - 2;
      }
      return http.Response(jsonEncode(j), 200);
    }
    return http.Response('not found', 404);
  });

  setUpAll(() async {
    await _loadFonts();
    debugTileProvider = _OfflineTiles(File('test/fixtures/tile.png').readAsBytesSync());
  });

  testWidgets('overview, route, bus and alert flows render', (tester) async {
    tester.view.physicalSize = const Size(1080, 2340);
    tester.view.devicePixelRatio = 2.625;
    addTearDown(tester.view.reset);
    SharedPreferences.setMockInitialValues({});

    final settings = AppSettings();
    final inbox = Inbox();
    final alerts = AlertController(inbox);
    final state = AppState(settings,
        location: _FakeLocation(), apiFactory: (url) => FindMyBusApi(url, client: client));

    await tester.pumpWidget(FindMyBusApp(state: state, alerts: alerts, inbox: inbox, settings: settings));
    await tester.runAsync(() async {
      await settings.load();
      await state.init();
      await Future<void>.delayed(const Duration(milliseconds: 100));
    });
    await _settle(tester);
    await tester.runAsync(() => Future<void>.delayed(const Duration(milliseconds: 200)));
    await _settle(tester);

    expect(find.text('Where are you going?'), findsOneWidget);
    expect(find.text('Nearest stop'), findsOneWidget);
    await expectLater(find.byType(MaterialApp), matchesGoldenFile('goldens/1_overview.png'));

    // Open route 720.
    await tester.tap(find.textContaining('Wilshire Rapid').first);
    await tester.runAsync(() => Future<void>.delayed(const Duration(milliseconds: 200)));
    await _settle(tester);
    expect(find.text('Next buses'), findsOneWidget);
    expect(state.selectedRouteId, 'R1');
    await expectLater(find.byType(MaterialApp), matchesGoldenFile('goldens/2_route.png'));

    // Expand the sheet to show the stop timeline + traffic legend.
    await tester.drag(find.text('Next buses'), const Offset(0, -500));
    await _settle(tester);
    expect(find.text('Heavy traffic'), findsOneWidget);
    await expectLater(find.byType(MaterialApp), matchesGoldenFile('goldens/3_route_expanded.png'));

    // Alert setup sheet.
    await tester.tap(find.text('Notify me when a bus is near'));
    await _settle(tester);
    expect(find.text('Start alert'), findsOneWidget);
    await expectLater(find.byType(MaterialApp), matchesGoldenFile('goldens/4_alert_setup.png'));
    await tester.tapAt(const Offset(200, 60)); // dismiss
    await _settle(tester);

    // Bus detail (first bus marker in the selected route).
    final busId = state.viewsOf('R1').first.bus.id;
    state.selectBus(busId);
    await _settle(tester);
    expect(find.text('Follow on map'), findsOneWidget);
    await expectLater(find.byType(MaterialApp), matchesGoldenFile('goldens/5_bus.png'));

    // In-app notification toast.
    inbox.add(InboxItem(
        id: 'x',
        title: 'Bus Sim 01 is approaching Koreatown',
        body: '480 m away · about 2 min. Get ready!',
        time: DateTime.now()));
    for (var i = 0; i < 4; i++) {
      await tester.pump(const Duration(milliseconds: 150));
    }
    expect(find.text('Bus Sim 01 is approaching Koreatown'), findsOneWidget);
    await expectLater(find.byType(MaterialApp), matchesGoldenFile('goldens/6_toast.png'));
    await tester.pump(const Duration(seconds: 6));

    state.pause();
    await _settle(tester);
  });
}
