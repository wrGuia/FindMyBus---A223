import 'package:findmybus/core/approach_alert.dart';
import 'package:findmybus/core/eta.dart';
import 'package:findmybus/core/freshness.dart';
import 'package:findmybus/core/geo.dart';
import 'package:findmybus/core/traffic.dart';
import 'package:findmybus/core/trip_planner.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:latlong2/latlong.dart';

void main() {
  group('geo', () {
    test('haversine matches a known distance', () {
      // Santa Monica -> Downtown LA is roughly 23 km in a straight line.
      final d = haversineM(const LatLng(34.0185, -118.4935), const LatLng(34.0486, -118.2589));
      expect(d, closeTo(21900, 600));
    });

    test('path is densified and projection is monotonic', () {
      final p = RoutePath.fromPoints(const [LatLng(34.0, -118.3), LatLng(34.0, -118.29)]);
      expect(p.points.length, greaterThan(10)); // ~920 m split into <=60 m pieces
      expect(p.lengthM, closeTo(922, 5));
      final a = p.project(const LatLng(34.0001, -118.298));
      final b = p.project(const LatLng(34.0001, -118.295));
      expect(b, greaterThan(a));
      expect(p.pointAt(p.lengthM / 2).longitude, closeTo(-118.295, 0.0005));
    });

    test('slice covers the requested range', () {
      final p = RoutePath.fromPoints(const [LatLng(34.0, -118.3), LatLng(34.0, -118.29)]);
      final s = p.slice(100, 400);
      expect(haversineM(s.first, p.pointAt(100)), lessThan(1));
      expect(haversineM(s.last, p.pointAt(400)), lessThan(1));
      expect(p.slice(400, 100), isEmpty);
    });
  });

  group('eta', () {
    const calc = EtaCalculator(EtaConfig(dwellPerStop: Duration.zero));

    test('remaining distance over speed', () {
      final r = calc.toStop(busAlongM: 1000, stopAlongM: 4000, forward: true, smoothedKmh: 36);
      expect(r.remainingM, 3000);
      expect(r.eta, const Duration(seconds: 300)); // 3 km at 10 m/s
      expect(r.passed, isFalse);
    });

    test('reverse direction counts the other way', () {
      final r = calc.toStop(busAlongM: 4000, stopAlongM: 1000, forward: false, smoothedKmh: 36);
      expect(r.remainingM, 3000);
      expect(r.passed, isFalse);
    });

    test('stop behind the bus is passed', () {
      final r = calc.toStop(busAlongM: 4000, stopAlongM: 1000, forward: true, smoothedKmh: 36);
      expect(r.passed, isTrue);
    });

    test('a stopped bus uses the minimum speed, unknown uses fallback', () {
      expect(calc.effectiveKmh(0), 8);
      expect(calc.effectiveKmh(null), 18);
      expect(calc.effectiveKmh(200), 70);
    });

    test('dwell time is added per intermediate stop', () {
      const c = EtaCalculator(EtaConfig(dwellPerStop: Duration(seconds: 20)));
      final r = c.toStop(
          busAlongM: 0,
          stopAlongM: 3600,
          forward: true,
          smoothedKmh: 36,
          stopsAlongM: const [0, 1000, 2000, 3600, 5000]);
      expect(r.stopsAway, 2);
      expect(r.eta, const Duration(seconds: 360 + 40));
    });

    test('speed smoother damps spikes and forgets missing buses', () {
      final s = SpeedSmoother(alpha: 0.5);
      expect(s.add('a', 20), 20);
      expect(s.add('a', 0), 10);
      expect(s.add('a', null), 10);
      s.retain(const ['b']);
      expect(s.of('a'), isNull);
    });

    test('formatting', () {
      expect(formatEta(const Duration(seconds: 20)), 'Now');
      expect(formatEta(const Duration(minutes: 7)), '7 min');
      expect(formatEta(const Duration(minutes: 65)), '1 h 05 min');
      expect(formatDistance(843), '840 m');
      expect(formatDistance(1260), '1.3 km');
    });
  });

  group('freshness', () {
    const p = FreshnessPolicy();
    test('classifies by total age', () {
      expect(p.classify(const Duration(seconds: 5), Duration.zero), Freshness.live);
      expect(p.classify(const Duration(seconds: 30), const Duration(seconds: 20)), Freshness.stale);
      expect(p.classify(const Duration(seconds: 130), Duration.zero), Freshness.offline);
    });
  });

  group('approach alert', () {
    AlertSettings settings({String? busId, bool arriving = true}) => AlertSettings(
          routeId: 'R1',
          routeLabel: '720',
          stopIndex: 3,
          stopName: 'Koreatown',
          direction: 'fwd',
          thresholdM: 500,
          busId: busId,
          notifyArriving: arriving,
        );
    BusApproach at(String id, double m, {bool passed = false, bool trusted = true}) => BusApproach(
        busId: id, remainingM: m, eta: Duration(seconds: m ~/ 5), passed: passed, trusted: trusted);

    test('fires approaching once, then arriving once, then passed', () {
      final e = AlertEngine(settings());
      expect(e.evaluate([at('A', 2000)]), isEmpty);
      final first = e.evaluate([at('A', 480)]);
      expect(first.single.kind, AlertEventKind.approaching);
      expect(e.evaluate([at('A', 300)]), isEmpty); // never twice
      expect(e.evaluate([at('A', 120)]).single.kind, AlertEventKind.arriving);
      expect(e.evaluate([at('A', 60)]), isEmpty);
      expect(e.evaluate([at('A', 80, passed: true)]).single.kind, AlertEventKind.passed);
      expect(e.isFinished, isTrue);
      expect(e.evaluate([at('A', 10)]), isEmpty);
    });

    test('locks onto the first bus in range', () {
      final e = AlertEngine(settings());
      e.evaluate([at('A', 450), at('B', 900)]);
      expect(e.followedBusId, 'A');
      // B coming close later does not trigger another approach alert.
      expect(e.evaluate([at('A', 300), at('B', 400)]), isEmpty);
    });

    test('stale positions never trigger', () {
      final e = AlertEngine(settings());
      expect(e.evaluate([at('A', 100, trusted: false)]), isEmpty);
      expect(e.followedBusId, isNull);
    });

    test('a bus already at the stop gives one arriving alert only', () {
      final e = AlertEngine(settings());
      final ev = e.evaluate([at('A', 100)]);
      expect(ev.map((x) => x.kind), [AlertEventKind.arriving]);
      expect(e.evaluate([at('A', 400)]), isEmpty);
    });

    test('without arriving alerts, finishes after approaching', () {
      final e = AlertEngine(settings(arriving: false));
      expect(e.evaluate([at('A', 100)]).single.kind, AlertEventKind.approaching);
      expect(e.isFinished, isTrue);
    });

    test('specific bus ignores other buses', () {
      final e = AlertEngine(settings(busId: 'B'));
      expect(e.evaluate([at('A', 100), at('B', 1500)]), isEmpty);
      expect(e.evaluate([at('B', 400)]).single.busId, 'B');
    });

    test('restored state does not fire again', () {
      final e = AlertEngine(settings());
      e.evaluate([at('A', 450)]);
      final saved = e.stateToJson();
      final again = AlertEngine(AlertSettings.fromJson(settings().toJson()))..restoreState(saved);
      expect(again.followedBusId, 'A');
      expect(again.evaluate([at('A', 400)]), isEmpty);
      expect(again.evaluate([at('A', 100)]).single.kind, AlertEventKind.arriving);
    });
  });

  group('traffic', () {
    final now = DateTime(2026, 1, 1, 8);

    test('slow buses paint heavy, medium light, fast clear', () {
      final t = TrafficModel(routeLengthM: 6000, config: const TrafficConfig(bucketM: 500, influenceM: 0));
      t.observe(250, 6, now);
      t.observe(2250, 16, now);
      t.observe(4250, 35, now);
      expect(t.levelAt(250, now), TrafficLevel.heavy);
      expect(t.levelAt(2250, now), TrafficLevel.light);
      expect(t.levelAt(4250, now), TrafficLevel.clear);
      expect(t.levelAt(5800, now), TrafficLevel.unknown);
    });

    test('segments merge equal neighbours and cover the route', () {
      final t = TrafficModel(routeLengthM: 2000, config: const TrafficConfig(bucketM: 500, influenceM: 500));
      t.observe(750, 5, now); // buckets 0..2
      final segs = t.segments(now);
      expect(segs.first.level, TrafficLevel.heavy);
      expect(segs.first.startM, 0);
      expect(segs.first.endM, 1500);
      expect(segs.last.endM, 2000);
    });

    test('observations expire', () {
      final t = TrafficModel(routeLengthM: 1000, config: const TrafficConfig(memory: Duration(minutes: 5)));
      t.observe(100, 5, now);
      expect(t.levelAt(100, now.add(const Duration(minutes: 6))), TrafficLevel.unknown);
    });

    test('smoothing needs more than one slow reading to flip clear to heavy', () {
      final t = TrafficModel(routeLengthM: 1000, config: const TrafficConfig(influenceM: 0, alpha: 0.4));
      t.observe(100, 30, now);
      t.observe(100, 0, now); // 30 -> 18: light, not heavy
      expect(t.levelAt(100, now), TrafficLevel.light);
    });
  });

  group('trip planner', () {
    const stops = [LatLng(34.0, -118.40), LatLng(34.0, -118.35), LatLng(34.0, -118.30), LatLng(34.0, -118.25)];

    test('boards at the nearest stop and rides toward the destination', () {
      final p = planTrip(stops: stops, from: const LatLng(34.001, -118.351), destinationStopIndex: 3)!;
      expect(p.boardStopIndex, 1);
      expect(p.direction, 'fwd');
      final back = planTrip(stops: stops, from: const LatLng(34.0, -118.26), destinationStopIndex: 0)!;
      expect(back.direction, 'rev');
    });

    test('no plan when already at the destination', () {
      expect(planTrip(stops: stops, from: stops[2], destinationStopIndex: 2), isNull);
    });
  });
}
