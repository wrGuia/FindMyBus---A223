package com.findmybus.findmybus

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
